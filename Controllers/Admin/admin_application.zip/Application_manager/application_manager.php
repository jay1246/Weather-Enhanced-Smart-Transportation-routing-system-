<?php

namespace App\Controllers\Admin\Application_manager;

use App\Controllers\BaseController;
use ZipArchive;

class application_manager extends BaseController
{

    // ---------------admin  Application Manager ---------------- 

    public function index()
    {
        $data['page_name'] = 'Application Manager';
        $status_list = "";
        if (session()->get('admin_account_type') == 'admin') {
            $status_list = ['Start', 'Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined', 'Withdrawn', 'Expired'];
        } else if (session()->get('admin_account_type') == 'head_office') {
            $status_list = ['Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined'];
        } else {
            exit;
        }
        //    $data['stage_1'] = $this->stage_1_model->asObject()->orWhereIn('status', $status_list)->orderby('submitted_date', 'DESC')->findAll();



        $all_list = array();
        $application_pointer_model = $this->application_pointer_model->asObject()->orWhereIn('status', $status_list)->orderby('create_date', 'DESC')->findAll();
        $lastQuery = $this->application_pointer_model->getLastQuery();

        // Display the last executed query
        // echo $lastQuery;
        $i = 0;
        $aaa = array();
        foreach ($application_pointer_model as $stage) {
            // echo "<pre>";
            // print_r($stage);
            // echo "</pre>";
            // exit;

            $show = true;
            if ($stage->stage == "stage_1") {
                if ($stage->status == "Start") {
                    $show = false;
                }
                if (session()->get('admin_account_type') == 'head_office') {
                    if ($stage->status == "Start" || $stage->status == "Submitted") {
                        $show = false;
                    }
                }
            }
            if ($show) {
                $i++;
                $asdasd = $stage->stage . " " . $stage->status;
                if (!in_array($asdasd, $aaa)) {

                    $aaa[] = $asdasd;
                }



                $list_array = array();

                $pointer_id = $stage->id;
                $list_array['pointer_id'] = $pointer_id;
                $list_array['unique_id'] = application_mo($pointer_id);
                $list_array['portal_reference_no'] = portal_reference_no($pointer_id);

                $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['Applicant_name'] =   $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name;


                $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
                $Pathway =  (isset($s1_occupation->pathway) ? $s1_occupation->pathway : "");
                if ($Pathway == "Pathway 2") {
                    $list_array['Pathway'] = 'p2';
                } else {
                    $list_array['Pathway'] = 'p1';
                }
                $occupation_list = find_one_row('occupation_list', 'id', $s1_occupation->occupation_id);
                $list_array['occupation_name'] =  (isset($occupation_list->name) ? $occupation_list->name : "");

                $stage_1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['date_of_birth'] =  (isset($stage_1_personal_details->date_of_birth) ? $stage_1_personal_details->date_of_birth : "");

                $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
                $stage_index = application_stage_no($pointer_id);
                $list_array['approved_date']  =  $stage_1->approved_date;


                $list_array['Current_Status'] =  create_status_rename(create_status_format($stage_index),$pointer_id);

                if (create_status_format($stage_index) == 'S2 - Start') {
                    $stage_status = 'S1 - ' . $stage->status;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $stage_status = 'S2 - ' . find_one_row('stage_2', 'pointer_id', $stage->id)->status;
                } else {
                    $stage_status = create_status_format($stage_index);
                }
                $list_array['application_status'] =  substr($stage_status, 0, 2);



                $stage_ = explode(" ", create_status_format($stage_index));

                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S2') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S3') {
                    // $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else {
                    // $get_submit_date = (isset(find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date)) ? find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date : "";
                    $get_submit_date =  $stage_1->submitted_date;
                }
                if (!empty($get_submit_date)) {
                    $list_array['submitted_date'] = $get_submit_date;
                    $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
                } else {
                    $list_array['submitted_date'] =  "";
                    $list_array['submitted_date_format'] =  "";
                }



                $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $pointer_id);
                $list_array['additional_info_request'] =  $additional_info_request;

                $all_list[] = $list_array;
            }
        }


        $data['all_list'] = $all_list;



        return view('admin/application_manager/index', $data);
    }

    // ---------------admin Application Manager -> view/update ----------------

    public function view_application($pointer_id, $tab)
    {
        
        $get_id = find_one_row('application_pointer', 'id', $pointer_id);
    
        $user_id = $get_id->user_id;
        
        
        if (session()->get('admin_account_type') == 'admin') {
            $data['stage_1'] = $this->stage_1_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_2'] = $this->stage_2_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            //    echo  $this->stage_2_model->getLastQuery();
            $data['stage_3'] = $this->stage_3_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
             $data['stage_4'] = $this->stage_4_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();

            
        } else {
            $data['stage_1'] = $this->stage_1_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_2'] = $this->stage_2_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_3'] = $this->stage_3_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_4'] = $this->stage_4_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();

        }
        
        $data['username'] =  $this->user_account_model->asObject()->find($user_id);
        $data['s1_personal_details'] =  $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['s1_contact_details'] =  $this->stage_1_contact_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['s1_occupation'] =  $this->stage_1_occupation_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['additional_info_request'] = $this->additional_info_request_model->asObject()->where('pointer_id', $pointer_id)->first();
        
        $data['stage_1_documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_1'])->whereNotIn('required_document_id', [50])->orderby('required_document_id', 'ASC')->findAll();
        $data['stage_3_documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->whereNotIn('required_document_id', [23, 24, 25, 26])->findAll();
        $data['stage_4_documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_4'])->whereNotIn('required_document_id', [23, 24, 25, 26])->findAll();
        // print_r($data['stage_4_documents']);
        // exit;
        $data['stage_2_add_employees'] = $this->stage_2_add_employment_model->asObject()->where('pointer_id', $pointer_id)->findAll();
        $data['application_pointer'] = $this->application_pointer_model->asObject()->where('id', $pointer_id)->first();
        $data['stage_2_email_verification'] = $this->email_verification_model->asObject()->where('pointer_id', $pointer_id,'verification_type','Verification Email - Employment')->findAll();
        $data['stage_3_documents_vhp'] = $this->documents_model->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->findAll();


        $data['pointer_id'] = $pointer_id;
        $data['user_id'] = $user_id;
        $data['tab'] = $tab;
        $data['is_uploaded_admin_doc'] =  $this->email_verification_model->asObject()->where('pointer_id', $pointer_id)->first();

        
             $offline_locations = $this->stage_3_offline_location_model->find();

            $country = array();

            foreach ($offline_locations as $key => $value) {

                if (!in_array($value['country'], $country)) {

                    $country[] = $value['country'];

                }

            }


         $location = array();

            foreach ($country as $key => $value) {

                $offline_location = $this->stage_3_offline_location_model->where(['country' => $value, 'pratical'=>0])->find();

                $location[$value] = $offline_location;

            }
            $pratical_location = array();

            foreach ($country as $key => $value) {

                $prat_location = $this->stage_3_offline_location_model->where(['country' => $value, 'pratical'=>1])->find();

                $pratical_location[$value] = $prat_location;

            }



            $data['location']=$location;
            $data['pratical_location']=$pratical_location;
            
             $data['time_zone'] = $this->time_zone_model->groupBy('zone_name')->findAll();
            
        return view('admin/application_manager/view_application', $data);
    }
    // ---------------admin  Application Manager -> view/update -> stage 1 -> update Head Office Unique Number----------------
    public function update_unique_no()
    {

        $pointer_id = $this->request->getVar('pointer_id');
        $unique_head_office_no = $this->request->getVar('unique_head_office_no');
        $allocate_team_member_name = $this->request->getVar('Assigned_Team_Member_id');

        $output = $this->stage_1_model->where(['pointer_id' => $pointer_id])->set(['unique_id' => $unique_head_office_no, 'allocate_team_member_name' => $allocate_team_member_name])->update();
        $json = ["error" => 1];
        if ($output) {
            $json = [
                "error" => 0,
                "msg"   => "Successfully",
            ];
        }

        echo json_encode($json);
    }
    // ---------------admin Application Manager -> documents ->comments for all stages ----------------
    public function comments_for_document()
    {
        $reasons = $this->request->getPost('reason');
        $stages = $this->request->getPost('stage');
        $pointer_ids = $this->request->getPost('pointer_id');
        $document_ids = $this->request->getPost('document_id');
        $request_additional = $this->request->getPost("request_additional");


        if (!empty($request_additional)) {
            $addition_data = array(
                'pointer_id' => $pointer_ids[0],
                'stage' => $stages[0],
                'reason' => $request_additional,
                'status' => 'send',
                'send_by' => session()->get('admin_id')

            );
            $this->additional_info_request_model->insert($addition_data);
        }


        if ($reasons != "") {
            foreach ($reasons as $key => $value) {
                if ($value) {
                    $reason = $value;
                    $stage =  $stages[$key];
                    $pointer_id =  $pointer_ids[$key];
                    $document_id =  $document_ids[$key];

                    $data = array(
                        'pointer_id' => $pointer_id,
                        'stage' => $stage,
                        'document_id' => $document_id,
                        'reason' => $reason,
                        'status' => 'send',
                        'send_by' => session()->get('admin_id')
                    );
                    $this->additional_info_request_model->insert($data);
                }
                $key++;
            }
        }
        $pointer_id = $pointer_ids[0];
        $user_id = find_one_row("application_pointer", "id", $pointer_id)->user_id;
        $user_data = find_one_row("user_account", "id", $user_id);
            // stage 1
        if ($stages[0] == 'stage_1' && $user_data->account_type == "Agent") {
            // s1_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '16'])->first();
        } elseif ($stages[0] == 'stage_1' && $user_data->account_type == "Applicant") {
            // s1_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '61'])->first();
            // stage 2
        } elseif ($stages[0] == 'stage_2' && $user_data->account_type == "Agent") {
            // s2_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '18'])->first();
        } elseif ($stages[0] == 'stage_2' && $user_data->account_type == "Applicant") {
            // s2_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '72'])->first();
            // stage 3
        } elseif ($stages[0] == 'stage_3') {
            // s3_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '33'])->first();
            // stage 4
        } elseif ($stages[0] == 'stage_4' && $user_data->account_type == "Agent") {
            // s4_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '139'])->first();
        } elseif ($stages[0] == 'stage_4' && $user_data->account_type == "Applicant") {
            // s4_request_additional_applicant
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '148'])->first();
        }
        
        $user_email  = $user_data->email;
        $subject = mail_tag_replace($mail_temp->subject, $pointer_id);
        $message = mail_tag_replace($mail_temp->body, $pointer_id);
        $to = $user_email;

        // print_r($message);
        // print_r($subject);
        // exit;
        $addReplyTo_array = [];
        if (session()->get('admin_account_type') == "head_office") {
            $addBCC_array = [env('ADMIN_EMAIL')];
        } else {
            $addBCC_array = [];
        }
        $addCC_array = [];
        $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, $addReplyTo_array, $addBCC_array, $addCC_array);


        if ($check == 1) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }

    // ---------------admin Application Manager -> documents -> documents delete for all stages ----------------
    public function delete_document($id)
    {
        $document = find_one_row("documents", "id", $id);
        $file = $document->document_path . '/' . $document->document_name;
        unlink($file);
        if ($this->documents_model->where('id', $id)->delete()) {
            $callback = array(
                "color" => "success",
                "msg" => "Delete recode",
                "response" => true,
            );
        } else {
            $callback = array(
                "msg" => "unable to delete record",
                "color" => "danger",
                "response" => false,
            );
        }
        echo json_encode($callback);
    }
    
    public function delete_company($id)
    {
        // stage_2_add_employment
       $employ = $this->stage_2_add_employment_model->asObject()->where('id', $id)->first();
       $documents = $this->documents_model->asObject()->where('employee_id',$id)->findAll();
       $number = count($documents);
       $name = $employ->company_organisation_name;
        $company_organisation_name =  $employ->company_organisation_name;
        $company_organisation_name = preg_replace('/[^A-Za-z0-9\-]/', '_', $company_organisation_name); // Removes special chars.
        $company_organisation_name = trim(str_replace(' ', '_', $company_organisation_name));
        $folder_path = 'public/application/' . $employ->pointer_id . '/stage_2/' . $company_organisation_name;

       $count = 0;
       if($documents){
       foreach($documents as $document){
        //   $document = find_one_row("documents", "id", $id);
            $file = $document->document_path . '/' . $document->document_name;
            unlink($file);
            if ($this->documents_model->where('id', $document->id)->delete()) {
               $count++;
            }
       }
       }
    //   echo $path_folder;
        $delete_folder = false;
        if($number == $count){
       $folderPath = $folder_path;

        function deleteFolder($folderPath) {
            if (!is_dir($folderPath)) {
                return;
            }
        
            $files = array_diff(scandir($folderPath), ['.', '..']);
        
            foreach ($files as $file) {
                $filePath = $folderPath . '/' . $file;
        
                if (is_dir($filePath)) {
                    deleteFolder($filePath);
                } else {
                    unlink($filePath);
                }
            }
        
            rmdir($folderPath);
        }

 
        //   unlink($folder_path);
           if($this->stage_2_add_employment_model->where('id', $id)->delete()){
                   $delete_folder = true;
           }
        
        }
       if($delete_folder){ 
           
           $callback = array(
                "color" => "success",
                "msg" => "Delete recode",
                "response" => true,
            );
        } else {
            $callback = array(
                "msg" => "unable to delete record",
                "color" => "danger",
                "response" => false,
            );
            }
        echo json_encode($callback);
     
    }
   
// Stage 3 EXEMPTION FILE METHODS 
    public function  upload_exemption_file(){



  $pointer_id = $this->request->getPost('pointer_id');
    $time_zone = $this->request->getPost('time_zone');

    $preference_location = "Online (Via Zoom)";//$this->request->getPost('preference_location');


        $file = $this->request->getFile('exemption_file');

         print_r($file);
       //  exit;

        $uploaded_filename =  $file->getName();

        $File_extention = $file->getClientExtension();

        $original_file_name = str_replace($uploaded_filename, 'Exemption form.' . $File_extention, $uploaded_filename);

        $target = 'public/application/' . $pointer_id . '/stage_2/assessment_documents';
 
        $file->move($target, $original_file_name, true);



        $data = array(


            'exemption_form' => $original_file_name,
            'preference_location'=>$preference_location,
            'time_zone'=>$time_zone
        );
        $update =   $this->stage_3_model->where('pointer_id', $pointer_id)->set($data)->update();


        if($update) {

            $callback = array(

                "color" => "success",

                "msg" => "file uploaded succesfully",

                "response" => true,

                'pointer_id' => $pointer_id,

            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "mail not send",

            //     "color" => "danger",

            //     "response" => false,

            //     'pointer_id' => $pointer_id,

            // );

        }


   

}
    // ---------------admin Application Manager -> exemption file -> exemption file delete ----------------
 public function delete_exemption_file($id)

    {
        $pointer_id=$id;
        //echo $pointer_id;
        $exemption_file=$this->stage_3_model->where('pointer_id', $id)->find();
        // print_r($exemption_file) ;
        //exit;

       $file = $exemption_file[0]['exemption_form'];//$document->document_path . '/' . $document->document_name;

        //unlink($file);
      // $data = array('exemption_form' =>'' );
        $update= $this->stage_3_model->where('pointer_id',$pointer_id)->set(['exemption_form'=>NULL])->update();

        if($update){

            $callback = array(

                "color" => "success",

                "msg" => "Delete recode",

                "response" => true,
            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "unable to delete record",

            //     "color" => "danger",

            //     "response" => false,

            // );

        }


    }
    
    //STAGE 4 EXEMPTION FILE METHODS
    public function  stage4_upload_exemption_file(){



  $pointer_id = $this->request->getPost('pointer_id');
    $time_zone = $this->request->getPost('time_zone');

    $preference_location = "Online (Via Zoom)";//$this->request->getPost('preference_location');


        $file = $this->request->getFile('exemption_file');

         print_r($file);
       //  exit;

        $uploaded_filename =  $file->getName();

        $File_extention = $file->getClientExtension();

        $original_file_name = str_replace($uploaded_filename, 'Exemption form.' . $File_extention, $uploaded_filename);

        $target = 'public/application/' . $pointer_id . '/stage_4/assessment_documents';
 
        $file->move($target, $original_file_name, true);



        $data = array(


            'exemption_form' => $original_file_name,
            'preference_location'=>$preference_location,
            'time_zone'=>$time_zone
        );
        $update =   $this->stage_4_model->where('pointer_id', $pointer_id)->set($data)->update();


        if($update) {

            $callback = array(

                "color" => "success",

                "msg" => "file uploaded succesfully",

                "response" => true,

                'pointer_id' => $pointer_id,

            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "mail not send",

            //     "color" => "danger",

            //     "response" => false,

            //     'pointer_id' => $pointer_id,

            // );

        }


   

}
    // ---------------admin Application Manager -> exemption file -> exemption file delete ----------------
 public function stage_4_delete_exemption_file($id)

    {
        $pointer_id=$id;
        //echo $pointer_id;
        $exemption_file=$this->stage_3_model->where('pointer_id', $id)->find();
        // print_r($exemption_file) ;
        //exit;

       $file = $exemption_file[0]['exemption_form'];//$document->document_path . '/' . $document->document_name;

        //unlink($file);
      // $data = array('exemption_form' =>'' );
        $update= $this->stage_4_model->where('pointer_id',$pointer_id)->set(['exemption_form'=>NULL])->update();

        if($update){

            $callback = array(

                "color" => "success",

                "msg" => "Delete recode",

                "response" => true,
            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "unable to delete record",

            //     "color" => "danger",

            //     "response" => false,

            // );

        }


    }




    // ---------------admin Application Manager -> documents -> documents zip for all stages ----------------
    public function download_zip($pointer_id, $stage)
    {
        $dirs = [];
        $s1_personal_details =  $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $name = $s1_personal_details->first_or_given_name . ' ' . $s1_personal_details->middle_names . ' ' . $s1_personal_details->surname_family_name;
        $all_file_array = array();
        $target = "public/application/" . $pointer_id . '/' . $stage;
        if ($stage == "stage_1") {
            $zip_file = str_replace("stage_1", "Stage 1 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            // $stage_1_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_1'])->findAll();
            $stage_1_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_1'])->whereNotIn('required_document_id', [50])->findAll();
            foreach ($stage_1_documents as $stage_1_document) {
                $single_file_array = array();
                $single_file_array['document_path'] = $stage_1_document->document_path;
                $single_file_array['document_name'] = $stage_1_document->document_name;
                $all_file_array[] = $single_file_array;
            }
        } else if ($stage == "stage_2") {
            $zip_file = str_replace("stage_2", "Stage 2 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            // $stage_2_documents = $this->documents_model->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_2'])->find();
            $stage_2_documents = $this->documents_model->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_2'])->whereNotIn('required_document_id', [52,51])->findAll();

            foreach ($stage_2_documents as $key => $value) {
                 $value['document_path']= $value['document_path'];
                $array_path = explode("/", $value['document_path']);
                if (isset($array_path[4])) {
                    $company_folder_name = $array_path[4];
                    $single_file_array = array();
                    if ($company_folder_name == "assessment_documents") {
                        if($value['required_document_id'] ==16){
                           
                            $company_folder_name = "Supporting evidences for Application Kit";
                           // $value['document_path']=$value['document_path']."/Supporting evidences for Application Kit";

                        }
                        else{
                         $company_folder_name = "Assessment Documents";

                        }
                    }
                    $single_file_array['company_folder_name'] = $company_folder_name;
                    $single_file_array['document_path'] = $value['document_path'];
                    $single_file_array['document_name'] = $value['document_name'];
                    $all_file_array[] = $single_file_array;
                } else {
                    $single_file_array = array();
                    $single_file_array['company_folder_name'] = 'Additional Information';
                    $single_file_array['document_path'] = $value['document_path'];
                    $single_file_array['document_name'] = $value['document_name'];
                    $all_file_array[] = $single_file_array;
                }
            }


            // foreach ($stage_2_documents as $stage_2_document) {
            //     $single_file_array = array();
            //     $single_file_array['document_path'] = $stage_2_document['document_path'];
            //     $single_file_array['document_name'] = $stage_2_document['document_name'];
            //     $all_file_array[] = $single_file_array;
            // }
        } else if ($stage == "stage_3") {
            $zip_file = str_replace("stage_3", "Stage 3 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            $stage_3_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->whereNotIn('required_document_id',[23,24,25,26])->findAll();
            // $stage_3_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->findAll();
            foreach ($stage_3_documents as $stage_3_document) {
                $single_file_array = array();
                $single_file_array['document_path'] = $stage_3_document->document_path;
                $single_file_array['document_name'] = $stage_3_document->document_name;
                $all_file_array[] = $single_file_array;
            }
        } else if ($stage == "stage_4") {
            $zip_file = str_replace("stage_4", "Stage 4 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            // $stage_4_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_4'])->findAll();
            $stage_4_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_4'])->whereNotIn('required_document_id',[45,46,47,48])->findAll();
            foreach ($stage_4_documents as $stage_4_document) {
                $single_file_array = array();
                $single_file_array['document_path'] = $stage_4_document->document_path;
                $single_file_array['document_name'] = $stage_4_document->document_name;
                $all_file_array[] = $single_file_array;
            }
        }

        $zip = new ZipArchive;
        if ($zip->open($zipname, ZIPARCHIVE::CREATE | ZipArchive::OVERWRITE) === false) {
            die("An error occurred creating your ZIP file.");
        } else {
            if ($stage == "stage_2") {
                foreach ($all_file_array as $key => $value) {
                    $path =  $value['document_path'];
                    $document_name =  $value['document_name'];
                    // for folder data 
                    if (isset($value['company_folder_name'])) {
                        $company_folder_name =  $value['company_folder_name'];
                        $zip->addFile($path . "/" . $document_name, $company_folder_name . '/' . $document_name);
                    } else {
                        // for off folder data 
                        $zip->addFile($path . "/" . $document_name, $document_name);
                    }
                } // for loop
            } else {
                //  for stage 1 and stage 3 
                foreach ($all_file_array as $key => $value) {
                    $path =  $value['document_path'];
                    $document_name =  $value['document_name'];
                    if (!str_contains($path, 'Photos_Videos')) {
                        if (!str_contains($document_name, 'PV_')) {
                            // echo $path ."/". $document_name;
                            // echo $document_name;
                            $zip->addFile($path . "/" . $document_name, $document_name);
                        }
                    }
                    if ($stage == "stage_1") {
                        $zip->addFile($path . "/TRA Application Form.pdf", "TRA Application Form.pdf");
                    }
                    if (str_contains($path, 'Photos_Videos')) {
                        if (str_contains($document_name, 'PV_')) {
                            $zip->addFile($path . "/" . $document_name, "Photos_Videos/" . $document_name);
                        }
                    }
                }
            }
            $zip->close();
        }

        $zipname = str_replace("index.php/", "", $zipname);
        echo base_url() . "/" . $zipname;
    }


    // ---------------admin Application Manager -> documents ->stage 1 -> Verification Email - Qualification ---------------
    public function verify_email_stage_1()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $file = $this->request->getFile('file');

        $uploaded_filename =  $file->getName();
        $File_extention = $file->getClientExtension();
        $original_file_name = str_replace($uploaded_filename, 'Verification - Qualification.' . $File_extention, $uploaded_filename);
        $target = 'public/application/' . $pointer_id . '/stage_1';

        $file->move($target, $original_file_name, true);

        $addition_data = array(
            'pointer_id' => $pointer_id,
            'stage' => 'stage_1',
            'required_document_id' => 21,
            'name' => 'Verification - Qualification',
            'document_name' => $original_file_name,
            'document_path' => $target,
            'status' => 1,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' => date("Y-m-d H:i:s")
        );
        if ($this->documents_model->insert($addition_data)) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    
 // --------------- 6 june 2023 akanksha ---------------
    public function check_extra_files(){
    $pointer_id = $this->request->getPost('pointer_id');            
    $extra_files = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'required_document_id' => 50,'stage' => 'stage_1'])->findAll();
        if($extra_files){
            $callback = array(
                "color" => "success",
                "msg" => "file uploaded succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "file not uploaded",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    
    }
    // ---------------admin Application Manager -> documents ->stage 1 ->upload extra file Qualification Verification ---------------
    public function qualification_verification_file()
    {        
        $pointer_id = $this->request->getPost('pointer_id');
        $files = $this->request->getFileMultiple('files');
        
        $database =0;
         $count = 1;
         $pass_data = [];
        if($this->request->getFileMultiple('files')[0]->getName()){
            foreach ($this->request->getFileMultiple('files') as $file){ 
                if ($file && $file->isValid()) {
                    $uploaded_filename =  $file->getName();
                    $File_extention = $file->getClientExtension();
                    $file_name = explode('.',$uploaded_filename);
                    $target = 'public/application/' . $pointer_id . '/stage_1';
                    $file->move($target, $uploaded_filename, true);
                    $addition_data = array(
                        'pointer_id' => $pointer_id,
                        'stage' => 'stage_1',
                        'required_document_id' => 50,
                        'employee_id' => 0,
                        'name' => $file_name[0],
                        'document_name' => $uploaded_filename,
                        'document_path' => $target,
                        'status' => 1,
                        'update_date' => date("Y-m-d H:i:s"),
                        'create_date' => date("Y-m-d H:i:s")
                    );
                    if ($this->documents_model->insert($addition_data)) {
                       $database = 1;
                       $lastInsertedId = $this->documents_model->insertID();
                        // $documentData = $this->documents_model->where('id',$lastInsertedId); // Assuming you have a method in the model to retrieve document data by ID
                        $pass_data[]= [
                        'id' =>$lastInsertedId,
                        'file_path' => $target . "/" . $uploaded_filename,
                        'file_name' => $uploaded_filename
                    ];
                    }
                }
            }
        }
        if ($database >= 1) {
            $callback = array(
                'document_ids'=>$pass_data,
                "color" => "success",
                "msg" => "file uploaded succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "file not uploaded",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    
        
    }
    // ---------------admin Application Manager -> documents ->stage 1 ->upload extra file Qualification Verification end ---------------
    // ---------------admin Application Manager -> documents ->stage 1 ->detete extra file Qualification Verification ----------------
    public function delete_file_qulifiaction_verfication()
    {
        $id = $this->request->getPost('document_id');
        $pass_data = [];
        $document = find_one_row("documents", "id", $id);
        $pointer_id = $document->pointer_id;
        $file = $document->document_path . '/' . $document->document_name;
        if($file){
        unlink($file);
        }
        if ($this->documents_model->where('id', $id)->delete()) {
            // $extra_doc = find_multiple_row_2_field('documents','pointer_id',$pointer_id,'required_document_id',50);
            // // print_r($extra_doc);
            // if($extra_doc){
            //     foreach($extra_doc as $doc){
            //         $pass_data[]= [
            //             'id' =>$doc->id,
            //             'file_path' => $doc->document_path . "/" . $doc->document_name,
            //             'file_name' => $doc->document_name
            //         ];
            //     }    
            // }
            $callback = array(
                'document_id'=>$id,
                "color" => "success",
                "msg" => "Delete recode",
                "response" => true,
            );
        } else {
            $callback = array(
                "msg" => "unable to delete record",
                "color" => "danger",
                "response" => false,
            );
        }
        echo json_encode($callback);
    }
    
    // ---------------admin Application Manager -> documents ->stage 1 ->Send Email Qualification Verification ---------------
    public function qualification_verification_form()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $prn =portal_reference_no($pointer_id);
        $email_to = $this->request->getPost('email');
        $email_cc = $this->request->getPost('email_cc');
        $post_document_ids = $this->request->getPost('document_ids');
        // $file = $this->request->getFile('extra_file');
        // echo $prn;
        // exit;
        $addAttachment = [];
        // echo "SDSfds";
        $array_documnet_id = [];
        if($post_document_ids){
            foreach($post_document_ids as $document_id){
               $array_documnet_id[] = $document_id;
            }
        }
            // echo "fdzd";
            // if($file['error'] === UPLOAD_ERR_OK) {
        // if ($file && $file->isValid()) {

        // // if($file){
        //     // echo "sdvgdv";
        //     $uploaded_filename =  $file->getName();
        //     $File_extention = $file->getClientExtension();
        //     // $original_file_name = str_replace($uploaded_filename, 'Verification - Employment.' . $File_extention, $uploaded_filename);
        //     $target = 'public/application/' . $pointer_id . '/stage_1';
    
        //     $file->move($target, $uploaded_filename, true);
            
        //     $addition_data = array(
        //         'pointer_id' => $pointer_id,
        //         'stage' => 'stage_1',
        //         'required_document_id' => 50,
        //         'employee_id' => 0,
        //         'name' => 'Extra file with email qualification',
        //         'document_name' => $uploaded_filename,
        //         'document_path' => $target,
        //         'status' => 1,
        //         'update_date' => date("Y-m-d H:i:s"),
        //         'create_date' => date("Y-m-d H:i:s")
        //     );
        //     if ($this->documents_model->insert($addition_data)) {
        //         $lastInsertedId = $this->documents_model->insertID();
        //         // echo "Last inserted ID: " . $lastInsertedId;
        //         $array_documnet_id[] =  $lastInsertedId;
        //         $addAttachment[] =
        //             [
        //                 'file_path' => $target . "/" . $uploaded_filename,
        //                 'file_name' => $uploaded_filename
        //             ];
        //     }
            
        // }
        $user = find_one_row('application_pointer', 'id', $pointer_id);

        // email send data ------------
        $mail_temp_1 = $this->mail_template_model->asObject()->where(['id' => '149'])->first();
        $mail_subject = mail_tag_replace($mail_temp_1->subject, $pointer_id);
        $mail_body = mail_tag_replace($mail_temp_1->body, $pointer_id);
        $mail_check = 0;
        $database_check = 0;
            // email send ------------
            $subject = str_replace('%PRN%', $prn, $mail_subject);
            $message = $mail_body;
            $to = $email_to;
            if (isset($post_document_ids)) {
                foreach ($post_document_ids as $post_doc_id) {
                    $document = $this->documents_model->asObject()->where(['id' => $post_doc_id, 'stage' => 'stage_1'])->first();
                    if (!empty($document)) {
                        $document_name = $document->document_name;
                        $document_path = $document->document_path;
                        $file_name = $document->name;
                        if (file_exists($document_path . "/" . $document_name)) {
                            $addAttachment[] =
                            [
                                'file_path' => $document_path . "/" . $document_name,
                                'file_name' => $document_name
                            ];
                        }
                    }
                }
            }
            $extra_files = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'required_document_id' => 50,'stage' => 'stage_1'])->findAll();
            foreach ($extra_files as $extra_file) {
                if (!empty($extra_file)) {
                    $document_name = $extra_file->document_name;
                    $document_path = $extra_file->document_path;
                    $file_name = $extra_file->name;
                    if (file_exists($document_path . "/" . $document_name)) {
                    $array_documnet_id[] = $extra_file->id;
                        $addAttachment[] =
                        [
                            'file_path' => $document_path . "/" . $document_name,
                            'file_name' => $document_name
                        ];
                    }
                }
            }
            $fix_document = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'required_document_id' => 6])->first();
            if (!empty($fix_document)) {
                $document_name = $fix_document->document_name;
                $document_path = $fix_document->document_path;
                $file_name = $fix_document->name;
                if (file_exists($document_path . "/" . $document_name)) {
                    $array_documnet_id[] = $fix_document->id;
                    $addAttachment[] = [
                        'file_path' => $document_path . "/" . $document_name,
                        'file_name' => $document_name
                    ];
                }
            }
            // print_r($array_documnet_id);
            // $result .= implode(', ', $array1);

            $string_documnet_ids = implode(', ', $array_documnet_id);
            $string_email_cc = implode(', ', $email_cc);
            $array_cc = explode(", ", $string_email_cc);  // Convert string to array
            $uniqueArray_cc = array_unique($array_cc);  // Remove duplicates from the array
            $unique_string_email_cc = implode(", ", $uniqueArray_cc);  // Convert array back to a string
            
            if(empty($string_email_cc)){
                // echo "fhfdh";
                $uniqueArray_cc = [];
            }
           
            $check = verification_(env('SERVER_EMAIL'), env('verification_SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], $uniqueArray_cc, $addAttachment);
            $database_entry = 0;
            if ($check == 1) {
                $data_verf = array(
                    'pointer_id' => $pointer_id,
                    'verification_type' => 'Verification - Qualification',
                    'verification_email_id' => $email_to,
                    'verification_email_subject' => $subject,
                    'email_cc_id'=>$unique_string_email_cc,
                    'verification_email_send' => 1,
                    'document_ids' => $string_documnet_ids,
                    'verification_email_send_date' => date("Y-m-d H:i:s"),
                    'update_date' => date("Y-m-d H:i:s"),
                    'create_date' => date("Y-m-d H:i:s")
                );
                // print_r($data_verf);
                // exit;
                if ($this->email_verification_model->insert($data_verf)) {
                    $database_entry = 1;
                }
            }// check email send
            if($database_entry ==1){
                $callback = array(
                    'mail_check' => $check,
                    'database_check' => $database_entry,
                    "color" => "success",
                    "msg" => "mail send succesfully",
                    "response" => true,
                    'pointer_id' => $pointer_id,
                );
            } else {
                $callback = array(
                    "msg" => "mail not send",
                    "color" => "danger",
                    "response" => false,
                    'pointer_id' => $pointer_id,
                );
            }
        echo json_encode($callback);
    }
    
    public function edit_passpost_photo(){
        $pointer_id = $this->request->getPost('pointer_id');
        $document_id = $this->request->getPost('document_id');
        $document_old_name = $this->request->getPost('document_old_name');
        // echo "pointer_id".$pointer_id;
        // echo "document_id".$document_id;
        // echo "document_old_name".$document_old_name;
        // $required_id = $this->request->getPost('required_id');
        // $doc_name = $this->request->getPost('doc_name');
        $file = $this->request->getFile('file');
        
        $required_doc = find_one_row('required_documents_list','id',1);
        $database = 0;
        // if ($file && $file->isValid()) {
            $uploaded_filename =  $file->getName();
            $File_extention = $file->getClientExtension();
            $target = 'public/application/' . $pointer_id . '/stage_1';
            $original_file_name = str_replace($uploaded_filename, $required_doc->document_name.'.' . $File_extention, $uploaded_filename);
            $old_file = $target . '/' . $document_old_name;
            // if($document_old_name){
                unlink($old_file);
            // }
            $file->move($target, $original_file_name, true);

            $addition_data = array(
                'document_name' => $original_file_name,
                'status' => 1,
                'update_date' => date("Y-m-d H:i:s"),
            );
            // $this->stage_1_model->where(['pointer_id' => $pointer_id])->set(['allocate_team_member_name' => $team_id])->update();
                    // $update = $this->stage_3_model->where('pointer_id', $pointer_id)->set($data)->update();
            $update = $this->documents_model->where('id',$document_id)->set($addition_data)->update();
            if ($update) {
                // print_r($update);
            $callback = array(
                "color" => "success",
                "msg" => "file uploaded succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "file not uploaded",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    
    }
   
    // attc
    // ---------------admin Application Manager -> documents ->stage 2 -> Send -> Email to All Employees ---------------
    public function send_email_employ_stage_2()
    {
        
        $pointer_id = $this->request->getPost('pointer_id');
        $user = find_one_row('application_pointer', 'id', $pointer_id);

        // email send data ------------
        // s2_send_email_employee
        // $mail_temp_1 = $this->mail_template_model->asObject()->where(['id' => '45'])->first();
        $mail_temp_1 = $this->mail_template_model->asObject()->where(['id' => '102'])->first();
        $mail_subject = mail_tag_replace($mail_temp_1->subject, $pointer_id);
        $mail_body = mail_tag_replace($mail_temp_1->body, $pointer_id);
        $employes = find_multiple_rows('stage_2_add_employment', 'pointer_id', $pointer_id);
        $mail_check = 0;
        $database_check = 0;
        foreach ($employes as $employe) {
            // email send ------------
            $subject = str_replace('%add_employment_company_name%', $employe->company_organisation_name, $mail_subject);
            $message = str_replace('%add_employment_referee_name%', $employe->referee_name, $mail_body);
            $to = $employe->referee_email;
            $employe_id = $employe->id;
            $check_exist =    $this->email_verification_model->where(['verification_email_send' => 1, 'pointer_id' => $pointer_id, 'employer_id' => $employe->id])->first();
            if (empty($check_exist)) {
                $documents = $this->documents_model->asObject()->where(['employee_id' => $employe_id, 'pointer_id' => $pointer_id, 'required_document_id' => 10])->first();
                $addAttachment = [];
                if (!empty($documents)) {
                    $document_name = $documents->document_name;
                    $document_path = $documents->document_path;
                    $file_name = $documents->name;
                    if (file_exists($document_path . "/" . $document_name)) {
                        $addAttachment = array(
                            [
                                'file_path' => $document_path . "/" . $document_name,
                                'file_name' => $document_name
                            ]
                        );
                    }
                }
                $document_2 = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'required_document_id' => 6])->first();
                    if (!empty($document_2)) {
                        $document_name = $document_2->document_name;
                        $document_path = $document_2->document_path;
                        $file_name = $document_2->name;
                        if (file_exists($document_path . "/" . $document_name)) {
                            $addAttachment[] = [
                                'file_path' => $document_path . "/" . $document_name,
                                'file_name' => $document_name
                            ];
                        }
                    }
                
                $check = verification_(env('SERVER_EMAIL'), env('verification_SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], [], $addAttachment);
                // echo $check;
                // exit;
                if ($check == 1) {
                    $mail_check++;
                    $data = array(
                        'pointer_id' => $pointer_id,
                        'verification_type' => 'Verification - Employment',
                        'employer_id' => $employe->id,
                        'verification_email_id' => $employe->referee_email,
                        'verification_email_subject' => $subject,
                        'verification_email_send' => 1,
                        'verification_email_send_date' => date("Y-m-d H:i:s"),
                        'update_date' => date("Y-m-d H:i:s"),
                        'create_date' => date("Y-m-d H:i:s")
                    );

                    if ($this->email_verification_model->insert($data)) {
                        $database_check++;
                    }
                } // check email send
            }
        } // loop

        // echo $mail_check;
        // echo $database_check;
        // exit;
        if ($mail_check > 0 || $database_check > 0) {
            $callback = array(
                'mail_check' => $mail_check,
                'database_check' => $database_check,
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    // attc

    // ---------------admin Application Manager -> documents ->stage 2 -> Verification Email - Employment ---------------
    public function verify_email_stage_2()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $file = $this->request->getFile('file');

        $uploaded_filename =  $file->getName();
        $File_extention = $file->getClientExtension();
        $original_file_name = str_replace($uploaded_filename, 'Verification - Employment.' . $File_extention, $uploaded_filename);
        $target = 'public/application/' . $pointer_id . '/stage_2/assessment_documents';

        $file->move($target, $original_file_name, true);
        
        $addition_data = array(
            'pointer_id' => $pointer_id,
            'stage' => 'stage_2',
            'required_document_id' => 22,
            'employee_id' => 0,
            'name' => 'Verification - Employment',
            'document_name' => $original_file_name,
            'document_path' => $target,
            'status' => 1,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' => date("Y-m-d H:i:s")
        );
        // print_r($addition_data);
        // exit;
        if ($this->documents_model->insert($addition_data)) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    // ---------------admin Applicant and Agent -> applicant name or agent company name -> Application Manager filter by user id---------------
    public function filter_company($id)
    {

        $user_id = $id;

        $data['page_name'] = 'Application Manager';

        $status_list = ['Start', 'Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined', 'Withdrawn', 'Expired'];

        $all_list = array();
        $application_pointer_model = $this->application_pointer_model->asObject()->orWhereIn('status', $status_list)->where("user_id", $user_id)->orderby('create_date', 'DESC')->findAll();

        $i = 0;
        $aaa = array();
        foreach ($application_pointer_model as $stage) {

            $show = true;
            if ($stage->stage == "stage_1") {
                if ($stage->status == "Start") {
                    $show = false;
                }
            }
            if ($show) {
                $i++;
                $asdasd = $stage->stage . " " . $stage->status;
                if (!in_array($asdasd, $aaa)) {

                    $aaa[] = $asdasd;
                }



                $list_array = array();

                $pointer_id = $stage->id;
                $list_array['pointer_id'] = $pointer_id;
                $list_array['unique_id'] = application_mo($pointer_id);
                $list_array['portal_reference_no'] = portal_reference_no($pointer_id);

                $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['Applicant_name'] =   $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name;


                $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
                $Pathway =  (isset($s1_occupation->pathway) ? $s1_occupation->pathway : "");
                if ($Pathway == "Pathway 2") {
                    $list_array['Pathway'] = 'p2';
                } else {
                    $list_array['Pathway'] = 'p1';
                }
                $occupation_list = find_one_row('occupation_list', 'id', $s1_occupation->occupation_id);
                $list_array['occupation_name'] =  (isset($occupation_list->name) ? $occupation_list->name : "");

                $stage_1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['date_of_birth'] =  (isset($stage_1_personal_details->date_of_birth) ? $stage_1_personal_details->date_of_birth : "");

                $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
                $stage_index = application_stage_no($pointer_id);
                if($Pathway == "Pathway 1"){
                    if($list_array['occupation_name']=="Electrician (General)"||$list_array['occupation_name']=="Plumber (General)"){
                                    $list_array['Current_Status'] =create_status_format($stage_index);

                }
                }
                else{
                                    $list_array['Current_Status'] =  create_status_rename(create_status_format($stage_index), $user_id);

                    
                }
                

                if (create_status_format($stage_index) == 'S2 - Start') {
                    $stage_status = 'S1 - ' . $stage->status;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $stage_status = 'S2 - ' . find_one_row('stage_2', 'pointer_id', $stage->id)->status;
                } else {
                    $stage_status = create_status_format($stage_index);
                }
                $list_array['application_status'] =  substr($stage_status, 0, 2);



                $stage_ = explode(" ", create_status_format($stage_index));

                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S2') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S3') {
                    // $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else {
                    // $get_submit_date = (isset(find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date)) ? find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date : "";
                    $get_submit_date =  $stage_1->submitted_date;
                }
                if (!empty($get_submit_date)) {
                    $list_array['submitted_date'] = $get_submit_date;
                    $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
                } else {
                    $list_array['submitted_date'] =  "";
                    $list_array['submitted_date_format'] =  "";
                }



                $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $pointer_id);
                $list_array['additional_info_request'] =  $additional_info_request;

                $all_list[] = $list_array;
            }
        }


        $data['all_list'] = $all_list;


        return view('admin/application_manager/index', $data);
    }

    public function save_Assigned_Team_Member($pointer_id)
    {
        if (!empty($pointer_id)) {
            $team_id = $_POST['selectedValue'];
            echo $this->stage_1_model->where(['pointer_id' => $pointer_id])->set(['allocate_team_member_name' => $team_id])->update();
        }
    }
    public function exemption_form($pointer_id)
    
    {
        $data['title'] = "exemption form";
         return view('admin/application_manager/exemption_form', $data);

    }
    
}
