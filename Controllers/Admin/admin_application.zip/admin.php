<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class admin extends BaseController
{

    public function stage_3_date_vishal()
    {
        echo "<pre>";
        $stage_3 = $this->stage_3_model->asObject()->find();
        foreach ($stage_3 as $key => $value) {
            $status = $value->status;

            $in_progress_date = '0000-00-00 00:00:00';
            $lodged_date = $value->lodged_date;
            $approved_date = $value->approved_date; if($stage_[0] == 'S4'){
                    $get_submit_date = find_one_row('stage_4', 'pointer_id', $pointer_id)->lodged_date;
                }
            $declined_date = $value->declined_date;
            if ($status == "Submitted") {
                $declined_date =  $approved_date =  $lodged_date = '0000-00-00 00:00:00';
            } elseif ($status == "Lodged") {
                $declined_date =  $approved_date   = '0000-00-00 00:00:00';
            } elseif ($status == "Approved") {
                $declined_date  = '0000-00-00 00:00:00';
            }
            print_r($value);

            echo "<br>" . $lodged_date;
            echo "<br>" . $in_progress_date;
            echo "<br>" . $approved_date;
            $pointer_id = $value->pointer_id;
            echo $this->stage_3_model->where(['pointer_id' => $pointer_id])->set(['lodged_date' => $lodged_date, 'in_progress_date' => $in_progress_date, 'approved_date' => $approved_date])->update();
            echo "<hr>";
        }
    }
    // -------------- dashboard ----------------

    public function dashboard()
    {
        $show_oly = "Submitted";
        $stage_only = "";
        if (session()->get('admin_account_type') == 'admin') {
            $show_oly = "Submitted";
            $stage_only = ['stage_1','stage_2','stage_3','stage_4'];
        } else if (session()->get('admin_account_type') == 'head_office') {
            $show_oly = "Lodged";
            $stage_only = ['stage_1','stage_2'];
        } else {
            // $this->session->destroy();
            return redirect()->to(base_url('admin/logout'));
        }

        $data['application_pointers'] = $this->application_pointer_model->asObject()->where('status',$show_oly)->whereIn('stage', $stage_only)->orderby('update_date', 'ASC')->findAll();

        $all_list = array();
        $application_pointer_model = $this->application_pointer_model->asObject()->where('status',$show_oly)->whereIn('stage', $stage_only)->orderby('update_date', 'ASC')->findAll();
        foreach ($application_pointer_model as $stage) {
            $list_array = array();

            $pointer_id = $stage->id;
            $list_array['pointer_id'] = $pointer_id;
            $list_array['unique_id'] = application_mo($pointer_id);
            $list_array['portal_reference_no'] = portal_reference_no($pointer_id);

            $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
            $list_array['Applicant_name'] =  "";
            if (!empty($s1_personal_details)) {
                $list_array['Applicant_name'] =   $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name;
            } else {
                // echo "pointer : " . $pointer_id . "<br>";
                // echo "stage_1_personal_details is empty  <br>";
                // exit;
            }

            $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
            $occupation_list = find_one_row('occupation_list', 'id', $s1_occupation->occupation_id);
            $list_array['occupation_name'] =  $occupation_list->name;

            $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
            $stage_index = application_stage_no($pointer_id);

            if (create_status_format($stage_index) == 'S2 - Start') {
                $stage_status = 'S1 - ' . $stage->status;
            } else if (create_status_format($stage_index) == 'S3 - Start') {
                $stage_status = 'S2 - ' . find_one_row('stage_2', 'pointer_id', $stage->id)->status;
            } else {
                $stage_status = create_status_format($stage_index);
            }
            $list_array['application_status'] =  substr($stage_status, 0, 2);


            if (session()->get('admin_account_type') == 'head_office') {

                $stage_ = explode(" ", create_status_format($stage_index));
                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->lodged_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->lodged_date;
                } else if ($stage_[0] == 'S2') {
                    $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->lodged_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->lodged_date;
                } else if ($stage_[0] == 'S3') {
                    $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->lodged_date;
                } else if($stage_[0] == 'S4'){
                    $get_submit_date = find_one_row('stage_4', 'pointer_id', $pointer_id)->lodged_date;
                }
                $list_array['submitted_date'] = $get_submit_date;
                $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
            } else {

                $stage_ = explode(" ", create_status_format($stage_index));
                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S2') {
                    $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                } else if ($stage_[0] == 'S3') {
                    $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date;
                }  else if($stage_[0] == 'S4'){
                    $get_submit_date = find_one_row('stage_4', 'pointer_id', $pointer_id)->submitted_date;
                }
                $list_array['submitted_date'] = $get_submit_date;
                $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
            }


            $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $pointer_id);
            $list_array['additional_info_request'] =  $additional_info_request;

            $all_list[] = $list_array;
        }


        $data['all_list'] = $all_list;




        return view('admin/dashboard', $data);
    }
    // -------------- dashboard end ----------------

    // -------------- interview_calendar ----------------

    public function  interview_calendar()
    {
        $data['title'] = "interview_calendar";

        return view('admin/interview_calendar/index', $data);
    }
    // -------------- interview_calendar end ----------------

    // -------------- interview_location end ----------------
    // public function interview_location()
    // {
    //     $data['interview_locations'] = $this->stage_3_offline_location_model->asObject()->findAll();
    //     $data['countries'] = $this->country_model->asObject()->findAll();

    //     return view('admin/interview_location/index', $data);
    // }

    // public function update()
    // {
    //     $data = $this->request->getvar();

    //     $id = $data['id'];

    //     $details = array(
    //         'city_name' => $data['city_name'],
    //         'country' => $data['country'],
    //         'venue' => $data['venue'],
    //         'office_address' => $data['office_address'],
    //         'contact_details' => $data['contact_details'],
    //         'reg_date' =>  date("Y-m-d H:i:s")
    //     );
    //     if ($this->stage_3_offline_location_model->update($id, $details)) {
    //         $callback = array(
    //             "color" => "success",
    //             "msg" => "update recode",
    //             "response" => true,
    //         );
    //     } else {
    //         $callback = array(
    //             "msg" => "unable to update record",
    //             "color" => "danger",
    //             "response" => false,
    //         );
    //     }
    //     echo json_encode($callback);
    // }
    // -------------- interview_location end ----------------

    // -------------- interview_booking ----------------
    public function interview_booking()
    {
        $data['interview_bookings'] = $this->stage_3_interview_booking_model->asObject()->findAll();
        $data['countries'] = $this->stage_3_offline_location_model->asObject()->findAll();
        $data['applicants'] = $this->stage_3_model->where('status', 'Lodged')->asObject()->findAll();


        $data['time_zone'] = $this->time_zone_model->groupBy('zone_name')->findAll();

        $data['stage_3_interview_booking_time_slots'] = $this->stage_3_interview_booking_time_slots_model->find();
        return view('admin/interview_booking/index', $data);

        // time_zone
    }

    
    public function get_preference_location()
    {
        $data = "";
        $id = $_POST['id'];
        $stage_3 =  $this->stage_3_model->where('id', $id)->first();
        if (!empty($stage_3)) {
            $data = isset($stage_3['preference_location']) ? $stage_3['preference_location'] : "";
        }
        return $data;
    }
    
    public function get_applicant_location()
    {
        $data = "";
        $id = $_POST['id'];
        $stage_3 =  $this->stage_3_model->where('id', $id)->first();
        if (!empty($stage_3)) {
            $data = isset($stage_3['time_zone']) ? $stage_3['time_zone'] : "";
        }
        return $data;
    }

    public function insert_booking()
    {
        $database_check = 0;
        $database_check_1 = 0;
        $mail_check = 0;

        $stage_3_id = $this->request->getPost("applicant_name_id");
        $location_id = $this->request->getPost("venue");
        // $date = $this->request->getPost("date");


        $date = $_POST['date'];
        $time = $_POST['time'];
        $datetime = \DateTime::createFromFormat('Y-m-d h:i A', $date . ' ' . $time);
        $date = $datetime->format('Y-m-d H:i:s');


        $time_zone = (isset($_POST['time_zone'])) ? $_POST['time_zone'] : "";
        $stage_3 = find_one_row('stage_3', 'id', $stage_3_id);
        $pointer_id = $stage_3->pointer_id;
        $details = array(
            'pointer_id' => $pointer_id,
            'location_id' => $location_id,
            'date_time' => $date,
            'is_booked' => 1,
            'is_temp' => 1,
            'time_zone' => $time_zone,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' =>  date("Y-m-d H:i:s")
        );

        if ($this->stage_3_interview_booking_model->insert($details)) {
            $database_check = 1;
        }
        $application_pointer = find_one_row('application_pointer', 'id', $pointer_id);
        $user_account = find_one_row('user_account', 'id', $application_pointer->user_id);

        $Applicant_email = [];
        $stage_1_contact_details_ = $this->stage_1_contact_details_model->where(['pointer_id' => $pointer_id])->first();
        if (!empty($stage_1_contact_details_)) {
            $Applicant_email[] = $stage_1_contact_details_['email'];
        }

        // print_r($Applicant_email);
        // exit;



        // location_id == 9     Online (Via Zoom)
        if ($location_id == 9) {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") { // Applicant
                // s3_agent_online_scheduled
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '89'])->first();
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                // This is for Exception Online Zoom
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $to = $user_account->email;

                $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], $Applicant_email);
                if ($check == 1) {
                    $mail_check = 1;
                } else {
                    $mail_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                }
            }
            if ($client_type == "Applicant") {

                //s3_online_scheduled_applicant
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '82'])->first();
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $to = $user_account->email;
                $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                if ($check == 1) {
                    $mail_check = 1;
                }
            }


            //s3_admin_online_scheduled checking for 96
            $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '96'])->first();
            $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
            $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
            $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
            $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
            $to = env('ADMIN_EMAIL');
            $check_1 = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            // new add on 04-04-2023 by vishal as par clint call
            $to = env('HEADOFFICE_EMAIL');
            $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            if ($check_1 == 1 && $check == 1) {
                $mail_check = 1;
            }
        } else {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") { // Applicant
                // s3_scheduled_agent
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '36'])->first();
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                // Applicant Email
                $to = $user_account->email;

                $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], $Applicant_email);
                if ($check == 1) {
                    $mail_check = 1;
                } else {
                    $mail_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                }
            }
            if ($client_type == "Applicant") {
                //s3_scheduled_applicant
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '84'])->first();
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $to = $user_account->email;
                $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                if ($check == 1) {
                    $mail_check = 1;
                }
            }

            //s3_scheduled_admin
            $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '98'])->first();
            $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
            $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
            $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
            $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
            $to = env('ADMIN_EMAIL');
            $check_1 = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            // new add on 04-04-2023 by vishal as par clint call
            $to = env('HEADOFFICE_EMAIL');
            $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            if ($check_1 == 1 && $check == 1) {
                $mail_check = 1;
            }
        }

        //database record for mail 3 
        $admin_status = [
            'status' => "Scheduled",
            'scheduled_date' => date("Y-m-d H:i:s"),
            'scheduled_by' => session()->get('admin_id'),
            'update_date' => date("Y-m-d H:i:s")
        ];
        // if ($this->stage_3_model->update($stage_3_id, $admin_status)) {
        if ($this->stage_3_model->where('id', $stage_3_id)->set($admin_status)->update()) {
            $database_check_1 = 1;
        }
        $pointer_data = [
            'stage' => 'stage_3',
            'status' => 'Scheduled',
            'update_date' => date("Y-m-d H:i:s")
        ];
        $this->application_pointer_model->where('id', $pointer_id)->set($pointer_data)->update();
        // $this->application_pointer_model->update($pointer_id, $pointer_data);
        //database record for mail 3 end
        if ($mail_check == 1 || $database_check == 1 || $database_check_1 == 1) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }

    public function update_booking()
    {

        $stage_3_interview_booking_id =  $this->request->getPost('stage_3_interview_booking_id');
        $pointer_id = $this->request->getPost("pointer_id");
        $location_id = $this->request->getPost("venue");
        $time_zone = (isset($_POST['time_zone'])) ? $_POST['time_zone'] : "";

        $date = $_POST['date'];
        $time = $_POST['time'];
        $datetime = \DateTime::createFromFormat('Y-m-d h:i A', $date . ' ' . $time);
        $date = $datetime->format('Y-m-d H:i:s');


        // table 1 update --------------------------------------
        $details = array(
            'pointer_id' => $pointer_id,
            'location_id' => $location_id,
            'date_time' => $date,
            'is_booked' => 1,
            'is_temp' => 1,
            'time_zone' => $time_zone,
            'update_date' => date("Y-m-d H:i:s"),
        );
        // $stage_3_interview_booking_update =  $this->stage_3_interview_booking_model->update($stage_3_interview_booking_id, $details);
        $stage_3_interview_booking_update =  $this->stage_3_interview_booking_model->where('id', $stage_3_interview_booking_id)->set($details)->update();

        // table 2 update --------------------------------------
        $admin_status = [
            'status' => "Scheduled",
            'scheduled_date' => date("Y-m-d H:i:s"),
            'scheduled_by' => session()->get('admin_id'),
            'update_date' => date("Y-m-d H:i:s")
        ];
        // $stage_3_update = $this->stage_3_model->update($stage_3_id, $admin_status);
        $stage_3_update =  $this->stage_3_model->where('pointer_id', $pointer_id)->set($admin_status)->update();


        // table 3 update --------------------------------------
        $pointer_data = [
            'stage' => 'stage_3',
            'status' => 'Scheduled',
            'update_date' => date("Y-m-d H:i:s")
        ];
        $this->application_pointer_model->where('id', $pointer_id)->set($pointer_data)->update();

        $Email_send_check = 0;

        // Email Send ---------------------------------------------------- 
        $application_pointer = find_one_row('application_pointer', 'id', $pointer_id);
        $user_account = find_one_row('user_account', 'id', $application_pointer->user_id);

        $Applicant_email = [];
        $stage_1_contact_details_ = $this->stage_1_contact_details_model->where(['pointer_id' => $pointer_id])->first();
        if (!empty($stage_1_contact_details_)) {
            $Applicant_email[] = $stage_1_contact_details_['email'];
        }



        // location_id == 9     Online (Via Zoom)
        if ($location_id == 9) {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") {
                //   s3_agent_online_rescheduled
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '90'])->first();
                $to = $user_account->email;
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);

                $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], $Applicant_email);
                if ($Email_send_check == 1) {
                    $Email_send_check = 1;
                } else {
                    $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                }
            }

            if ($client_type == "Applicant") {
                //   s3_online_rescheduled_applicant
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '81'])->first();
                $to = $user_account->email;
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                if ($Email_send_check == 1) {
                    $Email_send_check = 1;
                }
            }

            //   s3_admin_online_rescheduled
            $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '97'])->first();
            $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
            $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
            $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
            $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
            $to = env('ADMIN_EMAIL');
            $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            // new add on 04-04-2023 by vishal as par clint call
            $to = env('HEADOFFICE_EMAIL');
            $Email_send_check_2 = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            if ($Email_send_check == 1 && $Email_send_check_2 == 1) {
                $Email_send_check = 1;
            }
        } else {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") {
                //   s3_re_scheduled_agent
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '53'])->first();
                $to = $user_account->email;
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], $Applicant_email);
                if ($Email_send_check == 1) {
                    $Email_send_check = 1;
                } else {
                    $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                }
            }

            if ($client_type == "Applicant") {
                //   s3_rescheduled_applicant
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '83'])->first();
                $to = $user_account->email;
                $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
                $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
                $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
                $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
                $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                if ($Email_send_check == 1) {
                    $Email_send_check = 1;
                }
            }

            //   s3_scheduled_admin
            $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '98'])->first();
            $subject = mail_tag_replace($mail_temp_3->subject, $pointer_id);
            $day_time = mail_tag_replace($mail_temp_3->body, $pointer_id);
            $get_slot_time = str_replace('%s3_interview_day_and_date%', date('Y-m-d', strtotime($date)), $day_time);
            $message = str_replace('%s3_interview_time%', date('H:i', strtotime($date)), $get_slot_time);
            $to = env('ADMIN_EMAIL');
            $Email_send_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            // new add on 04-04-2023 by vishal as par clint call
            $to = env('HEADOFFICE_EMAIL');
            $Email_send_check_2 = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            if ($Email_send_check == 1 && $Email_send_check_2 == 1) {
                $Email_send_check = 1;
            }
        }


        //database record for mail 3 end
        if ($Email_send_check || $stage_3_interview_booking_update && $stage_3_update) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    // -------------- interview_booking end ----------------

    // akanksha 19 june 2023
    public function File_update_stage_2()
    {
        if (isset($_POST['file_upload_name'])) {
            $file_upload_name  = $_POST['file_upload_name'];
            $pointer_id  = $_POST['pointer_id'];
            if (!empty($file_upload_name) && !empty($pointer_id)) {
                if (isset($_FILES['file'])) {
                    $s1_personal_details = $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
                    $name = $s1_personal_details->first_or_given_name;
                    $target_file =  'public/application/' . $pointer_id . '/stage_2/approved';
                    $file  = $_FILES['file'];
                    $file  = $this->request->getFile('file');
                    $Files = $file->getName();
                    if (!empty($Files)) {
                        $file_extension = explode(".", $Files);
                        $file_extension = $file_extension[count($file_extension) - 1];
                        $target_file =  'public/application/' . $pointer_id . '/stage_2/declined';
                        $file_name = $Files;  // temp
                        $user_view_name = ""; // temp
                        $required_document_id = ""; // temp
                        if ($file_upload_name == "outcome_file") { 
                            $file_name = 'Skills Assessment Result - '.$name.'.'. $file_extension;
                            // $file_name = 'Unsuccessful_outcome_letter.' . $file_extension;
                            $required_document_id = 52;
                            $user_view_name = 'Skills Assessment Result';
                        } else if ($file_upload_name == "reason_file") {  
                            $file_name = 'Statement Of Reason - '.$name.'.'. $file_extension;
                            // $file_name = 'Statement_of_reason.' . $file_extension;
                            $required_document_id = 53;
                            $user_view_name = 'Statement Of Reason';
                        }
                        // echo $file_upload_name;
                        // echo $file_name;
                        // echo $required_document_id;
                        // echo $user_view_name;
                        // exit;
                        if ($file->move($target_file, $file_name, true)) {
                            if (!empty($user_view_name) && !empty($required_document_id)) {
                                $data = array(
                                    'pointer_id' => $pointer_id,
                                    'stage' => 'stage_2',
                                    'required_document_id' => $required_document_id,
                                    'name' => $user_view_name,
                                    'document_name' => $file_name,
                                    'document_path' => $target_file,
                                    'status' => 1,
                                    'update_date' => date("Y-m-d H:i:s"),
                                    // 'create_date' => date("Y-m-d H:i:s")
                                );
                                $check_documents_model = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->first();
                                if (empty($check_documents_model)) {
                                    // insert 
                                    if ($this->documents_model->insert($data)) {
                                        echo "ok";
                                    }
                                } else {
                                    // update
                                    if ($this->documents_model->set($data)->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->update()) {
                                        echo "ok";
                                    }
                                }
                            } else {
                                echo "data missing doc id and pointer";
                            }
                        } else {
                            echo "sorry file not move";
                        }
                    } // file not empty
                } // isset file 
            }
        }
    }
    
    // vishal patel 26/04/2023 update akanksha 19 june 2023
    // stage 3 file upload withaut mail   
    // stage 3 file upload withaut mail   
    public function File_update_stage_3()
    {
        // vishal patel 26/04/2023
        if (isset($_POST['file_upload_name'])) {
            $file_upload_name  = $_POST['file_upload_name'];
            $pointer_id  = $_POST['pointer_id'];
            if (!empty($file_upload_name) && !empty($pointer_id)) {
                if (isset($_FILES['file'])) {
                    $s1_personal_details = $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
                    $name = $s1_personal_details->first_or_given_name;
                    $target_file =  'public/application/' . $pointer_id . '/stage_3/approved';
                    $file  = $_FILES['file'];
                    $file  = $this->request->getFile('file');
                    $Files = $file->getName();
                    // akanksha 19 june 2023
                    if (!empty($Files)) {
                        $file_extension = explode(".", $Files);
                        $file_extension = $file_extension[count($file_extension) - 1];
                        $file_name = $Files;  // temp
                        $user_view_name = ""; // temp
                        $required_document_id = ""; // temp
                        if ($file_upload_name == "upload_qualification_file") {
                            $file_name = 'Qualification letter -' . $name . "." . $file_extension;
                            $required_document_id = 26;
                            $user_view_name = 'Qualification letter';
                        } else if ($file_upload_name == "upload_outcome_file" || $file_upload_name == "upload_outcome_file") {
                            $file_name = 'Skills Assessment Result - ' . $name . "." . $file_extension;
                            $required_document_id = 25;
                            $user_view_name = 'Skills Assessment Result';
                        } else if ($file_upload_name == "outcome_file") { // <!-- // vishal patel 27-04-2023  -->
                            $target_file =  'public/application/' . $pointer_id . '/stage_3/declined';
                            $file_name = 'Skills Assessment Result - '. $name . "." . $file_extension;
                            $required_document_id = 23;
                            $user_view_name = 'Skills Assessment Result';
                        } else if ($file_upload_name == "reason_file") {   // <!-- // vishal patel 27-04-2023  -->
                            $target_file =  'public/application/' . $pointer_id . '/stage_3/declined';
                            $file_name = 'Statement Of Reason - ' . $name . "." . $file_extension;
                            $required_document_id = 24;
                            $user_view_name = 'Statement Of Reason';
                        }
                        if ($file->move($target_file, $file_name, true)) {
                            if (!empty($user_view_name) && !empty($required_document_id)) {
                                $qualification_data = array(
                                    'pointer_id' => $pointer_id,
                                    'stage' => 'stage_3',
                                    'required_document_id' => $required_document_id,
                                    'name' => $user_view_name,
                                    'document_name' => $file_name,
                                    'document_path' => $target_file,
                                    'status' => 1,
                                    'update_date' => date("Y-m-d H:i:s"),
                                    'create_date' => date("Y-m-d H:i:s")
                                );
                                $check_documents_model = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->first();
                                if (empty($check_documents_model)) {
                                    // insert 
                                    if ($this->documents_model->insert($qualification_data)) {
                                        echo "ok";
                                    }
                                } else {
                                    // update
                                    if ($this->documents_model->set($qualification_data)->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->update()) {
                                        echo "ok";
                                    }
                                }
                            } else {
                                echo "data missing doc id and pointer";
                            }
                        } else {
                            echo "sorry file not move";
                        }
                    } // file not empty
                } // isset file 
            }
        }
    }
    
    
    // Mohsin -> 2 Jun 2023 update akanksha 19 june 2023
    // stage 4 file upload withaut mail   
    public function File_update_stage_4()
    {
        if (isset($_POST['file_upload_name'])) {
            $file_upload_name  = $_POST['file_upload_name'];
            $pointer_id  = $_POST['pointer_id'];
            if (!empty($file_upload_name) && !empty($pointer_id)) {
                if (isset($_FILES['file'])) {
                    $s1_personal_details = $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
                    $name = $s1_personal_details->first_or_given_name;
                    $target_file =  'public/application/' . $pointer_id . '/stage_4/approved';
                    $file  = $_FILES['file'];
                    $file  = $this->request->getFile('file');
                    $Files = $file->getName();
                    // akanksha 19 june 2023
                    if (!empty($Files)) {
                        $file_extension = explode(".", $Files);
                        $file_extension = $file_extension[count($file_extension) - 1];
                        $file_name = $Files;  // temp
                        $user_view_name = ""; // temp
                        $required_document_id = ""; // temp
                        if ($file_upload_name == "upload_qualification_file") {
                            $file_name = 'OTSR'.$name.'.' . $file_extension;
                            $required_document_id = 48;
                            $user_view_name = 'OTSR';
                        } else if ($file_upload_name == "upload_outcome_file" || $file_upload_name == "upload_outcome_file") {
                            $file_name = 'Pratical Assessment Result - ' . $name . "." . $file_extension;
                            $required_document_id = 47;
                            $user_view_name = 'Skills Assessment Result';
                        } else if ($file_upload_name == "outcome_file") { 
                            $target_file =  'public/application/' . $pointer_id . '/stage_4/declined';
                            $file_name = 'Skills Assessment Result - '.$name.'.'. $file_extension;
                            $required_document_id = 45;
                            $user_view_name = 'Skills Assessment Result';
                        } else if ($file_upload_name == "reason_file") {  
                            $target_file =  'public/application/' . $pointer_id . '/stage_4/declined';
                            $file_name = 'Statement Of Reason - ' . $name . "." . $file_extension;
                            $required_document_id = 46;
                            $user_view_name = 'Statement Of Reason';
                        }

                        if ($file->move($target_file, $file_name, true)) {
                            if (!empty($user_view_name) && !empty($required_document_id)) {
                                $qualification_data = array(
                                    'pointer_id' => $pointer_id,
                                    'stage' => 'stage_4',
                                    'required_document_id' => $required_document_id,
                                    'name' => $user_view_name,
                                    'document_name' => $file_name,
                                    'document_path' => $target_file,
                                    'status' => 1,
                                    'update_date' => date("Y-m-d H:i:s"),
                                    'create_date' => date("Y-m-d H:i:s")
                                );
                                $check_documents_model = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->first();
                                if (empty($check_documents_model)) {
                                    // insert 
                                    if ($this->documents_model->insert($qualification_data)) {
                                        echo "ok";
                                    }
                                } else {
                                    // update
                                    if ($this->documents_model->set($qualification_data)->where(['pointer_id' => $pointer_id, 'required_document_id' => $required_document_id])->update()) {
                                        echo "ok";
                                    }
                                }
                            } else {
                                echo "data missing doc id and pointer";
                            }
                        } else {
                            echo "sorry file not move";
                        }
                    } // file not empty
                } // isset file 
            }
        }
    }
}
