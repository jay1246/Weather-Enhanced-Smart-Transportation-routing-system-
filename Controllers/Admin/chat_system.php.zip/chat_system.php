<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use stdClass;

use DateTimeZone;
use DateTime;

class chat_system extends BaseController
{

function chat_system(){
    
    //print_r($_POST);
     //$this->chat_system
     $chat=$this->request->getVar('chat');
     $reply_id=$this->request->getVar('reply_id');
     $reply_msg=$this->request->getVar('reply_msg_update');
     $admin_id=$this->request->getVar('admin_id');
     $reply_user_name=$this->request->getVar('reply_user_name');
     $admin_ac = $this->admin_account_model->where('id', $admin_id)->get()->getRow();
     $user_name = $admin_ac->first_name.$admin_ac->last_name_chat;
     $reply_color=$this->request->getVar('reply_color');
     $color=$admin_ac->color; 
    $insert_data=[
        'message'=>$chat,
        'user_id'=>$admin_id,
        'user_name'=>$user_name,
        'reply_id'=>$reply_id,
        'reply_msg'=>$reply_msg,
        'reply_user_name'=>$reply_user_name,
        'reply_color'=>$reply_color,
        'color'=>$color,
        'created_at'=>date('Y-m-d-H-i'),
        'updated_at'=>date('Y-m-d-H-i')
        ];
    $insert=$this->chat_system->insert($insert_data);
    $lastQuery = $this->chat_system->getLastQuery();
    if($insert){
    
     $data = [
            'response' => 1
        ];

        echo $jsonResponse = json_encode($data);
    
}
}
function chat_system_fetch(){
    
$offset_ = $this->request->getPost("userTimezone");

$record_fetch = $this->request->getPost("record_fetch");
$offset_record = $this->request->getPost("offset_record");
$single_record = $this->request->getPost("single_record");
$timezone = new DateTimeZone($offset_);
$date = new DateTime('now', $timezone);
//echo 'Current time in ' . $offset_ . ': ' . $date->format('Y-m-d H:i:s');
$data = $this->chat_system->limit($record_fetch, $offset_record)->orderBy('id', 'DESC')->find();
if(isset($single_record)){
    $data = $this->chat_system->limit(1)->orderBy('id', 'DESC')->find();
}

// echo $this->chat_system->getLastQuery();
// exit;
$json = [];
$last_data=null;
//$item=['label']="";
foreach ($data as $key => $item) {
    $createdDate = new DateTime($item['created_at']);
    $createdDate->setTimezone($timezone);
    $new_date = $createdDate->format('Y-m-d H:i:s');
    $item['created_at'] = $new_date;
    
    //for give check labels today and tomorrow
    $currentDate = new DateTime('now', $timezone);
    $currentDateFormatted = $currentDate->format('Y-m-d H:i:s');
    $interval = $createdDate->diff($currentDate);
    $daysDifference = $interval->days;
    
    if ($daysDifference === 0) {
         $item['date_label']="Today";
    } elseif ($daysDifference === 1) {
        $item['date_label']="Yesterday";
    } else {
        $item['date_label']=$createdDate->format('M j Y');
    }
    
    array_push($json, $item);
}

$last_data = end($json);

$last_id = '';
if ($last_data !== null && is_array($last_data)) {
    $last_id = isset($last_data['id']) ? $last_data['id'] - 1 : '';
} else {
    // Handle the case where $last_data is not an array or is null
}

//--------

$data_last = $this->chat_system->where('id',$last_id)->first();
//print_r($data_last);
if($data_last !== null){
$data_last_created_at =new DateTime($data_last['created_at']); 
$data_last_created_at->setTimezone($timezone);
$data_last_created_at_format=$data_last_created_at->format('M j Y');
//$data_last_created_at_format;
  //--------
    $currentDate = new DateTime('now', $timezone);
    $currentDateFormatted = $currentDate->format('Y-m-d H:i:s');
    $interval = $data_last_created_at->diff($currentDate);
    $daysDifference = $interval->days;

  if($daysDifference === 0) {
         $data_last_created_at_format="Today";
    } elseif ($daysDifference === 1) {
        $data_last_created_at_format="Yesterday";
    } else {
       $data_last_created_at_format=$data_last_created_at_format;
    }
//echo $data_last_created_at_format;
$modified_json = [];
foreach($json as $json_){
    //echo $json_["date_label"]."-->".$data_last_created_at_format;
    if($json_["date_label"] === $data_last_created_at_format){
        $json_['date_label']="";
        //echo 'matched';
    }else{
       //echo "not match";
    }
    //array_push($json, $json_);
    //print_r($json_);
    $modified_json[] = $json_;
}


//print_r($modified_json);


//echo $last_created_at_format."--".$data_last_created_at_format;
// if ($last_created_at_format === $data_last_created_at_format) {
//      $json[$key]['date_label'] = '';
//   // echo "The 'created_at' values are equal.";
// } else {
//     //echo "The 'created_at' values are not equal.";
// }   
}
//print_r($data_last);
if(isset($modified_json)){
  $json = $modified_json;  
}
  
  return $this->response->setJSON($json);

}
function chat_system_fetch_reply(){
  $id=$this->request->getVar('id');
  $data = $this->chat_system->where('id', $id)->first(); 
  return $this->response->setJSON($data);
}

function chat_system_checksession(){
    $session = \Config\Services::session();
    $operation = $this->request->getVar('operation');
    $session->set('operation', $operation);
      
}

function chat_system_getsession(){
    $session = \Config\Services::session();
    $operationValue = $session->get('operation');
    return $this->response->setJSON(['operation' => $operationValue]);
    
}

function last_one_data_fetch(){
    
    $offset_ = $this->request->getPost("userTimezone");
    $timezone = new DateTimeZone($offset_);
    $date = new DateTime('now', $timezone);
    $today=$date->format('Y-m-d'); //today date
    $data = $this->chat_system->orderBy('id', 'DESC')->first(); 
    $createdDate = new DateTime($data['created_at']);
    //$last_msg_date= $createdDate->format('Y-m-d');//last msg date
    $createdDate->setTimezone($timezone);
    $new_date = $createdDate->format('Y-m-d H:i:s');
    $data['created_at'] = $new_date;
    $check_today_date = $this->chat_system->where('DATE(created_at)', $today)->findAll();
    $count_today_date_count = count($check_today_date);
    if($count_today_date_count == 1){
        $data['date_label']='Today';
    }else{
        $data['date_label']=''; 
    }
    return $this->response->setJSON($data);
}
// public function get_latest_message_id() {
//     $latestMessage = $this->chat_system->orderBy('created_at', 'DESC')->first();

//     if ($latestMessage) {
//         $latestMessageId = $latestMessage['id'];
//     } else {
//         // Handle the case where no messages are found
//         $latestMessageId = null;
//     }

//     return $this->response->setJSON(['latestMessageId' => $latestMessageId]);
// }


  function notes(){
        $notes = $this->request->getPost('notes');
        $pointer_id = $this->request->getPost('pointer_id');
        $data=[
             
         	 'message' => $notes,
         	 'pointer_id' => $pointer_id,
         	 'created_at'=> date('Y-m-d-H-i'),
         	 'updated_at' => date('Y-m-d-H-i')
            ];
          /*  print_r($data);*/
         $insert= $this->notes->insert($data); 
         if($insert){
             $callback = array(
                "color" => "success",
                "msg" => "msg send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
             $callback = array(
                "msg" => "msg not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($data);
    } 


function notes_fetch(){
  $data = $this->notes->orderBy('created_at', 'ASC')->findAll(); 
  return $this->response->setJSON($data);

}

 function update_message() {
    $messageId = $this->input->post('messageId');
    $newMessage = $this->input->post('newMessage');

    // Update the message in the database or wherever you're storing messages
    // Example using CodeIgniter's Active Record:
    $this->db->where('id', $messageId);
    $this->db->update('messages', array('message' => $newMessage));

    // Send a success response
    echo json_encode(array('success' => true));
}

// function delete_chat_(){
//      $id=$_POST['id'];
//       $this->db->where('id', $id);
//       $deleted=$this->db->delete('id',$id);
//       echo json_encode(array('success' => true));
// }



}
