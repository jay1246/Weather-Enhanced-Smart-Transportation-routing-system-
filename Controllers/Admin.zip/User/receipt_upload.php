<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

// stage 3 ---------------------------------------- 

class receipt_upload extends BaseController
{
    public function receipt_upload_page($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        if (empty($stage_3)) {
            $this->stage_3_model->insert(['pointer_id' => $pointer_id, 'status' => 'Start']);
        }
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        $status = (!empty($stage_3['status']) ? $stage_3['status'] : "");

        if ($status == "" || $status == "Start") {
            $receipt_number = (!empty($stage_3['receipt_number']) ? $stage_3['receipt_number'] : "");
            $payment_date = "";
            if (!empty($stage_3['payment_date']) && $stage_3['payment_date'] != "0000-00-00 00:00:00") {
                $payment_date = (!empty($stage_3['payment_date']) ?  date("d/m/Y", strtotime($stage_3['payment_date'])) : "");
            }
            $preference_location =  (!empty($stage_3['preference_location']) ? $stage_3['preference_location'] : "");
            $preference_comment = (!empty($stage_3['preference_comment']) ? $stage_3['preference_comment'] : "");

            $documents = $this->documents_model->where(["pointer_id" => $pointer_id, 'stage' => 'stage_3'])->first();
            $document_full_name = (isset($documents['document_name']) ? $documents['document_name'] : "");
            $document_path = (isset($documents['document_path']) ? $documents['document_path'] : "");
            $document_name = (isset($documents['name']) ? $documents['name'] : "");
            if (!empty($document_name)) {
                $file_uploaded = true;
            } else {
                $file_uploaded = false;
            }


            $offline_locations = $this->stage_3_offline_location_model->find();
            $country = array();
            foreach ($offline_locations as $key => $value) {
                if (!in_array($value['country'], $country)) {
                    $country[] = $value['country'];
                }
            }
            $location = array();
            foreach ($country as $key => $value) {
                $offline_location = $this->stage_3_offline_location_model->where(['country' => $value])->find();
                $location[$value] = $offline_location;
            }




            $data["page"] = 'TRA Payment Receipt Number';
            $data["pointer_id"] = $pointer_id;
            $data["ENC_pointer_id"] = $ENC_pointer_id;
            $data["receipt_number"] = $receipt_number;
            $data["payment_date"] = $payment_date;
            $data["preference_location"] = $preference_location;
            $data["preference_comment"] = $preference_comment;
            $data["document_name"] = $document_name;
            $data["document_full_name"] = $document_full_name;
            $data["document_path"] = $document_path;
            $data["file_uploaded"] = $file_uploaded;
            $data["location"] = $location;
            // echo "<pre>";
            // print_r($data);
            // exit;
            return view('user/stage_3/receipt_upload', $data);
        }
        // return view('user/dashboard');
        return redirect()->to('user/dashboard');
    }

    // ajax ----------
    public function save_Preferred_info_($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        $data = $this->request->getVar();
        $preference_comment = "";
        if (isset($data['preference_comment'])) {
            $preference_comment = $data['preference_comment'];
        }
        $preference_location = "";
        if (isset($data['preference_location'])) {
            $preference_location = $data['preference_location'];
        }

        $details = [
            'preference_comment' => $preference_comment,
            'preference_location' => $preference_location,
        ];
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->set($details)->update();
        if ($stage_3) {
            echo "done";
        } else {
            echo "sorry";
        }
    }

    // ajax ----------
    public function get_addresh_()
    {
        $city_name = $_POST['city_name'];
        $offline_locations = $this->stage_3_offline_location_model->where('city_name', $city_name)->first();
        return json_encode($offline_locations);
    }


    // ajax ----------
    public function receipt_upload_action($ENC_pointer_id)
    {
        // Start Session
        $session = session();
        // 
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $recipt_number =  $this->request->getPost('recipt_number');

        $payment_date =  $this->request->getPost('payment_date');
        $payment_date = str_replace('/', '-', $payment_date);
        if (!empty($payment_date)) {
            $payment_date =  date("Y-m-d h:i:s", strtotime($payment_date));
        }

        // file data and file name 
        $file =  $this->request->getFile('recipt');


        $File_extention = $file->getClientExtension();

        $docs_db = $this->required_documents_list_model->where("stage", "stage_3")->first();
        $folder_path = 'public/application/' . $pointer_id . '/stage_3';
        $document_name = $docs_db["document_name"];
        $file_name_with_extantion = $document_name . '.' . $File_extention;
        if (!is_dir($folder_path)) {
            mkdir($folder_path);
        }
        // move file to folder 
        $is_move = $file->move($folder_path, $file_name_with_extantion, true);
        if ($is_move) {
            $data = [
                "receipt_number" => $recipt_number,
                "payment_date" => $payment_date,
                "submitted_by"  => $session->user_id,
            ];
            if ($this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update()) {
                $data_docs = [
                    "pointer_id" => $pointer_id,
                    "stage" => 'stage_3',
                    "required_document_id" => $docs_db["id"],
                    "name" => $docs_db["document_name"],
                    "document_name" => $file_name_with_extantion,
                    "document_path" => $folder_path,
                    "status" => 1,
                ];

                if ($this->documents_model->insert($data_docs)) {
                    $this->session->setFlashdata('msg', 'File Uploaded Successfully.');
                } else {
                    $this->session->setFlashdata('error_msg', 'File Uploading Error.');
                }
            }
        } else {
            $this->session->setFlashdata('error_msg', 'Sorry! File Not Uploaded.');
        }

        return redirect()->back();
    }

    public function receipt_upload_getData($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $stage_3__ = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        $docs = $this->documents_model->where([
            "pointer_id" => $pointer_id,
            "stage" => "stage_3",
        ])->first();
        $output = [];
        if ($docs) {
            $output = [
                "name" => $docs["name"],
                "path" => base_url() . "/" . $docs["document_path"] . "/" . $docs["document_name"],
                "pointer_id" => $docs["pointer_id"],
                "receipt_number" => $stage_3__["receipt_number"],
                "payment_date" => date("d/m/y", strtotime($stage_3__["payment_date"])),
            ];
        }
        echo json_encode($output);
    }

    // working
    function receipt_upload_delete($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $data = [
            'receipt_number' => '',
            'payment_date' => '',
            'preference_location' => '',
            'preference_comment' => '',
        ];
        if ($this->stage_3_model->where("pointer_id", $pointer_id)->set($data)->update()) {
            $documents = $this->documents_model->where("pointer_id", $pointer_id)->first();
            if (!empty($documents)) {
                $file_path =  $documents['document_path'] . '/' . $documents['document_name'];
                if (file_exists($file_path)) {
                    if (unlink($file_path)) {
                        if ($this->documents_model->where(['stage' => 'stage_3', 'pointer_id' => $pointer_id])->delete()) {
                            $this->session->setFlashdata('msg', 'File Deleted Successfully.');
                        }
                    }
                } else {
                    if ($this->documents_model->where(['stage' => 'stage_3', 'pointer_id' => $pointer_id])->delete()) {
                        $this->session->setFlashdata('msg', 'File Deleted Successfully.');
                    }
                }
            } else {
                $this->session->setFlashdata('error_msg', 'Sorry! File Not Found.');
            }
        }

        return redirect()->back();
    }



    function stage_3_submit_($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        // echo $pointer_id;
        $is_update = $this->stage_3_model->set([
            "status" => "Submitted",
            "submitted_date" => date("Y-m-d H:i:s"),
        ])->where("pointer_id", $pointer_id)->update();


        // email -----------------------------------------------------------------
        // no reply to applicant or agent  -------------------
        $email = "";
        $stage_1_contact_details_ = $this->stage_1_contact_details_model->where(['pointer_id' => $pointer_id])->first();
        if (!empty($stage_1_contact_details_)) {
            $email = $stage_1_contact_details_['email'];
        } // Applicant email

        $application_pointer = $this->application_pointer_model->where(['id' => $pointer_id])->first();
        if (!empty($application_pointer)) {
            $user_id = $application_pointer['user_id'];
            $user_account = $this->user_account_model->where(['id' => $user_id])->first();
            if (!empty($user_account)) {
                $email = $user_account['email'];
            }
        } // agent email


        if (!empty($email)) {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") { // Applicant
                // s3_submitted_agent
                $mail_temp_4 = $this->mail_template_model->where(['id' => '43'])->first();
                if (!empty($mail_temp_4)) {
                    $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
                    $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
                    $to =  $email;
                    $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                    if ($check == 1) {
                        $email_send_agent_applicant = true;
                    }
                } // email template
            }
            if ($client_type == "Applicant") { // 
                // s3_submitted_applicant
                $mail_temp_4 = $this->mail_template_model->where(['id' => '86'])->first();
                if (!empty($mail_temp_4)) {
                    $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
                    $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
                    $to =  $email;
                    $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                    if ($check == 1) {
                        $email_send_agent_applicant = true;
                    }
                } // email template
            }
        } // email


        //s3_submitted_admin
        $mail_temp_4 = $this->mail_template_model->where(['id' => '44'])->first();
        if (!empty($mail_temp_4)) {
            $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
            $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
            $stage_3_ = $this->stage_3_model->where(['pointer_id' => $pointer_id])->first();

            $preference_location_comment = "";
            if (!empty($stage_3_)) {
                $preference_location = trim($stage_3_['preference_location']);
                $preference_comment = trim($stage_3_['preference_comment']);
                $preference_comment = trim($preference_comment, "\xC2\xA0");
                $preference_comment = str_replace("&nbsp;", '', $preference_comment);
                if (!empty($preference_location)) {
                    $preference_location_comment .= "<b>Applicant's Preferred Venue: " . $preference_location;
                }
                if (!empty($preference_comment)) {
                    // $preference_location_comment .= "<br><br><u> Comments: </u><br>" . $preference_comment . "</b>";
                    $preference_location_comment .= "<br><br><u> Comments: </u><br><i>\"" . $preference_comment . "\"</i></b>";
                }
            }

            $stage_3_Docs = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 19, 'stage' => "stage_3"])->first();
            $addAttachment = array(
                [
                    'file_path' => $stage_3_Docs['document_path'] . '/' . $stage_3_Docs['document_name'],
                    'file_name' => $stage_3_Docs['document_name'],
                ]
            );

            $message = str_replace('%preference_location_comment%', $preference_location_comment, $message);
            $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'),  env('ADMIN_EMAIL'), $subject, $message, [], [], [], $addAttachment);
            if ($check == 1) {
                $email_send_admin = true;
            }
        }

        if ($email_send_agent_applicant && $email_send_admin) {
            if ($is_update) {
                $is_pointer_update = $this->application_pointer_model->set([
                    "stage" => "stage_3",
                    "status" => "Submitted",
                ])->where("id", $pointer_id)->update();
                // Do here Mail Code
                // End Do here Mail Code
                if ($is_pointer_update) {
                    $json = [
                        "error" => 0,
                        "msg"   => "Submitted Successfully",
                    ];
                }
            }
        }

        return redirect()->to(base_url('user/view_application/' . $ENC_pointer_id));
    }
}
