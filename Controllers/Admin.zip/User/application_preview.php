<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;
use Dompdf\Dompdf;

class application_preview extends BaseController
{
    public function application_preview($ENC_pointer_id)
    {
        // Decode ------
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $register_user = $this->application_pointer_model->where('id', $pointer_id)->first();

        if (session()->has('user_id')) {
            $user_id = session()->get('user_id');
        } else {
            $user_id = $register_user['user_id'];
            $this->session->set('user_id', $user_id);
            $this->session->set('check_admin', "yes");
        }

        $database = $this->stage_1_education_and_employment_model->where(['pointer_id' => $pointer_id])->find();
        $perosnal_details = $this->stage_1_personal_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $occupation_details = $this->stage_1_occupation_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $contact_details = $this->stage_1_contact_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $identification_details = $this->stage_1_identification_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $usi_details = $this->stage_1_usi_avetmiss_model->orderby('id', 'DESC')->where(['pointer_id' => $pointer_id])->first();
        $education_and_employment = $this->stage_1_education_and_employment_model->orderby('id', 'DESC')->where(['pointer_id' => $pointer_id])->first();
        $register_user = $this->user_account_model->where('id', $user_id)->first();
        $stage_1_pdf_download = $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();

        $data = [
            'ENC_pointer_id' => $ENC_pointer_id,
            'page' => "Application Preview",
            'education_and_employment' => $education_and_employment,
            'database' => $database,
            'register_user' => $register_user,
            'personal_details' => $perosnal_details,
            'identification_details' => $identification_details,
            'occupation' => $occupation_details,
            'usi_details' => $usi_details,
            'contact_details' => $contact_details,
            'stage_1_pdf_download' => $stage_1_pdf_download,
        ];
        return view('user/stage_1/application_preview', $data);
    } // funtion close


    //  on page load ajex call --------------
    // that funtion use to Applicant Declaration page also ---
    public function pdf_Download_check_()
    {
        $data = $this->request->getvar();

        $file_page = $data['file_page'];
        $ENC_pointer_id = $data['ENC_pointer_id'];
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);


        $is_add_update = false;
        $stage_1_review_confirm_model = $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        if (empty($stage_1_review_confirm_model)) {
            $details = [
                $file_page => 1,
                'pointer_id' => $pointer_id,
            ];
            if ($this->stage_1_review_confirm_model->insert($details)) {
                $is_add_update = true;
            }
        } else {
            $check_1 =  $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->set($file_page, 1)->update();
            if ($check_1) {
                $is_add_update = true;
            }
        }
        $agent_details = $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id, 'information_release_file_download' => 1, 'applicant_declaration_file_download' => 1])->orderby('id', 'DESC')->first();
        if ($agent_details) {
            return "ok";
        }



        return "sorry";
    }



    public function pdf_Download_check_only_()
    {
        $data = $this->request->getvar();

        $ENC_pointer_id = $data['ENC_pointer_id'];
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        $agent_details = $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id, 'information_release_file_download' => 1, 'applicant_declaration_file_download' => 1])->orderby('id', 'DESC')->first();
        if ($agent_details) {
            return "ok";
        }
        return "sorry";
    }




    //  on page load ajex call -------
    public function pdf_html_code_()
    {
        $data = $this->request->getvar();
        $pdf_html_code = $data['pdf_html_code'];

        $pdf_html_code =   str_replace('style="font-size: 23px;"', "", $pdf_html_code);
        $ENC_pointer_id = $data['ENC_pointer_id'];
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        if (!empty($pointer_id)) {
            $check = $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->first();
            if (!empty($check)) {
                $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->set(['pdf_html_code' => $pdf_html_code])->update();
            } else {
                $details = [
                    'pdf_html_code' => $pdf_html_code,
                ];
                $this->stage_1_review_confirm_model->save($details);
            }
            echo "done";
        }
    }


    public function download_PDF_($ENC_pointer_id, $file_name)
    {



        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        $this->stage_1_education_and_employment_model->where(['pointer_id' => $pointer_id])->set('is_downloaded', 1)->update();

        $img_tag  = '<img src="' . base_url() . '/public/assets/image/profile_pic.jpg"   alt="" class="responsive" width="10%" height="40px" id="user_img">';

        $document = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 1, 'stage' => 'stage_1'])->first();
        if (!empty($document)) {
            $document_name = $document['document_name'];
            $document_path = $document['document_path'];
            $full_path = $document_path . '/' . $document_name;
            if (file_exists($full_path)) {
                $img_tag  = '  <img src="' . base_url() . '/' . $full_path . '"  alt="" class="responsive" width="10%" height="75px" id="user_img">';
            }
        }

        $stage_1_ = $this->stage_1_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $status = $stage_1_['status'];
        $submitted_date = $stage_1_['submitted_date'];

        $date = '<DIV class="date">Date : ' . date("d/m/Y") . '</DIV> ';
        if (!empty($status)) {
            if ($status == 'submitted') {
                if (!empty($submitted_date)) {
                    $date = '<DIV class="date">Submitted Date : ' . $submitted_date . '</DIV> ';
                }
            }
        }

        if (!empty($file_name)) {
            $file_name = $file_name;
        } else {
            $file_name = 'review & confirm';
        }

        $perosnal_details = $this->stage_1_personal_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $first_or_given_name = (!empty($perosnal_details['first_or_given_name'])) ? $perosnal_details['first_or_given_name'] : '';
        $middle_names = (!empty($perosnal_details['middle_names'])) ? $perosnal_details['middle_names'] : '';
        $surname_family_name = (!empty($perosnal_details['surname_family_name'])) ? $perosnal_details['surname_family_name'] : '';

        $aqato_logo = base_url('public/assets/image/aqato_logo.png');
        $attc_logo = base_url('public/assets/image/attc_logo.png');

        $a = '<html>
                    <head>
                        <title>
                        ' . $file_name . '
                        </title>
                        <style>
                
                            @page {
                                margin: 0cm 0cm;
                            }
                            body {
                                margin-top: 5cm;
                                margin-left: 2cm;
                                margin-right: 2cm;
                                margin-bottom: 2cm;
                            }
                            header {
                                position: fixed;
                                top: 0.9cm;
                                left: 1cm;
                                right: 1cm;
                                height: 80px;
                                border-bottom: 1px solid;

                            }
                            footer {
                            border-top: 1px solid;
                            padding-top: 5px;
                                position: fixed;
                                bottom: 0cm;
                                left: 1cm;
                                right: 1cm;
                                height: 2cm;
                            }
                            table {
                            
                                border-collapse: collapse;
                                width: 100%;
                            filter: alpha(opacity=40); 
                            opacity: 0.95;
                            border:1px black solid;"
                            }
                            hr {
                            clear: both;
                            visibility: hidden;
                        }
                            table td,
                            table th {
                            
                                padding: 8px;
                            }
                            table tr:nth-child(even) {
                                background-color: #f2f2f2;
                            }
                            table tr:hover {
                                background-color: #ddd;
                            }
                            table th {
                                padding-top: 12px;
                                padding-bottom: 12px;
                                text-align: left;
                                background-color: #f2f2f2;
                            }
                            #tra {
                            position:absolute;
                            left:70%;
                            margin-top: 20px;
                            margin-left: 10px;
                            }
                            .table {
                                margin-bottom: 20px;
                            }
                        .Personal_Details{
                        margin-top:-30px;
                        }
                        .Occupation{
                        margin-top:-20px;
                        }
                        .Contact_Details{
                        margin-top:-60px; 
                        }
                        .Identification_Details{
                        margin-top:-60px; 
                        }
                        .Representative_Details{
                        margin-top:-60px; 
                        }
                        .USI{
                        margin-top:-60px; 
                        }

                            .date { margin-top:-30px; margin-left:40%; font-size: 14px;  }
                            .name {  margin-left:40%;  margin-top: -30px !important; }
                            #user_img { margin-top: -34px; margin-left:86.5%; border:1px solid black; padding: 20px 10px 20px 10px; }
                        
                        </style>
                    </head>
                    
                    <body>';
        $b = '<header>
                                    <img src="' . base_url() . '/public/assets/image/tra.png" alt="Aqato" height="auto" width="10%">
                                    
                                            <img src="' . $attc_logo . '" alt="Attc" height="80px" width="60%">
                                            <div id="tra">TRA Application Form</div>
                                        </header>
                                        <footer>
                                            <img src="' . $aqato_logo . '" alt="Aqato" height="30px" width="15%">
                                        ' . $date . '
                                        </footer>

                                    <div id="list"">
                                    
                                        <h4 class="name ">Name :- ' . $first_or_given_name . ' ' . $middle_names . " " . $surname_family_name . '</h4> 
                                       <br> ' . $img_tag . '
                                        </div>
                                ';



        $data =   $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->first();

        if (!isset($data['pdf_html_code']) || empty($data['pdf_html_code'])) {
            $this->session->setFlashdata('error_msg', 'PDF pdf_html_code empty ');
            return redirect()->back();
        }

        if ($data['pdf_html_code']) {
            $html = $a . ' ' . $b . ' ' . $data['pdf_html_code'];
        } else {
            $html = $a . ' ' . $b;
        }
        // echo $html;
        // exit;
        // -------------PDF creat Code  ----------
        require_once "dompdf/autoload.inc.php";
        $dompdf = new Dompdf();
        // echo "hi";
        // exit;
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->set_option('isRemoteEnabled', true);
        $dompdf->loadhtml($html);
        $dompdf->setpaper('A4', 'portrait');
        $dompdf->set_option("isPhpEnabled", true); //
        $dompdf->render();
        $x          = 505;
        $y          = 790;
        $text       = "{PAGE_NUM} of {PAGE_COUNT}";
        $font       = $dompdf->getFontMetrics()->get_font('Helvetica', 'normal');
        $size       = 10;
        $color      = array(0, 0, 0);
        $word_space = 0.0;
        $char_space = 0.0;
        $angle      = 0.0;
        $dompdf->getCanvas()->page_text(
            $x,
            $y,
            $text,
            $font,
            $size,
            $color,
            $word_space,
            $char_space,
            $angle
        );




        if (!empty($file_name)) {
            $dompdf->stream($file_name);
        } else {
            $dompdf->stream('review & confirm');
        }

        $output = $dompdf->output();
        $sss = "public/application/" . $pointer_id . "/stage_1/";
        if (!is_dir($sss)) {
            // create the directory path if it does not exist
            mkdir($sss, 0777, true);
        }
        $sss .= "TRA Application Form.pdf";
        file_put_contents($sss, $output);


        // $sss = "public/" . $user_id . "_" . $application_id . ".pdf";
        // file_put_contents($sss, $output);
    }




    public function auto_save_download_PDF_($ENC_pointer_id,  $file_name)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        $this->stage_1_education_and_employment_model->where(['pointer_id' => $pointer_id])->set('is_downloaded', 1)->update();

        $img_tag  = '<img src="' . base_url() . '/public/assets/image/profile_pic.jpg"   alt="" class="responsive" width="10%" height="35px" id="user_img">';

        $document = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 1, 'stage' => 'stage_1'])->first();
        if (!empty($document)) {
            $document_name = $document['document_name'];
            $document_path = $document['document_path'];
            $full_path = $document_path . '/' . $document_name;
            if (file_exists($full_path)) {
                $img_tag  = '  <img src="' . base_url() . '/' . $full_path . '"  alt="" class="responsive" width="10%" height="75px" id="user_img">';
            }
        }

        $stage_1_ = $this->stage_1_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $status = $stage_1_['status'];
        $submitted_date = $stage_1_['submitted_date'];

        $date = '<DIV class="date">Date : ' . date("d/m/Y") . '</DIV> ';
        if (!empty($status)) {
            if ($status == 'submitted') {
                if (!empty($submitted_date)) {
                    $date = '<DIV class="date">Submitted Date : ' . $submitted_date . '</DIV> ';
                }
            }
        }

        if (!empty($file_name)) {
            $file_name = $file_name;
        } else {
            $file_name = 'review & confirm';
        }

        $perosnal_details = $this->stage_1_personal_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $first_or_given_name = (!empty($perosnal_details['first_or_given_name'])) ? $perosnal_details['first_or_given_name'] : '';
        $middle_names = (!empty($perosnal_details['middle_names'])) ? $perosnal_details['middle_names'] : '';
        $surname_family_name = (!empty($perosnal_details['surname_family_name'])) ? $perosnal_details['surname_family_name'] : '';

        $aqato_logo = base_url('public/assets/image/aqato_logo.png');
        $attc_logo = base_url('public/assets/image/attc_logo.png');


        $a = '<html>
                    <head>
                        <title>
                        ' . $file_name . '
                        </title>
                        <style>
                
                            @page {
                                margin: 0cm 0cm;
                            }
                            body {
                                margin-top: 5cm;
                                margin-left: 2cm;
                                margin-right: 2cm;
                                margin-bottom: 2cm;
                            }
                            header {
                                position: fixed;
                                top: 0.9cm;
                                left: 1cm;
                                right: 1cm;
                                height: 80px;
                                border-bottom: 1px solid;

                            }
                            footer {
                            border-top: 1px solid;
                            padding-top: 5px;
                                position: fixed;
                                bottom: 0cm;
                                left: 1cm;
                                right: 1cm;
                                height: 2cm;
                            }
                            table {
                            
                                border-collapse: collapse;
                                width: 100%;
                            filter: alpha(opacity=40); 
                            opacity: 0.95;
                            border:1px black solid;"
                            }
                            hr {
                            clear: both;
                            visibility: hidden;
                        }
                            table td,
                            table th {
                            
                                padding: 8px;
                            }
                            table tr:nth-child(even) {
                                background-color: #f2f2f2;
                            }
                            table tr:hover {
                                background-color: #ddd;
                            }
                            table th {
                                padding-top: 12px;
                                padding-bottom: 12px;
                                text-align: left;
                                background-color: #f2f2f2;
                            }
                            #tra {
                            position:absolute;
                            left:70%;
                            margin-top: 20px;
                            margin-left: 10px;
                            }
                            .table {
                                margin-bottom: 20px;
                            }
                        .Personal_Details{
                        margin-top:-30px;
                        }
                        .Occupation{
                        margin-top:-20px;
                        }
                        .Contact_Details{
                        margin-top:-60px; 
                        }
                        .Identification_Details{
                        margin-top:-60px; 
                        }
                        .Representative_Details{
                        margin-top:-60px; 
                        }
                        .USI{
                        margin-top:-60px; 
                        }

                            .date { margin-top:-30px; margin-left:40%; font-size: 14px;  }
                            .name {  margin-left:40%;  margin-top: -30px !important; }
                            #user_img { margin-top: -34px; margin-left:86.5%; border:1px solid black; padding: 20px 10px 20px 10px; }
                        
                        </style>
                    </head>
                    
                    <body>';
        $b = '<header>
                     <img src="' . base_url() . '/public/assets/image/tra.png" alt="Aqato" height="auto" width="10%">
                     <img src="' . $attc_logo . '" alt="Attc" height="80px" width="60%">
                     <div id="tra">TRA Application Form</div>
             </header>
             <footer>
                   <img src="' . $aqato_logo . '" alt="Aqato" height="30px" width="15%">
                   ' . $date . '
              </footer>
                <div id="list"">
                       <h4 class="name ">Name :- ' . $first_or_given_name . ' ' . $middle_names . " " . $surname_family_name . '</h4> 
                      <br>   ' . $img_tag . '
                </div>
             ';



        $data =   $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->first();

        if (!isset($data['pdf_html_code']) || empty($data['pdf_html_code'])) {
            $this->session->setFlashdata('error_msg', 'PDF pdf_html_code empty ');
            return redirect()->back();
        }

        if ($data['pdf_html_code']) {
            $html = $a . ' ' . $b . ' ' . $data['pdf_html_code'];
        } else {
            $html = $a . ' ' . $b;
        }



        // echo $html;
        // exit;
        // -------------PDF  creat Code  ----------
        require_once "dompdf/autoload.inc.php";
        $dompdf = new Dompdf();
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->set_option('isRemoteEnabled', true);
        $dompdf->loadhtml($html);
        $dompdf->setpaper('A4', 'portrait');
        $dompdf->set_option("isPhpEnabled", true); //
        $dompdf->render();
        $x          = 505;
        $y          = 790;
        $text       = "{PAGE_NUM} of {PAGE_COUNT}";
        $font       = $dompdf->getFontMetrics()->get_font('Helvetica', 'normal');
        $size       = 10;
        $color      = array(0, 0, 0);
        $word_space = 0.0;
        $char_space = 0.0;
        $angle      = 0.0;
        $dompdf->getCanvas()->page_text(
            $x,
            $y,
            $text,
            $font,
            $size,
            $color,
            $word_space,
            $char_space,
            $angle
        );

        // if (!empty($file_name)) {
        //     $dompdf->stream($file_name);
        // } else {
        //     $dompdf->stream('review & confirm');
        // }

        // $output = $dompdf->output();
        $sss = "public/application/" . $pointer_id . "/stage_1/";
        if (!is_dir($sss)) {
            // create the directory path if it does not exist
            mkdir($sss, 0777, true);
        }
        $sss = "public/application/" . $pointer_id . "/stage_1/TRA Application Form.pdf";
        file_put_contents($sss, $dompdf->output());
        // return redirect()->back();
    }


    public function auto_save_download_PDF_admin($ENC_pointer_id,  $file_name)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);



        $this->stage_1_education_and_employment_model->where(['pointer_id' => $pointer_id])->set('is_downloaded', 1)->update();

        $img_tag  = '<img src="' . base_url() . '/public/assets/image/profile_pic.jpg"   alt="" class="responsive" width="10%" height="35px" id="user_img">';

        $document = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 1, 'stage' => 'stage_1'])->first();
        if (!empty($document)) {
            $document_name = $document['document_name'];
            $document_path = $document['document_path'];
            $full_path = $document_path . '/' . $document_name;
            if (file_exists($full_path)) {
                $img_tag  = '  <img src="' . base_url() . '/' . $full_path . '"  alt="" class="responsive" width="10%" height="75px" id="user_img">';
            }
        }

        $stage_1_ = $this->stage_1_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $status = $stage_1_['status'];
        $submitted_date = $stage_1_['submitted_date'];

        $date = '<DIV class="date">Date : ' . date("d/m/Y") . '</DIV> ';
        if (!empty($status)) {
            if ($status == 'submitted') {
                if (!empty($submitted_date)) {
                    $date = '<DIV class="date">Submitted Date : ' . $submitted_date . '</DIV> ';
                }
            }
        }

        if (!empty($file_name)) {
            $file_name = $file_name;
        } else {
            $file_name = 'review & confirm';
        }

        $perosnal_details = $this->stage_1_personal_details_model->where(['pointer_id' => $pointer_id])->orderby('id', 'DESC')->first();
        $first_or_given_name = (!empty($perosnal_details['first_or_given_name'])) ? $perosnal_details['first_or_given_name'] : '';
        $middle_names = (!empty($perosnal_details['middle_names'])) ? $perosnal_details['middle_names'] : '';
        $surname_family_name = (!empty($perosnal_details['surname_family_name'])) ? $perosnal_details['surname_family_name'] : '';

        $aqato_logo = base_url('public/assets/image/aqato_logo.png');
        $attc_logo = base_url('public/assets/image/attc_logo.png');


        $a = '<html>
                    <head>
                        <title>
                        ' . $file_name . '
                        </title>
                        <style>
                
                            @page {
                                margin: 0cm 0cm;
                            }
                            body {
                                margin-top: 5cm;
                                margin-left: 2cm;
                                margin-right: 2cm;
                                margin-bottom: 2cm;
                            }
                            header {
                                position: fixed;
                                top: 0.9cm;
                                left: 1cm;
                                right: 1cm;
                                height: 80px;
                                border-bottom: 1px solid;

                            }
                            footer {
                            border-top: 1px solid;
                            padding-top: 5px;
                                position: fixed;
                                bottom: 0cm;
                                left: 1cm;
                                right: 1cm;
                                height: 2cm;
                            }
                            table {
                            
                                border-collapse: collapse;
                                width: 100%;
                            filter: alpha(opacity=40); 
                            opacity: 0.95;
                            border:1px black solid;"
                            }
                            hr {
                            clear: both;
                            visibility: hidden;
                        }
                            table td,
                            table th {
                            
                                padding: 8px;
                            }
                            table tr:nth-child(even) {
                                background-color: #f2f2f2;
                            }
                            table tr:hover {
                                background-color: #ddd;
                            }
                            table th {
                                padding-top: 12px;
                                padding-bottom: 12px;
                                text-align: left;
                                background-color: #f2f2f2;
                            }
                            #tra {
                            position:absolute;
                            left:70%;
                            margin-top: 20px;
                            margin-left: 10px;
                            }
                            .table {
                                margin-bottom: 20px;
                            }
                        .Personal_Details{
                        margin-top:-30px;
                        }
                        .Occupation{
                        margin-top:-20px;
                        }
                        .Contact_Details{
                        margin-top:-60px; 
                        }
                        .Identification_Details{
                        margin-top:-60px; 
                        }
                        .Representative_Details{
                        margin-top:-60px; 
                        }
                        .USI{
                        margin-top:-60px; 
                        }

                            .date { margin-top:-30px; margin-left:40%; font-size: 14px;  }
                            .name {  margin-left:40%;  margin-top: -30px !important; }
                            #user_img { margin-top: -34px; margin-left:86.5%; border:1px solid black; padding: 20px 10px 20px 10px; }
                        
                        </style>
                    </head>
                    
                    <body>';
        $b = '<header>
                     <img src="' . base_url() . '/public/assets/image/tra.png" alt="Aqato" height="auto" width="10%">
                     <img src="' . $attc_logo . '" alt="Attc" height="80px" width="60%">
                     <div id="tra">TRA Application Form</div>
             </header>
             <footer>
                   <img src="' . $aqato_logo . '" alt="Aqato" height="30px" width="15%">
                   ' . $date . '
              </footer>
                <div id="list"">
                       <h4 class="name ">Name :- ' . $first_or_given_name . ' ' . $middle_names . " " . $surname_family_name . '</h4> 
                      <br>   ' . $img_tag . '
                </div>
             ';



        $data =   $this->stage_1_review_confirm_model->where(['pointer_id' => $pointer_id])->first();

        if (!isset($data['pdf_html_code']) || empty($data['pdf_html_code'])) {
            $this->session->setFlashdata('error_msg', 'PDF pdf_html_code empty ');
            return redirect()->back();
        }

        if ($data['pdf_html_code']) {
            $html = $a . ' ' . $b . ' ' . $data['pdf_html_code'];
        } else {
            $html = $a . ' ' . $b;
        }



        // echo $html;
        // exit;
        // -------------PDF  creat Code  ----------
        require_once "dompdf/autoload.inc.php";
        $dompdf = new Dompdf();
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->set_option('isRemoteEnabled', true);
        $dompdf->loadhtml($html);
        $dompdf->setpaper('A4', 'portrait');
        $dompdf->set_option("isPhpEnabled", true); //
        $dompdf->render();
        $x          = 505;
        $y          = 790;
        $text       = "{PAGE_NUM} of {PAGE_COUNT}";
        $font       = $dompdf->getFontMetrics()->get_font('Helvetica', 'normal');
        $size       = 10;
        $color      = array(0, 0, 0);
        $word_space = 0.0;
        $char_space = 0.0;
        $angle      = 0.0;
        $dompdf->getCanvas()->page_text(
            $x,
            $y,
            $text,
            $font,
            $size,
            $color,
            $word_space,
            $char_space,
            $angle
        );

        // if (!empty($file_name)) {
        //     $dompdf->stream($file_name);
        // } else {
        //     $dompdf->stream('review & confirm');
        // }

        // $output = $dompdf->output();
        $sss = "public/application/" . $pointer_id . "/stage_1/";
        if (!is_dir($sss)) {
            // create the directory path if it does not exist
            mkdir($sss, 0777, true);
        }
        $sss = "public/application/" . $pointer_id . "/stage_1/TRA Application Form.pdf";
        file_put_contents($sss, $dompdf->output());
        // return redirect()->back();
    }
}
