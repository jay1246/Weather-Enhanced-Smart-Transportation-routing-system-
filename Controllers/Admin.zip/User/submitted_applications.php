<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

class submitted_applications extends BaseController
{
    public function submitted_applications()
    {

        $data["page_name"] = "Submitted Applications";
        $user_id = session()->get("user_id");
        $application_pointer = $this->application_pointer_model->where(['user_id' => $user_id])->orderby('create_date', 'desc')->find();

        $table_data = array();
        foreach ($application_pointer as $res) {
            $pointer_id = $res['id'];

            // stage_1 = 1 to 10  index
            // stage_2 = 11 to 20  index
            // stage_3 = 21 to 30  index

            // helper call 
            $stage_index = application_stage_no($pointer_id);

            if ($stage_index >= 2) {

                $singal_table_data = array();
                // helper call
                $singal_table_data['ENC_pointer_id'] =  pointer_id_encrypt($res['id']);
                // helper call
                $singal_table_data['status_format'] =   create_status_format($stage_index);
                // helper call
                $singal_table_data['application_mo'] =  application_mo($pointer_id);
                $singal_table_data['portal_reference_no'] =  portal_reference_no($pointer_id);

                $singal_table_data['pointer_id'] =  $res['id'];



                // date format
                $created_at = $res['create_date'];
                $singal_table_data['created_at'] = $created_at;
                $created_at = strtotime($created_at);
                $created_at =  date("d/m/Y", $created_at);
                $singal_table_data['created_at_format'] =  empty($created_at) ? '--//--' : $created_at;



                // table 1
                $personal_details = $this->stage_1_personal_details_model->where(['pointer_id' => $pointer_id])->first();
                $singal_table_data['first_or_given_name'] = empty($personal_details['first_or_given_name']) ? '--//--' : $personal_details['first_or_given_name'];
                $singal_table_data['surname_family_name'] = empty($personal_details['surname_family_name']) ? '' : $personal_details['surname_family_name'];
                $singal_table_data['date_of_birth'] = empty($personal_details['date_of_birth']) ? '--//--' : $personal_details['date_of_birth'];
                // table 2 
                $occupation_application = $this->stage_1_occupation_model->where(['pointer_id' => $pointer_id])->first();

                $occupation_id = $occupation_application['occupation_id'];

                $occupation_list = $this->occupation_list_model->where(['id' => $occupation_id])->first();

                $singal_table_data['occupation'] =   empty($occupation_list['name']) ? '--//--' : $occupation_list['name'];
                // creat mainaray 


                // 25-04-2023 vishal
                $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
                $submitted_date = $stage_1->submitted_date;
                $approved_date = $stage_1->approved_date;
                $singal_table_data['submitted_date'] = $submitted_date;
                $singal_table_data['approved_date'] = $approved_date;

                $submitted_date = strtotime($submitted_date);
                $submitted_date =  date("d/m/Y", $submitted_date);
                $submitted_date = empty($submitted_date) ? '--//--' : $submitted_date;
                $singal_table_data['submitted_date_format'] = $submitted_date;



                $table_data[] = $singal_table_data;
            }
        }


        $data['table_data'] = $table_data;
        $data['page'] = "Submitted Applications";
        return view('user/submitted_applications', $data);
    }
}
