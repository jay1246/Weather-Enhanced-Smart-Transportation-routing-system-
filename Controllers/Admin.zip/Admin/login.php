<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class login extends BaseController
{
    public function login_page()
    {
        $data = ['page' => 'Admin Login'];
        return view('admin/login/login', $data);
    }
    public function forgot_password_page()
    {
        $data = ['page' => 'Forgotten password'];
        return view('admin/login/forgot_password', $data);
    }
    public function logincheck()
    {
        $session = session();
        $user_data = $this->request->getpost();
        $email = trim($user_data['email']);
        $password = trim($user_data['password']);
        $database = $this->admin_account_model->where(['password' => $password, 'email' => $email, 'status' => 'active'])->first();

        if ($database) {
            $admin_name = $database['first_name'] . " " . $database['middle_name'] . " " . $database['last_name'];

            $session = session();

            $session->set('admin_name', $admin_name);
            $session->set('admin_account_type', $database['account_type']);
            $session->set('admin_email', $database['email']);
            $session->set('admin_id', $database['id']);

            return redirect()->to(base_url('admin/dashboard'));
        } else {
            $session->setFlashdata('error', 'Invalid Username Or Password');
            return redirect()->to(base_url('admin/login'));
        }
    }
    public function check_forgot_password()
    {
        $data = $this->request->getvar();

        // forgot password for Admin ---------------------
        $database = $this->admin_account_model->where('email', $data['email'])->first();
        if (isset($database)) {
            // echo "check true";

            // email encrypt 
            $encrypter = \Config\Services::encrypter();
            $ciphertext = $encrypter->encrypt($data['email']);
            // reset password URL 
            $url =  base_url("admin/new_password/" . bin2hex($ciphertext));
            // email Funtion
            $to = $data['email'];
            $subject = 'Create a  New Password AQATO';
            $message = '<p>Admin > Create a New Password </p><hr>
                        <p>
                            <a href="' . $url . '">
                                Click here to Reset your Password !
                            </a>
                        </p> ';
            $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
            // email send check
            if ($check == 1) {
                // echo "send email";
                // exit;
                $this->session->setFlashdata("msg", ' Create New Password Link send to your Email Id, Please check your email ');
                return redirect()->to(base_url('admin/forgot_password'));
            } else {
                // echo "could not be sent email";
                // exit;
                $this->session->setFlashdata("error_msg", 'Sorry Email could not be sent.');
                return redirect()->to(base_url('admin/forgot_password'));
            }
        } else { // if user not found 
            //             echo "valid Email";
            // exit;
            $this->session->setFlashdata("error_msg", 'Please Enter valid Email Id ');
            return redirect()->to(base_url('admin/forgot_password'));
        }
    }
    public function New_password_page($encode_data)
    {
        $encrypter = \Config\Services::encrypter();

        // Encoded Sring check 
        if (ctype_xdigit($encode_data) && strlen($encode_data) % 2 == 0) {

            $h2b = hex2bin($encode_data);
            $data_a =  $encrypter->decrypt($h2b);
            // reset password for Admin ---------
            $database = $this->admin_account_model->where('email', $data_a)->first();
            if (isset($database)) {
                $data = [
                    'tokan' => $encode_data,
                    'ad' => '1',
                    'page' => 'Create New Password',
                ];
                return view('New_password_page', $data);
            } else {
                $this->session->setFlashdata('error_msg', 'Sorry! User Not Found.');
                return redirect()->to(base_url('admin/login'));
            }
        }
    }
    public function logout()
    {
        $this->session->destroy();
        return redirect()->to(base_url('admin/login'));
    }
}
