<?php

namespace App\Controllers\Admin\Application_manager;

use App\Controllers\BaseController;
use ZipArchive;

class application_manager extends BaseController
{

    // ---------------admin  Application Manager ---------------- 

    public function index()
    {
        $data['page_name'] = 'Application Manager';

        if (session()->get('admin_account_type') == 'admin') {
            $status_list = ['Start', 'Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined', 'Withdrawn', 'Expired'];
        } else if (session()->get('admin_account_type') == 'head_office') {
            $status_list = ['Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined', 'Withdrawn', 'Expired'];
        } else {
            exit;
        }
        //    $data['stage_1'] = $this->stage_1_model->asObject()->orWhereIn('status', $status_list)->orderby('submitted_date', 'DESC')->findAll();



        $all_list = array();
        $application_pointer_model = $this->application_pointer_model->asObject()->orWhereIn('status', $status_list)->orderby('create_date', 'DESC')->findAll();
        $i = 0;
        $aaa = array();
        foreach ($application_pointer_model as $stage) {
            // echo "<pre>";
            // print_r($stage);
            // echo "</pre>";
            // exit;

            $show = true;
            if ($stage->stage == "stage_1") {
                if ($stage->status == "Start") {
                    $show = false;
                }
                if (session()->get('admin_account_type') == 'head_office') {
                    if ($stage->status == "Start" || $stage->status == "Submitted") {
                        $show = false;
                    }
                }
            }
            if ($show) {
                $i++;
                $asdasd = $stage->stage . " " . $stage->status;
                if (!in_array($asdasd, $aaa)) {

                    $aaa[] = $asdasd;
                }



                $list_array = array();

                $pointer_id = $stage->id;
                $list_array['pointer_id'] = $pointer_id;
                $list_array['unique_id'] = application_mo($pointer_id);
                $list_array['portal_reference_no'] = portal_reference_no($pointer_id);

                $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['Applicant_name'] =   $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name;


                $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
                $Pathway =  (isset($s1_occupation->pathway) ? $s1_occupation->pathway : "");
                if ($Pathway == "Pathway 2") {
                    $list_array['Pathway'] = 'p2';
                } else {
                    $list_array['Pathway'] = 'p1';
                }
                $occupation_list = find_one_row('occupation_list', 'id', $s1_occupation->occupation_id);
                $list_array['occupation_name'] =  (isset($occupation_list->name) ? $occupation_list->name : "");

                $stage_1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['date_of_birth'] =  (isset($stage_1_personal_details->date_of_birth) ? $stage_1_personal_details->date_of_birth : "");

                $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
                $stage_index = application_stage_no($pointer_id);
                $list_array['approved_date']  =  $stage_1->approved_date;


                $list_array['Current_Status'] =  create_status_rename(create_status_format($stage_index));

                if (create_status_format($stage_index) == 'S2 - Start') {
                    $stage_status = 'S1 - ' . $stage->status;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $stage_status = 'S2 - ' . find_one_row('stage_2', 'pointer_id', $stage->id)->status;
                } else {
                    $stage_status = create_status_format($stage_index);
                }
                $list_array['application_status'] =  substr($stage_status, 0, 2);



                $stage_ = explode(" ", create_status_format($stage_index));

                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S2') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S3') {
                    // $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else {
                    // $get_submit_date = (isset(find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date)) ? find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date : "";
                    $get_submit_date =  $stage_1->submitted_date;
                }
                if (!empty($get_submit_date)) {
                    $list_array['submitted_date'] = $get_submit_date;
                    $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
                } else {
                    $list_array['submitted_date'] =  "";
                    $list_array['submitted_date_format'] =  "";
                }



                $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $pointer_id);
                $list_array['additional_info_request'] =  $additional_info_request;

                $all_list[] = $list_array;
            }
        }


        $data['all_list'] = $all_list;



        return view('admin/application_manager/index', $data);
    }

    // ---------------admin Application Manager -> view/update ----------------

    public function view_application($pointer_id, $tab)
    {
        $get_id = find_one_row('application_pointer', 'id', $pointer_id);
        $user_id = $get_id->user_id;
        if (session()->get('admin_account_type') == 'admin') {
            $data['stage_1'] = $this->stage_1_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_2'] = $this->stage_2_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            //    echo  $this->stage_2_model->getLastQuery();
            $data['stage_3'] = $this->stage_3_model->asObject()->where('pointer_id', $pointer_id, 'status', ['Submitted', 'Lodged', 'In Progress', 'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
        } else {
            $data['stage_1'] = $this->stage_1_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_2'] = $this->stage_2_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
            $data['stage_3'] = $this->stage_3_model->asObject()->where('pointer_id', $pointer_id, 'status', ['In Progress', 'Lodged',  'Approved', 'Declined', 'Withdrawn', 'Expired'])->first();
        }
        $data['username'] =  $this->user_account_model->asObject()->find($user_id);
        $data['s1_personal_details'] =  $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['s1_contact_details'] =  $this->stage_1_contact_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['s1_occupation'] =  $this->stage_1_occupation_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['additional_info_request'] = $this->additional_info_request_model->asObject()->where('pointer_id', $pointer_id)->first();
        $data['stage_1_documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_1'])->findAll();
        $data['stage_3_documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->whereNotIn('required_document_id', [23, 24, 25, 26])->findAll();
        $data['stage_2_add_employees'] = $this->stage_2_add_employment_model->asObject()->where('pointer_id', $pointer_id)->findAll();
        $data['application_pointer'] = $this->application_pointer_model->asObject()->where('id', $pointer_id)->first();
        $data['stage_2_email_verification'] = $this->email_verification_model->asObject()->where('pointer_id', $pointer_id)->findAll();
        $data['stage_3_documents_vhp'] = $this->documents_model->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->findAll();


        $data['pointer_id'] = $pointer_id;
        $data['user_id'] = $user_id;
        $data['tab'] = $tab;
        $data['is_uploaded_admin_doc'] =  $this->email_verification_model->asObject()->where('pointer_id', $pointer_id)->first();

        
             $offline_locations = $this->stage_3_offline_location_model->find();

            $country = array();

            foreach ($offline_locations as $key => $value) {

                if (!in_array($value['country'], $country)) {

                    $country[] = $value['country'];

                }

            }


         $location = array();

            foreach ($country as $key => $value) {

                $offline_location = $this->stage_3_offline_location_model->where(['country' => $value])->find();

                $location[$value] = $offline_location;

            }



            $data['location']=$location;

             $data['time_zone'] = $this->time_zone_model->groupBy('zone_name')->findAll();


        return view('admin/application_manager/view_application', $data);
    }
    // ---------------admin  Application Manager -> view/update -> stage 1 -> update Head Office Unique Number----------------
    public function update_unique_no()
    {

        $pointer_id = $this->request->getVar('pointer_id');
        $unique_head_office_no = $this->request->getVar('unique_head_office_no');
        $allocate_team_member_name = $this->request->getVar('Assigned_Team_Member_id');

        $output = $this->stage_1_model->where(['pointer_id' => $pointer_id])->set(['unique_id' => $unique_head_office_no, 'allocate_team_member_name' => $allocate_team_member_name])->update();
        $json = ["error" => 1];
        if ($output) {
            $json = [
                "error" => 0,
                "msg"   => "Successfully",
            ];
        }

        echo json_encode($json);
    }
    // ---------------admin Application Manager -> documents ->comments for all stages ----------------
    public function comments_for_document()
    {
        $reasons = $this->request->getPost('reason');
        $stages = $this->request->getPost('stage');
        $pointer_ids = $this->request->getPost('pointer_id');
        $document_ids = $this->request->getPost('document_id');
        $request_additional = $this->request->getPost("request_additional");


        if (!empty($request_additional)) {
            $addition_data = array(
                'pointer_id' => $pointer_ids[0],
                'stage' => $stages[0],
                'reason' => $request_additional,
                'status' => 'send',
                'send_by' => session()->get('admin_id')

            );
            $this->additional_info_request_model->insert($addition_data);
        }


        if ($reasons != "") {
            foreach ($reasons as $key => $value) {
                if ($value) {
                    $reason = $value;
                    $stage =  $stages[$key];
                    $pointer_id =  $pointer_ids[$key];
                    $document_id =  $document_ids[$key];

                    $data = array(
                        'pointer_id' => $pointer_id,
                        'stage' => $stage,
                        'document_id' => $document_id,
                        'reason' => $reason,
                        'status' => 'send',
                        'send_by' => session()->get('admin_id')
                    );
                    $this->additional_info_request_model->insert($data);
                }
                $key++;
            }
        }

        if ($stages[0] == 'stage_1') {
            // s1_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '16'])->first();
        } elseif ($stages[0] == 'stage_2') {
            // s2_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '18'])->first();
        } elseif ($stages[0] == 'stage_3') {
            // s3_request_additional_agent
            $mail_temp = $this->mail_template_model->asObject()->where(['id' => '33'])->first();
        }
        $pointer_id = $pointer_ids[0];

        $user_id = find_one_row("application_pointer", "id", $pointer_id)->user_id;
        $user_email = find_one_row("user_account", "id", $user_id)->email;
        $subject = mail_tag_replace($mail_temp->subject, $pointer_id);
        $message = mail_tag_replace($mail_temp->body, $pointer_id);
        $to = $user_email;


        $addReplyTo_array = [];
        if (session()->get('admin_account_type') == "head_office") {
            $addBCC_array = [env('ADMIN_EMAIL')];
        } else {
            $addBCC_array = [];
        }
        $addCC_array = [];
        $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, $addReplyTo_array, $addBCC_array, $addCC_array);


        if ($check == 1) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }

    // ---------------admin Application Manager -> documents -> documents delete for all stages ----------------
    public function delete_document($id)
    {
        $document = find_one_row("documents", "id", $id);
        $file = $document->document_path . '/' . $document->document_name;
        unlink($file);
        if ($this->documents_model->where('id', $id)->delete()) {
            $callback = array(
                "color" => "success",
                "msg" => "Delete recode",
                "response" => true,
            );
        } else {
            $callback = array(
                "msg" => "unable to delete record",
                "color" => "danger",
                "response" => false,
            );
        }
        echo json_encode($callback);
    }


    public function  upload_exemption_file(){



  $pointer_id = $this->request->getPost('pointer_id');
    $time_zone = $this->request->getPost('time_zone');

    $preference_location = "Online (Via Zoom)";//$this->request->getPost('preference_location');


        $file = $this->request->getFile('exemption_file');

         print_r($file);
       //  exit;

        $uploaded_filename =  $file->getName();

        $File_extention = $file->getClientExtension();

        $original_file_name = str_replace($uploaded_filename, 'Exemption form.' . $File_extention, $uploaded_filename);

        $target = 'public/application/' . $pointer_id . '/stage_2/assessment_documents';
 
        $file->move($target, $original_file_name, true);



        $data = array(


            'exemption_form' => $original_file_name,
            'preference_location'=>$preference_location,
            'time_zone'=>$time_zone
        );
        $update =   $this->stage_3_model->where('pointer_id', $pointer_id)->set($data)->update();


        if($update) {

            $callback = array(

                "color" => "success",

                "msg" => "file uploaded succesfully",

                "response" => true,

                'pointer_id' => $pointer_id,

            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "mail not send",

            //     "color" => "danger",

            //     "response" => false,

            //     'pointer_id' => $pointer_id,

            // );

        }


   

}
    // ---------------admin Application Manager -> exemption file -> exemption file delete ----------------
 public function delete_exemption_file($id)

    {
        $pointer_id=$id;
        //echo $pointer_id;
        $exemption_file=$this->stage_3_model->where('pointer_id', $id)->find();
        // print_r($exemption_file) ;
        //exit;

       $file = $exemption_file[0]['exemption_form'];//$document->document_path . '/' . $document->document_name;

        //unlink($file);
      // $data = array('exemption_form' =>'' );
        $update= $this->stage_3_model->where('pointer_id',$pointer_id)->set(['exemption_form'=>NULL])->update();

        if($update){

            $callback = array(

                "color" => "success",

                "msg" => "Delete recode",

                "response" => true,
            );
                    echo json_encode($callback);


        } else {

            // $callback = array(

            //     "msg" => "unable to delete record",

            //     "color" => "danger",

            //     "response" => false,

            // );

        }


    }




    // ---------------admin Application Manager -> documents -> documents zip for all stages ----------------
    public function download_zip($pointer_id, $stage)
    {
        $dirs = [];
        $s1_personal_details =  $this->stage_1_personal_details_model->asObject()->where('pointer_id', $pointer_id)->first();
        $name = $s1_personal_details->first_or_given_name . ' ' . $s1_personal_details->middle_names . ' ' . $s1_personal_details->surname_family_name;
        $all_file_array = array();
        $target = "public/application/" . $pointer_id . '/' . $stage;
        if ($stage == "stage_1") {
            $zip_file = str_replace("stage_1", "Stage 1 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            $stage_1_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_1'])->findAll();
            foreach ($stage_1_documents as $stage_1_document) {
                $single_file_array = array();
                $single_file_array['document_path'] = $stage_1_document->document_path;
                $single_file_array['document_name'] = $stage_1_document->document_name;
                $all_file_array[] = $single_file_array;
            }
        } else if ($stage == "stage_2") {
            $zip_file = str_replace("stage_2", "Stage 2 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            $stage_2_documents = $this->documents_model->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_2'])->find();

            foreach ($stage_2_documents as $key => $value) {
                $array_path = explode("/", $value['document_path']);
                if (isset($array_path[4])) {
                    $company_folder_name = $array_path[4];
                    $single_file_array = array();
                    if ($company_folder_name == "assessment_documents") {
                        $company_folder_name = "Assessment Documents";
                    }
                    $single_file_array['company_folder_name'] = $company_folder_name;
                    $single_file_array['document_path'] = $value['document_path'];
                    $single_file_array['document_name'] = $value['document_name'];
                    $all_file_array[] = $single_file_array;
                } else {
                    $single_file_array = array();
                    $single_file_array['company_folder_name'] = 'Additional Information';
                    $single_file_array['document_path'] = $value['document_path'];
                    $single_file_array['document_name'] = $value['document_name'];
                    $all_file_array[] = $single_file_array;
                }
            }


            // foreach ($stage_2_documents as $stage_2_document) {
            //     $single_file_array = array();
            //     $single_file_array['document_path'] = $stage_2_document['document_path'];
            //     $single_file_array['document_name'] = $stage_2_document['document_name'];
            //     $all_file_array[] = $single_file_array;
            // }
        } else if ($stage == "stage_3") {
            $zip_file = str_replace("stage_3", "Stage 3 - ", $stage) . "" . $name . ".zip";
            $zipname =  $target . "/" . $zip_file;
            $stage_2_documents = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'status' => 1, 'stage' => 'stage_3'])->findAll();
            foreach ($stage_2_documents as $stage_2_document) {
                $single_file_array = array();
                $single_file_array['document_path'] = $stage_2_document->document_path;
                $single_file_array['document_name'] = $stage_2_document->document_name;
                $all_file_array[] = $single_file_array;
            }
        }

        $zip = new ZipArchive;
        if ($zip->open($zipname, ZIPARCHIVE::CREATE | ZipArchive::OVERWRITE) === false) {
            die("An error occurred creating your ZIP file.");
        } else {
            if ($stage == "stage_2") {
                foreach ($all_file_array as $key => $value) {
                    $path =  $value['document_path'];
                    $document_name =  $value['document_name'];
                    // for folder data 
                    if (isset($value['company_folder_name'])) {
                        $company_folder_name =  $value['company_folder_name'];
                        $zip->addFile($path . "/" . $document_name, $company_folder_name . '/' . $document_name);
                    } else {
                        // for off folder data 
                        $zip->addFile($path . "/" . $document_name, $document_name);
                    }
                } // for loop
            } else {
                //  for stage 1 and stage 3 
                foreach ($all_file_array as $key => $value) {
                    $path =  $value['document_path'];
                    $document_name =  $value['document_name'];
                    if (!str_contains($path, 'Photos_Videos')) {
                        if (!str_contains($document_name, 'PV_')) {
                            // echo $path ."/". $document_name;
                            // echo $document_name;
                            $zip->addFile($path . "/" . $document_name, $document_name);
                        }
                    }
                    if ($stage == "stage_1") {
                        $zip->addFile($path . "/TRA Application Form.pdf", "TRA Application Form.pdf");
                    }
                    if (str_contains($path, 'Photos_Videos')) {
                        if (str_contains($document_name, 'PV_')) {
                            $zip->addFile($path . "/" . $document_name, "Photos_Videos/" . $document_name);
                        }
                    }
                }
            }
            $zip->close();
        }

        $zipname = str_replace("index.php/", "", $zipname);
        echo base_url() . "/" . $zipname;
    }


    // ---------------admin Application Manager -> documents ->stage 1 -> Verification Email - Qualification ---------------
    public function verify_email_stage_1()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $file = $this->request->getFile('file');

        $uploaded_filename =  $file->getName();
        $File_extention = $file->getClientExtension();
        $original_file_name = str_replace($uploaded_filename, 'Verification - Qualification.' . $File_extention, $uploaded_filename);
        $target = 'public/application/' . $pointer_id . '/stage_1';

        $file->move($target, $original_file_name, true);

        $addition_data = array(
            'pointer_id' => $pointer_id,
            'stage' => 'stage_1',
            'required_document_id' => 21,
            'name' => 'Verification - Qualification',
            'document_name' => $original_file_name,
            'document_path' => $target,
            'status' => 1,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' => date("Y-m-d H:i:s")
        );
        if ($this->documents_model->insert($addition_data)) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }

    // attc
    // ---------------admin Application Manager -> documents ->stage 2 -> Send -> Email to All Employees ---------------
    public function send_email_employ_stage_2()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $user = find_one_row('application_pointer', 'id', $pointer_id);

        // email send data ------------
        // s2_send_email_employee
        $mail_temp_1 = $this->mail_template_model->asObject()->where(['id' => '45'])->first();
        $mail_subject = mail_tag_replace($mail_temp_1->subject, $pointer_id);
        $mail_body = mail_tag_replace($mail_temp_1->body, $pointer_id);
        $employes = find_multiple_rows('stage_2_add_employment', 'pointer_id', $pointer_id);
        $mail_check = 0;
        $database_check = 0;
        foreach ($employes as $employe) {
            // email send ------------
            $subject = str_replace('%add_employment_company_name%', $employe->company_organisation_name, $mail_subject);
            $message = str_replace('%add_employment_referee_name%', $employe->referee_name, $mail_body);
            $to = $employe->referee_email;
            $employe_id = $employe->id;
            $check_exist =    $this->email_verification_model->where(['verification_email_send' => 1, 'pointer_id' => $pointer_id, 'employer_id' => $employe->id])->first();
            if (empty($check_exist)) {
                $documents = $this->documents_model->asObject()->where(['employee_id' => $employe_id, 'pointer_id' => $pointer_id, 'required_document_id' => 10])->first();
                $addAttachment = [];
                if (!empty($documents)) {
                    $document_name = $documents->document_name;
                    $document_path = $documents->document_path;
                    $file_name = $documents->name;
                    if (file_exists($document_path . "/" . $document_name)) {
                        $addAttachment = array(
                            [
                                'file_path' => $document_path . "/" . $document_name,
                                'file_name' => $document_name
                            ]
                        );
                    }
                }
                $check = verification_(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], [], $addAttachment);
                if ($check == 1) {
                    $mail_check++;
                    $data = array(
                        'pointer_id' => $pointer_id,
                        'verification_type' => 'Verification - Employment',
                        'employer_id' => $employe->id,
                        'verification_email_id' => $employe->referee_email,
                        'verification_email_subject' => $subject,
                        'verification_email_send' => 1,
                        'verification_email_send_date' => date("Y-m-d H:i:s"),
                        'update_date' => date("Y-m-d H:i:s"),
                        'create_date' => date("Y-m-d H:i:s")
                    );

                    if ($this->email_verification_model->insert($data)) {
                        $database_check++;
                    }
                } // check email send
            }
        } // loop


        if ($mail_check > 0 || $database_check > 0) {
            $callback = array(
                'mail_check' => $mail_check,
                'database_check' => $database_check,
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    // attc

    // ---------------admin Application Manager -> documents ->stage 2 -> Verification Email - Employment ---------------
    public function verify_email_stage_2()
    {
        $pointer_id = $this->request->getPost('pointer_id');
        $file = $this->request->getFile('file');

        $uploaded_filename =  $file->getName();
        $File_extention = $file->getClientExtension();
        $original_file_name = str_replace($uploaded_filename, 'Verification - Employment.' . $File_extention, $uploaded_filename);
        $target = 'public/application/' . $pointer_id . '/stage_2/assessment_documents';

        $file->move($target, $original_file_name, true);

        $addition_data = array(
            'pointer_id' => $pointer_id,
            'stage' => 'stage_2',
            'required_document_id' => 21,
            'employee_id' => 0,
            'name' => 'Verification - Employment',
            'document_name' => $original_file_name,
            'document_path' => $target,
            'status' => 1,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' => date("Y-m-d H:i:s")
        );
        if ($this->documents_model->insert($addition_data)) {
            $callback = array(
                "color" => "success",
                "msg" => "mail send succesfully",
                "response" => true,
                'pointer_id' => $pointer_id,
            );
        } else {
            $callback = array(
                "msg" => "mail not send",
                "color" => "danger",
                "response" => false,
                'pointer_id' => $pointer_id,
            );
        }
        echo json_encode($callback);
    }
    // ---------------admin Applicant and Agent -> applicant name or agent company name -> Application Manager filter by user id---------------
    public function filter_company($id)
    {

        $user_id = $id;

        $data['page_name'] = 'Application Manager';

        $status_list = ['Start', 'Submitted', 'Lodged', 'In Progress', 'Scheduled', 'Conducted', 'Approved', 'Declined', 'Withdrawn', 'Expired'];

        $all_list = array();
        $application_pointer_model = $this->application_pointer_model->asObject()->orWhereIn('status', $status_list)->where("user_id", $user_id)->orderby('create_date', 'DESC')->findAll();

        $i = 0;
        $aaa = array();
        foreach ($application_pointer_model as $stage) {

            $show = true;
            if ($stage->stage == "stage_1") {
                if ($stage->status == "Start") {
                    $show = false;
                }
            }
            if ($show) {
                $i++;
                $asdasd = $stage->stage . " " . $stage->status;
                if (!in_array($asdasd, $aaa)) {

                    $aaa[] = $asdasd;
                }



                $list_array = array();

                $pointer_id = $stage->id;
                $list_array['pointer_id'] = $pointer_id;
                $list_array['unique_id'] = application_mo($pointer_id);
                $list_array['portal_reference_no'] = portal_reference_no($pointer_id);

                $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['Applicant_name'] =   $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name;


                $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
                $Pathway =  (isset($s1_occupation->pathway) ? $s1_occupation->pathway : "");
                if ($Pathway == "Pathway 2") {
                    $list_array['Pathway'] = 'p2';
                } else {
                    $list_array['Pathway'] = 'p1';
                }
                $occupation_list = find_one_row('occupation_list', 'id', $s1_occupation->occupation_id);
                $list_array['occupation_name'] =  (isset($occupation_list->name) ? $occupation_list->name : "");

                $stage_1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
                $list_array['date_of_birth'] =  (isset($stage_1_personal_details->date_of_birth) ? $stage_1_personal_details->date_of_birth : "");

                $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
                $stage_index = application_stage_no($pointer_id);


                $list_array['Current_Status'] =  create_status_rename(create_status_format($stage_index));

                if (create_status_format($stage_index) == 'S2 - Start') {
                    $stage_status = 'S1 - ' . $stage->status;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    $stage_status = 'S2 - ' . find_one_row('stage_2', 'pointer_id', $stage->id)->status;
                } else {
                    $stage_status = create_status_format($stage_index);
                }
                $list_array['application_status'] =  substr($stage_status, 0, 2);



                $stage_ = explode(" ", create_status_format($stage_index));

                if ($stage_[0] == 'S1') {
                    $get_submit_date = $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S2 - Start') {
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S2') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if (create_status_format($stage_index) == 'S3 - Start') {
                    // $get_submit_date = find_one_row('stage_2', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else if ($stage_[0] == 'S3') {
                    // $get_submit_date = find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date;
                    $get_submit_date =  $stage_1->submitted_date;
                } else {
                    // $get_submit_date = (isset(find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date)) ? find_one_row('stage_3', 'pointer_id', $pointer_id)->submitted_date : "";
                    $get_submit_date =  $stage_1->submitted_date;
                }
                if (!empty($get_submit_date)) {
                    $list_array['submitted_date'] = $get_submit_date;
                    $list_array['submitted_date_format'] = date('d/m/Y', strtotime($get_submit_date));
                } else {
                    $list_array['submitted_date'] =  "";
                    $list_array['submitted_date_format'] =  "";
                }



                $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $pointer_id);
                $list_array['additional_info_request'] =  $additional_info_request;

                $all_list[] = $list_array;
            }
        }


        $data['all_list'] = $all_list;


        return view('admin/application_manager/index', $data);
    }

    public function save_Assigned_Team_Member($pointer_id)
    {
        if (!empty($pointer_id)) {
            $team_id = $_POST['selectedValue'];
            echo $this->stage_1_model->where(['pointer_id' => $pointer_id])->set(['allocate_team_member_name' => $team_id])->update();
        }
    }
}
