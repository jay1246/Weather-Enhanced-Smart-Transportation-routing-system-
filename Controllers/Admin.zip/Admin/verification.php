<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class verification extends BaseController
{
    public function index()
    {
        $data['title'] = "verification";

        $data['applications'] = $this->application_pointer_model->asObject()->where(['stage' => 'stage_2', 'status' => 'Submitted'])->findAll();
        $data['stage_2_documents'] = $this->documents_model->asObject()->where(['status' => 1])->findAll();

        return view('admin/verification/index', $data);
    }
    public function view($pointer_id)
    {
        $data['title'] = "verification view";
        $applicant = find_one_row('application_pointer', 'id', $pointer_id);
        $data['stage_1'] = $this->stage_1_model->asObject()->where(['pointer_id' => $pointer_id])->findAll();
        $data['s1_personal_details'] =  $this->stage_1_personal_details_model->asObject()->where(['pointer_id' => $pointer_id])->first();
        $data['user_account'] =  $this->user_account_model->asObject()->where('id', $applicant->user_id)->first();
        $data['employs'] =  $this->stage_2_add_employment_model->asObject()->where(['pointer_id' => $pointer_id])->findAll();
        $data['pointer_id'] = $pointer_id;
        // vishal patel 28-04-2023 
        $data['documents'] = $this->documents_model->asObject()->where(['pointer_id' => $pointer_id, 'stage' => 'stage_2'])->findAll();

        return view('admin/verification/view', $data);
    }



    public function Change_status($pointer_id, $employer_id, $status)
    { // v
        $sql =  $this->email_verification_model->where(['pointer_id' => $pointer_id, 'employer_id' => $employer_id])->first();
        if (!empty($sql)) {
            if ($status == "Pending") {
                $data = [
                    'is_verification_done' => 1,
                    'verification_email_received' => 1
                ];
            } else {
                $data = [
                    'is_verification_done' => 0,
                    'verification_email_received' => 0
                ];
            }
            // print_r($data);
            // exit;
            $this->email_verification_model->where(['pointer_id' => $pointer_id, 'employer_id' => $employer_id])->set($data)->update();
            $this->session->setFlashdata('msg', 'Status Change Successfully.');
            return redirect()->back();
        }
        $this->session->setFlashdata('error_msg', 'Sorry! Status Not Change.');
        return redirect()->back();
    }
    public function edite_and_email_send($pointer_id, $employer_id)
    {
        // echo "test";
        // exit;
        $pointer_id = $_POST['pointer_id'];
        $employer_id = $_POST['employer_id'];
        $referee_name = $_POST['referee_name'];
        $referee_email = $_POST['referee_email'];

        // vishal patel 28-04-2023
        $addAttachment = [];
        $document_ids = "";
        if (isset($_POST['document_ids'])) {
            $document_ids = json_encode($_POST['document_ids']);
            foreach (json_decode($document_ids) as $key => $value) {
                $documents = $this->documents_model->asObject()->where(['id' => $value, 'stage' => 'stage_2'])->first();
                if (!empty($documents)) {
                    $document_name = $documents->document_name;
                    $document_path = $documents->document_path;
                    // $document_name =  "header_logo.jpg";
                    // $document_path =  "public/assets/image/";
                    $file_name = $documents->name;
                    if (file_exists($document_path . "/" . $document_name)) {
                        $addAttachment[] =
                            [
                                'file_path' => $document_path . "/" . $document_name,
                                'file_name' => $document_name
                            ];
                    }
                }
            }
            $document_ids = json_encode($_POST['document_ids']);
        }
        // ---/---vishal patel 28-04-2023


        // get data 
        $get_data =  $this->stage_2_add_employment_model->where(['pointer_id' => $pointer_id, 'id' => $employer_id])->first();
        if (!empty($get_data)) {
            // update data 
            $data = [
                'referee_name' => $referee_name,
                'referee_email' => $referee_email,
            ];
            $update_check =  $this->stage_2_add_employment_model->where(['pointer_id' => $pointer_id, 'id' => $employer_id])->set($data)->update();
            if ($update_check) {
                // get data 
                $get_data =  $this->stage_2_add_employment_model->where(['pointer_id' => $pointer_id, 'id' => $employer_id])->first();
                $referee_name = $get_data['referee_name'];
                $referee_email = $get_data['referee_email'];
                $company_organisation_name = $get_data['company_organisation_name'];

                // email send ------------ s2_send_email_employee
                $mail_temp_1 = $this->mail_template_model->asObject()->where(['id' => '45'])->first();
                $mail_subject = mail_tag_replace($mail_temp_1->subject, $pointer_id);
                $mail_body = mail_tag_replace($mail_temp_1->body, $pointer_id);



                $documents = $this->documents_model->asObject()->where(['employee_id' => $employer_id, 'pointer_id' => $pointer_id, 'required_document_id' => 10])->first();
                if (!empty($documents)) {
                    $document_name = $documents->document_name;
                    $document_path = $documents->document_path;
                    $file_name = $documents->name;
                    if (file_exists($document_path . "/" . $document_name)) {
                        // vishal patel 28-04-2023
                        $addAttachment[] = [
                            'file_path' => $document_path . "/" . $document_name,
                            'file_name' => $document_name
                        ];
                    }
                }

                $subject = str_replace('%add_employment_company_name%', $company_organisation_name, $mail_subject);
                $message = str_replace('%add_employment_referee_name%', $referee_name, $mail_body);
                $to = $referee_email;
                $check = verification_(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message, [], [], [], $addAttachment);
                // after email send 
                if ($check == 1) {
                    // update data 
                    // vishal 17-04-2023
                    $check_table =  $this->email_verification_model->where(['pointer_id' => $pointer_id, 'employer_id' => $employer_id])->first();
                    if (!empty($check_table)) {
                        // $this->email_verification_model->asObject()->where('pointer_id', $pointer_id)->findAll();
                        // vishal patel 28-04-2023
                        $data = array(
                            'verification_email_id' => $referee_email,
                            'verification_email_send' => 1,
                            'verification_email_send_date' => date("Y-m-d H:i:s"),
                            'document_ids' => $document_ids,
                            'update_date' => date("Y-m-d H:i:s")
                        );
                        $update_email_verify =  $this->email_verification_model->where(['pointer_id' => $pointer_id, 'employer_id' => $employer_id])->set($data)->update();
                    } else {
                        // vishal 17-04-2023
                        // vishal patel 28-04-2023
                        $data = array(
                            'pointer_id' => $pointer_id,
                            'verification_type' => 'Verification Email - Employment',
                            'employer_id' => $employer_id,
                            'verification_email_id' => $referee_email,
                            'verification_email_subject' => $subject,
                            'verification_email_send' => 1,
                            'verification_email_send_date' => date("Y-m-d H:i:s"),
                            'document_ids' => $document_ids,
                            'update_date' => date("Y-m-d H:i:s"),
                            'create_date' => date("Y-m-d H:i:s")
                        );
                        $update_email_verify = $this->email_verification_model->insert($data);
                    }


                    if ($update_email_verify) {
                        $this->session->setFlashdata('error_msg', 'Information is updated and Email sent to ' . $referee_name);
                        return redirect()->back();
                    }
                } else {

                    $this->session->setFlashdata('error_msg', 'Sorry! email service is not working,');
                }
            } else {
                $this->session->setFlashdata('error_msg', 'Sorry! Referee Info Not Update.');
            }
        } else {
            $this->session->setFlashdata('error_msg', 'Sorry! Referee Not Find');
        }

        return redirect()->back();
    }
}
