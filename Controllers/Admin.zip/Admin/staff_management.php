<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
 
class staff_management extends BaseController 
{
    public function index()
    {
        $data['staffs'] = $this->admin_account_model->asObject()->findAll();

        $data['title'] = 'Staff Management';

        $data['countries'] = $this->country_model->asObject()->findAll();

        return view('admin/staff_management/index', $data);
    }

    public function insert()
    {
        $data = $this->request->getVar();

        $details = array(
            'first_name' => $data['first_name'],
            'middle_name' => $data['middle_name'],
            'last_name' => $data['last_name'],           
            'mobile_code' => $data['mobile_code'],
            'mobile_no' => $data['mobile_no'],
            'email' => $data['email'],
            'password' => $data['password'],
            'account_type' => $data['account_type'],             
            'status' => $data['status']
        );

        if($this->admin_account_model->insert($details)){
        $callback = array(
            "color" => "success",
            "msg" => "inserted recode",
            "response" => true,
        );
    }else{
        $callback = array(
            "msg" => "unable to insert record",
            "color" => "danger",
            "response" => false,
        );     
    }
        echo json_encode($callback);
    }


    public function update()
    {
        $data = $this->request->getvar();

        $id = $data['id'];

        $details = array(
            'first_name' => $data['first_name'],
            'middle_name' => $data['middle_name'],
            'last_name' => $data['last_name'],           
            'mobile_code' => $data['mobile_code'],
            'mobile_no' => $data['mobile_no'],
            'email' => $data['email'],
            'password' => $data['password'],
            'account_type' => $data['account_type'],             
            'status' => $data['status']
        );
        if($this->admin_account_model->update($id,$details)){
            $callback = array(
                "color" => "success",
                "msg" => "update recode",
                "response" => true,
            );
        }else{
            $callback = array(
                "msg" => "unable to update record",
                "color" => "danger",
                "response" => false,
            );
    
        }
        echo json_encode($callback);
    }

    public function delete($id)
    {
       if($this->admin_account_model->where('id', $id)->delete()){
        $callback = array(
            "color" => "success",
            "msg" => "Delete recode",
            "response" => true,
        );
        }else{
            $callback = array(                
                "msg" => "unable to delete record",
                "color" => "danger",
                "response" => false,
            );
 
        }
        echo json_encode($callback);

    }

    public function status($id)
    {
        $status = $this->admin_account_model->where('id',$id)->asObject()->first();
       if($status->status == "active"){
            $change_status ="inactive";
       }else{
        $change_status ="active";
       }
       $data = array(
        'status'=>$change_status
       );
       if($this->admin_account_model->update($id,$data)){
        $callback = array(
            "color" => "success",
            "msg" => "update status",
            "response" => true,
        );
        }else{
            $callback = array(                
                "msg" => "unable to update status",
                "color" => "danger",
                "response" => false,
            );
 
        }
        echo json_encode($callback);

    }


}