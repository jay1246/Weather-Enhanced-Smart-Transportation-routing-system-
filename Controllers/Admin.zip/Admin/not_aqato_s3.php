<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

use DateTime;
use DateTimeZone;

class not_aqato_s3 extends BaseController
{


    public function index()
    {
        // vishal patel 28-04-2023
        $data['interview_locations'] = $this->stage_3_offline_location_model->asObject()->findAll();
        $data['occupation_list'] = $this->occupation_list_model->asObject()->findAll();
        $data['stage_3_interview_booking_time_slots'] = $this->stage_3_interview_booking_time_slots_model->find();
        $data['not_aqato_s3_model'] =   $this->not_aqato_s3_model->asObject()->orderby('create_date', 'DESC')->findAll();

        return view('admin/interview_booking/not_aqato_s3', $data);
    }


    // -------------- interview_location end ----------------
    // public function interview_location()
    // {
    //     return view('admin/interview_location/index', $data);
    // }

    // admin/not_aqato_s3/insert_booking // vishal patel 28-04-2023
    public function insert_booking()
    {

        $full_name = $_POST['full_name'];
        $occupation_name = $_POST['occupation_name'];
        $unique_number = $_POST['unique_number'];
        $interview_location = $_POST['interview_location'];

        $date = $_POST['date'];
        $time = $_POST['time'];
        $datetime = \DateTime::createFromFormat('Y-m-d h:i A', $date . ' ' . $time);
        $interview_date = $datetime->format('Y-m-d H:i:s');

        $details = array(
            'full_name' => $full_name,
            'occupation_name' => $occupation_name,
            'unique_number' => $unique_number,
            'interview_date' => $interview_date,
            'interview_location' => $interview_location,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' =>  date("Y-m-d H:i:s")
        );

        $not_aqato_s3_Check = $this->not_aqato_s3_model->where(['unique_number' => $unique_number])->first();
        if (empty($not_aqato_s3_Check)) {
            if ($this->not_aqato_s3_model->insert($details)) {


                // vishal patel 28-04-2023

                // NON_AQATO_admin_head_office
                $mail_temp_3 = $this->mail_template_model->asObject()->where(['id' => '115'])->first();
                if (!empty($mail_temp_3)) {
                    $subject = $mail_temp_3->subject;
                    $body = $mail_temp_3->body;

                    $subject = str_replace('%full_name%', $full_name, $subject);
                    $subject = str_replace('%occupation_name%', $occupation_name, $subject);
                    $subject = str_replace('%unique_number%', $unique_number, $subject);

                    // stage 3 
                    if (isset($interview_location)) {
                        $stage_3_offline_location_id = $interview_location;
                        $date_time = $interview_date;

                        $s3_interview_day_and_date = "";
                        $s3_interview_time_A = "";
                        if (!empty($date_time)) {
                            $s3_interview_day_and_date = date('l, jS F Y', strtotime($date_time));
                            $s3_interview_time_A = date('h:i A', strtotime($date_time)) . " (Australia/Brisbane Time)";
                        }

                        $stage_3_offline_location = find_one_row('stage_3_offline_location', 'id', $stage_3_offline_location_id);

                        $date_time_zone = (isset($stage_3_offline_location->date_time_zone)) ? $stage_3_offline_location->date_time_zone : "";


                        $s3_interview_venue = (isset($stage_3_offline_location->venue)) ? $stage_3_offline_location->venue : "";
                        $s3_interview_address = (isset($stage_3_offline_location->office_address)) ? $stage_3_offline_location->office_address : "";

                        $s3_interview_time_B = "";
                        if (!empty($date_time_zone)) {
                            if (!empty($date_time)) {
                                $date = new DateTime(date('Y-m-d H:i:s', strtotime($date_time)));
                                $date->setTimezone(new DateTimeZone($date_time_zone));
                                $s3_interview_time_B = $date->format('h:i A') . " (" . $date_time_zone . " Time)";
                            }
                        }

                        $body = str_replace('%s3_interview_day_and_date%', $s3_interview_day_and_date, $body);
                        $body = str_replace('%s3_interview_time%', $s3_interview_time_A . " / " . $s3_interview_time_B, $body);
                        $body = str_replace('%s3_interview_venue%', $s3_interview_venue, $body);
                        $body = str_replace('%s3_interview_address%', $s3_interview_address, $body);
                    }



                    // Applicant Email
                    $to = env('HEADOFFICE_EMAIL');
                    $mail_check_1 = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $body);
                    $to = env('ADMIN_EMAIL');
                    $mail_check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $body);
                    if ($mail_check == 1) { // vishal patel 28-04-2023
                        echo "ok";
                    }
                }
            }
        } else {
            echo "exist not add";
        }
    }

    public function insert_booking_edite()
    {

        $full_name = $_POST['full_name'];
        $occupation_name = $_POST['occupation_name'];
        $unique_number = $_POST['unique_number'];
        $interview_location = $_POST['interview_location'];

        $date = $_POST['date'];
        $time = $_POST['time'];
        $datetime = \DateTime::createFromFormat('Y-m-d h:i A', $date . ' ' . $time);
        $interview_date = $datetime->format('Y-m-d H:i:s');

        $details = array(
            'full_name' => $full_name,
            'occupation_name' => $occupation_name,
            'unique_number' => $unique_number,
            'interview_date' => $interview_date,
            'interview_location' => $interview_location,
            'update_date' => date("Y-m-d H:i:s"),
            'create_date' =>  date("Y-m-d H:i:s")
        );

        $not_aqato_s3_Check = $this->not_aqato_s3_model->where(['unique_number' => $unique_number])->first();
        if (!empty($not_aqato_s3_Check)) {
            if ($this->not_aqato_s3_model->set($details)->where(['unique_number' => $unique_number])->update()) {
                echo "ok";
                return redirect()->to(base_url('admin/not_aqato_s3'));
            }
        }
    }
}
