<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

// stage 3 ---------------------------------------- 

class receipt_upload extends BaseController
{
    public function receipt_upload_page($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        // if (empty($stage_3)) {
        //     $this->stage_3_model->insert(['pointer_id' => $pointer_id, 'status' => 'Start']);
        // }
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        $status = (!empty($stage_3['status']) ? $stage_3['status'] : "");

        if ($status == "" || $status == "Start") {
            $receipt_number = (!empty($stage_3['receipt_number']) ? $stage_3['receipt_number'] : "");
            $payment_date = "";
            if (!empty($stage_3['payment_date']) && $stage_3['payment_date'] != "0000-00-00 00:00:00") {
                $payment_date = (!empty($stage_3['payment_date']) ?  date("d/m/Y", strtotime($stage_3['payment_date'])) : "");
            }
            $preference_location =  (!empty($stage_3['preference_location']) ? $stage_3['preference_location'] : "");
            $preference_comment = (!empty($stage_3['preference_comment']) ? $stage_3['preference_comment'] : "");
            $exemption_yes_no = (!empty($stage_3['exemption_yes_no']) ? $stage_3['exemption_yes_no'] : "");
            $documents = $this->documents_model->where(["pointer_id" => $pointer_id, 'required_document_id' => 19, 'stage' => 'stage_3'])->first();
            $document_full_name = (isset($documents['document_name']) ? $documents['document_name'] : "");
            $document_path = (isset($documents['document_path']) ? $documents['document_path'] : "");
            $document_id = (isset($documents['id']) ? $documents['id'] : "");
            $document_name = (isset($documents['name']) ? $documents['name'] : "");
            if (!empty($document_name)) {
                $file_uploaded = true;
            } else {
                $file_uploaded = false;
            }
            
            // Excemption Form Code
             $document_full_name_ex = $document_path_ex = $document_name_ex = $document_id_ex ="";
            // echo "ffdfdnxbcbcb";
                $file_uploaded_ex = false;
                if(!empty($stage_3['download_ex_form'])){
                    $value_of_download_ex_form = $stage_3['download_ex_form'];
                }else {
                    $value_of_download_ex_form = 0;
                }
                // echo $exemption_yes_no;
                 if($exemption_yes_no == 'yes'){
                $download_ex_form = (!empty($stage_3['download_ex_form']) ? $stage_3['download_ex_form'] : "");
                $file_uploaded_ex = true;
                }else{
                    $file_uploaded_ex = false;
                    $download_ex_form =1;
                }
                      $documents_exception = $this->documents_model->where(["pointer_id" => $pointer_id, 'required_document_id' => 43, 'stage' => 'stage_3'])->first();
            // print_r($documents_exception);
            if($documents_exception){
                $document_full_name_ex = (isset($documents_exception['document_name']) ? $documents_exception['document_name'] : "");
                $document_path_ex = (isset($documents_exception['document_path']) ? $documents_exception['document_path'] : "");
                $document_name_ex = (isset($documents_exception['name']) ? $documents_exception['name'] : "");
                $document_id_ex = (isset($documents_exception['id']) ? $documents_exception['id'] : "");
                if (!empty($document_name_ex)) {
                    $file_uploaded_ex = true;
                } else {
                    $file_uploaded_ex = false;
                }
                 
            }
           
            $offline_locations = $this->stage_3_offline_location_model->find();
            $country = array();
            foreach ($offline_locations as $key => $value) {
                if (!in_array($value['country'], $country)) {
                    $country[] = $value['country'];
                }
            }
            $location = array();
            foreach ($country as $key => $value) {
                $offline_location = $this->stage_3_offline_location_model->where(['country' => $value])->find();
                $location[$value] = $offline_location;
            }



            // Get the Occupation
             $enroll_stage_4 = false;
            $occupation = $this->stage_1_occupation_model->where("pointer_id", $pointer_id)->asObject()->first();
            if($occupation->pathway == "Pathway 1"){
                if($occupation->occupation_id == 7 || $occupation->occupation_id == 18){
                    $enroll_stage_4 = true;
                }
            }
            // echo $occupation->pathway;
            // echo $occupation->occupation_id;
            // print_r($enroll_stage_4);
            // exit;
            // end


            $data["page"] = 'TRA Payment Receipt Number';
            $data["pointer_id"] = $pointer_id;
            $data["exemption_yes_no"] = $exemption_yes_no;
            
            $data["ENC_pointer_id"] = $ENC_pointer_id;
            $data["receipt_number"] = $receipt_number;
            $data["payment_date"] = $payment_date;
            $data["preference_location"] = $preference_location;
            $data["preference_comment"] = $preference_comment;
            $data["document_name"] = $document_name;
            $data["document_full_name"] = $document_full_name;
            $data["document_path"] = $document_path;
            $data["document_id"] = $document_id;
            $data["file_uploaded"] = $file_uploaded;
            $data["location"] = $location;
            $data["document_name_ex"] = $document_name_ex;
            $data["document_full_name_ex"] = $document_full_name_ex;
            $data["document_path_ex"] = $document_path_ex;
            $data["document_id_ex"] = $document_id_ex;
            $data["file_uploaded_ex"] = $file_uploaded_ex;
            $data['download_ex_form'] =$download_ex_form;
            $data['value_of_download_ex_form'] = $value_of_download_ex_form;
            $data["enroll_stage_4"] = $enroll_stage_4;
            // echo "<pre>";
            // print_r($data);
            // exit;
            return view('user/stage_3/receipt_upload', $data);
        }
        // return view('user/dashboard');
        return redirect()->to('user/dashboard');
    }

    public function valication($ENC_pointer_id){
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
         $stage_3 = $this->stage_3_model->where('pointer_id', $pointer_id)->first();
        //  print_r($stage_3);
        $exemption_type = $stage_3['exemption_yes_no'];
        if($exemption_type =='no'){
            
            $documents = $this->documents_model->where(['pointer_id'=> $pointer_id,'required_document_id'=>43])->first();
            // print_r($documents);
            // exit;
            if (!empty($documents)) {
                $file_path =  $documents['document_path'] . '/' . $documents['document_name'];
                
                if (file_exists($file_path)) {
                    if (unlink($file_path)) {
                        echo "unlink";
                    }else{
                        echo "not unlink";
                    }
                }
                    $data = [
                        "exemption_form"=>'',
                    ];
                    
                $this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update();
                
                $this->documents_model->where('id',$documents['id'])->delete();
            }
        }
        if($stage_3['receipt_number']!=""){
            if($stage_3['payment_date'] !="0000-00-00 00:00:00" || $stage_3['payment_date'] !="" || $stage_3['payment_date'] !=null ){
                  $json = [
                        "msg" => "Procced",
                        "error" => 0,
                    ];
                    echo json_encode($json);
                    exit;
                
            }else{
                  $json = [
                            "msg" => "Payment Date is Required",
                            "error" => 1,
                        ];
                        echo json_encode($json);
                        exit;
                      
            }
        }else{
              $json = [
                            "msg" => "TRA Payment Receipt Number is Required",
                            "error" => 1,
                        ];
                        echo json_encode($json);
                        exit;
                      
        }
    }

    // ajax ----------
    // public function save_Preferred_info_($ENC_pointer_id)
    // {
    //     $pointer_id = pointer_id_decrypt($ENC_pointer_id);

    //     $data = $this->request->getVar();
    //     $preference_comment = "";
    //     if (isset($data['preference_comment'])) {
    //         $preference_comment = $data['preference_comment'];
    //     }
    //     $preference_location = "";
    //     if (isset($data['preference_location'])) {
    //         $preference_location = $data['preference_location'];
    //     }

    //     $details = [
    //         'preference_comment' => $preference_comment,
    //         'preference_location' => $preference_location,
    //     ];
    //     $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->set($details)->update();
    //     if ($stage_3) {
    //         echo "done";
    //     } else {
    //         echo "sorry";
    //     }
    // }

    // ajax ----------
    public function get_addresh_()
    {
        $city_name = $_POST['city_name'];
        $offline_locations = $this->stage_3_offline_location_model->where('city_name', $city_name)->first();
        return json_encode($offline_locations);
    }
    public function exemption_form($ENC_pointer_id){
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
    
        $session = session();

          $file_exemption_uploaded =  $this->request->getFile('file_exemption');
        
        // print_r($file_exemption_uploaded);
        // echo "sdgdgf";
        // exit;
        $file_name_with_extention_of_exemption ="";
        if ($file_exemption_uploaded) {

            if($file_exemption_uploaded->getName()){
                $file_exemption_uploaded_extention = $file_exemption_uploaded->getClientExtension();

                $file_exemption_required = $this->required_documents_list_model->where(["stage" =>"stage_3",'category'=>'exemption_form'])->first();
                
                $folder_path_exemption = 'public/application/'.$pointer_id .'/stage_3';
                $document_name_exemption = $file_exemption_required["document_name"];
                $file_name_with_extention_of_exemption = $document_name_exemption . '.' . $file_exemption_uploaded_extention;
                if (!is_dir($folder_path_exemption)) {
                    mkdir($folder_path_exemption);
                }
                // move file to folder 
                $is_move_exemption_file = $file_exemption_uploaded->move($folder_path_exemption, $file_name_with_extention_of_exemption, true);
                // echo $is_move_exemption_file;
                // exit;
                 $file_exemption_document = [
                            'pointer_id' => $pointer_id,
                            'stage' => 'stage_3',
                            'required_document_id' => $file_exemption_required['id'],
                            'name' => $file_exemption_required["document_name"],
                            'document_name' => $file_name_with_extention_of_exemption,
                            'document_path' => $folder_path_exemption,
                            'document_type' => '',
                            'status' => 1
                        ];
                      $this->documents_model->insert($file_exemption_document);
                    //   exit;
                }
        }
                      $data=[  
                          "exemption_form"=>$file_name_with_extention_of_exemption,
                          'exemption_yes_no'=>'yes',
                          ];
            if ($this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update()) {
               $this->session->setFlashdata('msg', 'File Uploaded Successfully.');
                } else {
                    $this->session->setFlashdata('error_msg', 'File Uploading Error.');
                }    
                 return redirect()->back();
      
    }
    public function exemption_data($ENC_pointer_id){
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);

        $session = session();

        $exemption_yes_no =  $this->request->getPost('exemption_yes_no');
        $download_ex_form =  $this->request->getPost('download_ex_form');
        $stage_3 = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
            echo $download_ex_form;
            // exit;
        if (!empty($exemption_yes_no)) {
            if (empty($stage_3)) {
                $this->stage_3_model->insert(['pointer_id' => $pointer_id, 'status' => 'Start']);
            }
        }
    
        // echo $exemption_yes_no;
    //     if($exemption_yes_no !=""){
    //          $stage_3 = $this->stage_3_model->where('pointer_id', $pointer_id)->first();
    //   $exemption_yes_no = $stage_3['exemption_yes_no'];
    //     }
        // echo $exemption_yes_no;
        // exit;
        $preference_location ="";
        if($exemption_yes_no =='yes'){
         $preference_location = "Online (Via Zoom)";
        }else{
            $preference_location =  $this->request->getPost('preference_location');
        }
        $preference_comment =  $this->request->getPost('preference_comment');
        $recipt_number =  $this->request->getPost('recipt_number');
        $payment_date_get =  $this->request->getPost('payment_date');
        
        $payment_date_ = str_replace('/', '-', $payment_date_get);
        $payment_date ="";
        if (!empty($payment_date_)) {
            $payment_date =  date("Y-m-d h:i:s", strtotime($payment_date_));
        }
        // echo $payment_date;
        // exit;
        
         $data = [
                'download_ex_form'=>$download_ex_form,
                "receipt_number" => $recipt_number,
                "payment_date" => $payment_date,
                "submitted_by"  => $session->user_id,
                'exemption_yes_no'=>$exemption_yes_no,
                "preference_location"=>$preference_location,
                'preference_comment' => $preference_comment,

            ];
            if ($this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update()) {
                 $this->session->setFlashdata('msg', 'File Uploaded Successfully.');
                } else {
                    $this->session->setFlashdata('error_msg', 'File Uploading Error.');
                }    
                 return redirect()->back();
           
    }
    // ajax ----------
    public function receipt_upload_action($ENC_pointer_id)
    {
          $exemption_yes_no =  $this->request->getPost('exemption_yes_no');
    //   echo $exemption_yes_no;
    //   exit;
      
        // Start Session
        $session = session();
        // 
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $recipt_number =  $this->request->getPost('recipt_number');


        $payment_date =  $this->request->getPost('payment_date');
        $preference_location =  $this->request->getPost('preference_location');
        // echo $recipt_number;
        // echo $payment_date;
        // 
        $preference_location ="";
        if($exemption_yes_no == "yes"){
            $preference_location = "Online (Via Zoom)";
        }else{
            $preference_location =  $this->request->getPost('preference_location');
        }
        
        $payment_date = str_replace('/', '-', $payment_date);
        if (!empty($payment_date)) {
            $payment_date =  date("Y-m-d h:i:s", strtotime($payment_date));
        }

        // file data and file name 
        $file =  $this->request->getFile('recipt');
        
         if ($file) {

             if($file->getName()){

            $File_extention = $file->getClientExtension();
            
            $docs_db = $this->required_documents_list_model->where("id", "19")->first();
            $folder_path = 'public/application/'.$pointer_id .'/stage_3';
            $document_name = $docs_db["document_name"];
            $file_name_with_extantion = $document_name . '.' . $File_extention;
            // echo $folder_path;
            // exit;
            if (!is_dir($folder_path)) {
                mkdir($folder_path);
            }
            // move file to folder 
            $is_move = $file->move($folder_path, $file_name_with_extantion, true);
        
        }
         }
        // if ($is_move) {
            $data = [
                "receipt_number" => $recipt_number,
                "payment_date" => $payment_date,
                "submitted_by"  => $session->user_id,
                'exemption_yes_no'=>$exemption_yes_no,
                "preference_location"=>$preference_location,
                "download_ex_form" => 1,
                
            ];
            if ($this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update()) {
                $data_docs = [
                    "pointer_id" => $pointer_id,
                    "stage" => 'stage_3',
                    "required_document_id" => $docs_db["id"],
                    "name" => $docs_db["document_name"],
                    "document_name" => $file_name_with_extantion,
                    "document_path" => $folder_path,
                    "status" => 1,
                ];

                if ($this->documents_model->insert($data_docs)) {
                    $this->session->setFlashdata('msg', 'File Uploaded Successfully.');
                } else {
                    $this->session->setFlashdata('error_msg', 'File Uploading Error.');
                }
            // }
            } else {
                $this->session->setFlashdata('error_msg', 'Sorry! File Not Uploaded.');
            }

        return redirect()->back();
    }

    public function receipt_upload_getData($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $stage_3__ = $this->stage_3_model->where("pointer_id", $pointer_id)->first();
        $docs = $this->documents_model->where([
            "pointer_id" => $pointer_id,
            "stage" => "stage_3",
        ])->first();
        $output = [];
        if ($docs) {
            $output = [
                "name" => $docs["name"],
                "path" => base_url() . "/" . $docs["document_path"] . "/" . $docs["document_name"],
                "pointer_id" => $docs["pointer_id"],
                "receipt_number" => $stage_3__["receipt_number"],
                "payment_date" => date("d/m/y", strtotime($stage_3__["payment_date"])),
            ];
        }
        echo json_encode($output);
    }

    // working
    function receipt_upload_delete($ENC_pointer_id,$documnet_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        $documnet_id  = $documnet_id;
            $documents = $this->documents_model->where('id',$documnet_id)->first();
            // print_r($documents);
            // exit;
            if (!empty($documents)) {
                $file_path =  $documents['document_path'] . '/' . $documents['document_name'];
                
                    if (file_exists($file_path)) {
                        if (unlink($file_path)) {
                            echo "unlink";
                        }else{
                            echo "not unlink";
                        }
                    }
                    // if($documents['required_document_id'] == 19){
                    //     $data = [
                    //         "receipt_number" => '',
                    //         "payment_date" => '',

                    //     ];
                    //       $this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update();
  
                    // }
                    if($documents['required_document_id'] == 43){
                        $data = [
                            "exemption_form"=>'',
                        ];
                    $this->stage_3_model->set($data)->where('pointer_id', $pointer_id)->update();
                    }
                    if ($this->documents_model->where('id',$documnet_id)->delete()) {
                        $this->session->setFlashdata('msg', 'File Deleted Successfully.');
                        echo "delete";
                    }else{
                    $this->session->setFlashdata('error_msg', 'File Uploading Error.');
                    echo "not delete";
                    }
               
            }
        // echo json_encode($callback);
            return redirect()->back();

       }



    function stage_3_submit_($ENC_pointer_id)
    {
        $pointer_id = pointer_id_decrypt($ENC_pointer_id);
        // echo $pointer_id;


        // email -----------------------------------------------------------------
        // no reply to applicant or agent  -------------------
        $email = "";
        $stage_1_contact_details_ = $this->stage_1_contact_details_model->where(['pointer_id' => $pointer_id])->first();
        if (!empty($stage_1_contact_details_)) {
            $email = $stage_1_contact_details_['email'];
        } // Applicant email

        $application_pointer = $this->application_pointer_model->where(['id' => $pointer_id])->first();
        if (!empty($application_pointer)) {
            $user_id = $application_pointer['user_id'];
            $user_account = $this->user_account_model->where(['id' => $user_id])->first();
            if (!empty($user_account)) {
                $email = $user_account['email'];
            }
        } // agent email

        if (!empty($email)) {
            $client_type =  is_Agent_Applicant($pointer_id);
            if ($client_type == "Agent") { // Applicant
                // s3_submitted_agent
                $mail_temp_4 = $this->mail_template_model->where(['id' => '43'])->first();
                if (!empty($mail_temp_4)) {
                    $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
                    $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
                    $to =  $email;
                    $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                    if ($check == 1) {
                        $email_send_agent_applicant = true;
                    }
                } // email template
            }
            if ($client_type == "Applicant") { // 
                // s3_submitted_applicant
                $mail_temp_4 = $this->mail_template_model->where(['id' => '86'])->first();
                if (!empty($mail_temp_4)) {
                    $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
                    $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
                    $to =  $email;
                    $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'), $to, $subject, $message);
                    if ($check == 1) {
                        $email_send_agent_applicant = true;
                    }
                } // email template
            }
        } // email
        
        //s3_submitted_admin
        $mail_temp_4 = $this->mail_template_model->where(['id' => '44'])->first();
        if (!empty($mail_temp_4)) {
            $subject = mail_tag_replace($mail_temp_4['subject'], $pointer_id);
            $message = mail_tag_replace($mail_temp_4['body'], $pointer_id);
            $stage_3_ = $this->stage_3_model->where(['pointer_id' => $pointer_id])->first();

            $preference_location_comment = "";
            if (!empty($stage_3_)) {
                $preference_location = trim($stage_3_['preference_location']);
                $preference_comment = trim($stage_3_['preference_comment']);
                $preference_comment = trim($preference_comment, "\xC2\xA0");
                $preference_comment = str_replace("&nbsp;", '', $preference_comment);
                if (!empty($preference_location)) {
                    $preference_location_comment .= "<b>Applicant's Preferred Venue: " . $preference_location;
                }
                if (!empty($preference_comment)) {
                    // $preference_location_comment .= "<br><br><u> Comments: </u><br>" . $preference_comment . "</b>";
                    $preference_location_comment .= "<br><br><u> Comments: </u><br><i>\"" . $preference_comment . "\"</i></b>";
                }
            }

            $stage_3_Docs = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 19, 'stage' => "stage_3"])->first();
            
            
            
            $addAttachment = array(
                [
                    'file_path' => $stage_3_Docs['document_path'] . '/' . $stage_3_Docs['document_name'],
                    'file_name' => $stage_3_Docs['document_name'],
                ]
            );
            
            
            // If Online Via Zoom then add Exception Form
            // Get the Occupation
            $enroll_stage_4 = false;
            $occupation = $this->stage_1_occupation_model->where("pointer_id", $pointer_id)->asObject()->first();
            if($occupation->pathway == "Pathway 1"){
                if($occupation->occupation_id == 7 || $occupation->occupation_id == 18){
                    $enroll_stage_4 = true;
                }
            }
            // end
            
            if($enroll_stage_4 == false){
                if($preference_location == "Online (Via Zoom)"){
                    $stage_3_Docs_ex = $this->documents_model->where(['pointer_id' => $pointer_id, 'required_document_id' => 43, 'stage' => "stage_3"])->first();
                     $addAttachment_ex = array(
                        [
                            'file_path' => $stage_3_Docs_ex['document_path'] . '/' . $stage_3_Docs_ex['document_name'],
                            'file_name' => $stage_3_Docs_ex['document_name'],
                        ]
                    );
                    array_push($addAttachment, ...$addAttachment_ex);
                }
            }
            // print_r($addAttachment);
            // exit;
            
            $message = str_replace('%preference_location_comment%', $preference_location_comment, $message);
            $check = send_email(env('SERVER_EMAIL'), env('SERVER_FROM_EMAIL'),  env('ADMIN_EMAIL'), $subject, $message, [], [], [], $addAttachment);
            if ($check == 1) {
                $email_send_admin = true;
            }
        }
        // echo "First = ".$email_send_agent_applicant."Second = ".$email_send_admin;
        // exit;

        if ($email_send_agent_applicant && $email_send_admin) {
            $is_update = $this->stage_3_model->set([
                "status" => "Submitted",
                "submitted_date" => date("Y-m-d H:i:s"),
            ])->where("pointer_id", $pointer_id)->update();
            
            if ($is_update) {
                $is_pointer_update = $this->application_pointer_model->set([
                    "stage" => "stage_3",
                    "status" => "Submitted",
                ])->where("id", $pointer_id)->update();
                // Do here Mail Code
                // End Do here Mail Code
                if ($is_pointer_update) {
                    $json = [
                        "error" => 0,
                        "msg"   => "Submitted Successfully",
                    ];
                }
            }
        }

        return redirect()->to(base_url('user/view_application/' . $ENC_pointer_id));
    }
    

}
