<?php
// ---------for admin --------- 

function stage_1_expired_day($pointer_id)
{
    $db = db_connect();
    $sql = "select * from stage_1 where pointer_id = " . $pointer_id;
    $res = $db->query($sql);
    $data = $res->getRowArray();
    if (count($data)) {
        $expiry_date = $data['expiry_date'];
        $Todays_date = strtotime(date('Y-m-d'));
        $approved_date_temp = strtotime($expiry_date);
        $timeleft = $Todays_date - $approved_date_temp;
        $day_remain = round((($timeleft / 86400)));
        return $day_remain = 30 - $day_remain;
    }
    return 0;
}

function is_Agent_Applicant($pointer_id)
{
    $db = db_connect();
    $sql = "select * from application_pointer where id = " . $pointer_id;
    $res = $db->query($sql);
    $data = $res->getRowArray();
    if (count($data)) {
        $user_id = $data['user_id'];
        $sql = "select * from user_account where id = " . $user_id;
        $res = $db->query($sql);
        $data = $res->getRowArray();
        if (count($data)) {
            return  trim($data['account_type']);
        } else {
            return "";
        }
    } else {
        return "";
    }
}

function get_tb($table)
{
    $db = db_connect();
    $query = "select * from " . $table;
    $sql = $db->query($query);
    return  $sql->getResultarray();
}

function get_allocate_team_member_name($id)
{
    $db = db_connect();
    $query = "select * from allocate_team_member_name where id = " . $id;
    $sql = $db->query($query);
    return  $sql->getRow();
}

function find_one_row($table, $field, $value)
{
    $db = db_connect();
    $query = "select * from " . $table . " where " . $field . " = '" . $value . "'ORDER BY " . $table . ".`id` DESC";
    $sql = $db->query($query);
    return  $sql->getRow();
}
function find_multiple_rows($table, $field, $value)
{
    $db = db_connect();
    $query = "select * from " . $table . " where " . $field . " = '" . $value . "'ORDER BY " . $table . ".`id` DESC";
    $sql = $db->query($query);
    return  $sql->getResult();
}

function find_one_row_2_field($table, $field, $value, $field_2, $value_2)
{
    $db = db_connect();
    $query =  "select * from " . $table . " where " . $field . " = '" . $value . "' " . "and " . $field_2 . "='" . $value_2 . "'";
    $sql = $db->query($query);
    return $sql->getRow();
}

function find_multiple_row_2_field($table, $field, $value, $field_2, $value_2)
{
    $db = db_connect();
    $query =  "select * from " . $table . " where " . $field . " = '" . $value . "' " . "and " . $field_2 . "='" . $value_2 . "'";
    $sql = $db->query($query);
    return  $sql->getResult();
}
function find_one_row_3_field($table, $field, $value, $field_2, $value_2, $field_3, $value_3)
{
    $db = db_connect();
    $query =  "select * from " . $table . " where " . $field . " = '" . $value . "' " . "and " . $field_2 . "='" . $value_2 . "'" . "and " . $field_3 . "='" . $value_3 . "'";
    $sql = $db->query($query);
    return  $sql->getRow();
}

function find_multiple_row_3_field($table, $field, $value, $field_2, $value_2, $field_3, $value_3)
{
    $db = db_connect();
    $query =  "select * from " . $table . " where " . $field . " = '" . $value . "' " . "and " . $field_2 . "='" . $value_2 . "'" . "and " . $field_3 . "='" . $value_3 . "'";
    $sql = $db->query($query);
    return  $sql->getResult();
}
//  admin ->application_manger

function stage_status_app_mag($stage_tab, $field_1, $val_1, $field_2, $val_2, $field_3, $val_3)
{
    $db = db_connect();
    if ($stage_tab == 3) {
        $sql = "select * from " . $field_3 . " where " . $field_1 . "=" . $val_1 . " and " . $field_2 . "=" . $val_2 . " ORDER BY " . $val_3 . "  DESC";
        //    print_r($sql);
    } elseif ($stage_tab == 2) {
        $sql = "select * from stage_2_submitted_documents where " . $field_2 . "=" . $val_2 . " and " . $field_3 . "=" . $val_3 . " and " . $field_1 . " IN ('" . $val_1[0] . "','" . $val_1[1] . "','" . $val_1[2] . "','" . $val_1[3] . "')";
    } else {
        $sql = "select * from " . $stage_tab . " where " . $field_1 . "=" . $val_1 . " and " . $field_2 . "=" . $val_2 . " and " . $field_3 . "=" . $val_3;
        //    echo $sql;
    }
    $res = $db->query($sql);
    // return $res->getResult();
    return $res->getRow();
}
function occupation_saq_app_thir($val_offline)
{
    //    count($val);
    $db = db_connect();
    //   SELECT * FROM `occupation_file` WHERE id NOT IN (58,43);";
    $sql = "SELECT * FROM `occupation_list` WHERE id NOT IN (SELECT occupation_id FROM `offline_file` where use_for='" . $val_offline . "') and status ='active'";
    // print_r($sql);
    // exit;
    $res = $db->query($sql);
    return $res->getResult();
}
function mail_name()
{
    $db = db_connect();
    $sql = "SELECT * FROM `mail_template_name_keyword` WHERE id NOT IN (SELECT name FROM `mail_template`)";
    $res = $db->query($sql);
    return $res->getResult();
}

function country_phonecode($id)
{
    $db = db_connect();
    $sql = "SELECT * FROM `country` WHERE id = $id";
    $res = $db->query($sql);
    $data = $res->getRow();
    if (isset($data) && !empty($data)) {
        return $data->phonecode;
    } else {
        return "";
    }
}
function check_stage_3($pointer_id)
{
    $db = db_connect();
    $query = "SELECT * FROM `stage_3` WHERE pointer_id =".$pointer_id." ORDER BY `id`  DESC";
    $sql = $db->query($query);
    return $sql->getRow();
}

function check_stage_4($pointer_id)
{
    $db = db_connect();
    $query = "SELECT * FROM `stage_4` WHERE pointer_id =".$pointer_id." ORDER BY `id`  DESC";
    $sql = $db->query($query);
    return $sql->getRow();
}

function mail_tag_replace($mail_text, $pointer_id)
{
    $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $pointer_id);
    $application_pointer =  find_one_row('application_pointer', 'id', $pointer_id);
    $user_account = find_one_row('user_account', 'id', $application_pointer->user_id);

    $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $pointer_id);
    $occupation_list = find_one_row('occupation_list', 'id',  $s1_occupation->occupation_id);

    $stage_1 = find_one_row('stage_1', 'pointer_id', $pointer_id);
    $stage_2 = find_one_row('stage_2', 'pointer_id', $pointer_id);
    $stage_3 = find_one_row('stage_3', 'pointer_id', $pointer_id);
    $stage_4 = find_one_row('stage_4', 'pointer_id', $pointer_id);

    $signature_mail = find_one_row('mail_template', 'name', '18');
    $aqato_signature = $signature_mail->body;

    if ($s1_occupation->pathway == "Pathway 1") {
        $pathway = "P1";
    } else {
        $pathway = "P2";
    }


// $stage_4_practical_booking=find_one_row('stage_4_practical_booking', 'pointer_id', $pointer_id);
    // stage 3 
    $stage_3_interview_booking = find_one_row('stage_3_interview_booking', 'pointer_id', $pointer_id);
    if (isset($stage_3_interview_booking->location_id)) {
        $stage_3_offline_location_id = (isset($stage_3_interview_booking->location_id)) ? $stage_3_interview_booking->location_id : "Null";
        $date_time = (isset($stage_3_interview_booking->date_time)) ? $stage_3_interview_booking->date_time : "";

        $s3_interview_day_and_date = "";
        $s3_interview_time_A = "";
        if (!empty($date_time)) {
            $s3_interview_day_and_date = date('l, jS F Y', strtotime($date_time));
            $s3_interview_time_A = date('h:i A', strtotime($date_time)) . " (Australia/Brisbane Time)";
        }

        $stage_3_offline_location = find_one_row('stage_3_offline_location', 'id', $stage_3_offline_location_id);
        if ($stage_3_offline_location_id == 9) {
            $date_time_zone = (isset($stage_3_interview_booking->time_zone)) ? $stage_3_interview_booking->time_zone : "";
        } else {
            $date_time_zone = (isset($stage_3_offline_location->date_time_zone)) ? $stage_3_offline_location->date_time_zone : "";
        }

        $s3_interview_venue = (isset($stage_3_offline_location->venue)) ? $stage_3_offline_location->venue : "";
        $s3_interview_address = (isset($stage_3_offline_location->office_address)) ? $stage_3_offline_location->office_address : "";

        $s3_interview_time_B = "";
        if (!empty($date_time_zone)) {
            if (!empty($date_time)) {
                $date = new DateTime(date('Y-m-d H:i:s', strtotime($date_time)));
                $date->setTimezone(new DateTimeZone($date_time_zone));
                $s3_interview_time_B = $date->format('h:i A') . " (" . $date_time_zone . " Time)";
            }
        }

        $mail_text = str_replace('%s3_interview_day_and_date%', $s3_interview_day_and_date, $mail_text);
        $mail_text = str_replace('%s3_interview_time%', $s3_interview_time_A . " / " . $s3_interview_time_B, $mail_text);
        $mail_text = str_replace('%s3_interview_venue%', $s3_interview_venue, $mail_text);
        $mail_text = str_replace('%s3_interview_address%', $s3_interview_address, $mail_text);
    }


    // $mail_text = str_replace('%occupation_reason_for_decline_stage_1%', isset($stage_1->declined_reason) ? $stage_1->declined_reason : "", $mail_text);
    // $mail_text = str_replace('%occupation_reason_for_decline_stage_2%', isset($stage_2->declined_reason) ? $stage_2->declined_reason : "", $mail_text);
    // $mail_text = str_replace('%occupation_reason_for_decline_stage_3%', isset($stage_3->declined_reason) ? $stage_3->declined_reason : "", $mail_text);s
    
    
    //stage 4 mail tags
//     if(!empty($stage_4)){
//     if(!empty($stage_4_practical_booking)){
//       if (isset($stage_4_practical_booking->location_id)) {
//         $stage_4_offline_location_id = (isset($stage_4_practical_booking->location_id)) ? $stage_4_practical_booking->location_id : "Null";
//         $date_time = (isset($stage_4_practical_booking->date_time)) ? $stage_4_practical_booking->date_time : "";

//         $s4_practical_day_and_date = "";
//         $s4_practical_time_A = "";
//         if (!empty($date_time)) {
//             $s4_practical_day_and_date = date('l, jS F Y', strtotime($date_time));
//             $s4_practical_time_A = date('h:i A', strtotime($date_time)) . " (Australia/Brisbane Time)";
//         }

//         $s4_date_time_zone="Australia/Brisbane";
//         $s4_practical_time_B = "";
//         if (!empty($date_time_zone)) {
//             if (!empty($date_time)) {
//                 $date = new DateTime(date('Y-m-d H:i:s', strtotime($date_time)));
//                 $date->setTimezone(new DateTimeZone($date_time_zone));
//                 $s3_practical_time_B = $date->format('h:i A') . " (" . $s4_date_time_zone . " Time)";
//             }
//         }

//         $mail_text = str_replace('%s4_practical_day_and_date%', $s4_practical_day_and_date, $mail_text);
//         $mail_text = str_replace('%s4_practical_time%', $s4_practical_time_A . " / " . $s4_practical_time_B, $mail_text);
       
//     }
//     }
// } //stage 4
// echo $application_pointer->stage;
//  if($application_pointer->stage == 'stage_3'){
     if(!$stage_4){
if(isset($stage_3)){
    if(!empty($stage_3)){
        $mail_text = str_replace('%preference_location%', $stage_3->preference_location, $mail_text);
    $mail_text = str_replace('%time_zone%', $stage_3->time_zone, $mail_text);
    $mail_text = str_replace('%preference_comment%', $stage_3->preference_comment, $mail_text);

    }
} 
 
}


//  $mail_text = str_replace('%preference_location%', $stage_3->preference_location, $mail_text);
//     $mail_text = str_replace('%time_zone%', $stage_3->time_zone, $mail_text);
//     $mail_text = str_replace('%preference_comment%', $stage_3->preference_comment, $mail_text);

    $mail_text = str_replace('%personal_details_first_name%',trim($s1_personal_details->first_or_given_name," ")." ", $mail_text);
    $mail_text = str_replace('%personal_details_middle_name%', trim($s1_personal_details->middle_names)." ", $mail_text);
    $mail_text = str_replace('%personal_details_surname_name%', trim($s1_personal_details->surname_family_name," "), $mail_text);

    $mail_text = str_replace('%email_first_name%', $user_account->name, $mail_text);
    $mail_text = str_replace('%email_surname_name%',  $user_account->last_name, $mail_text);

    $mail_text = str_replace('%occupation_occupation%', $occupation_list->name, $mail_text);
    $mail_text = str_replace('%occupation_program%', $s1_occupation->program, $mail_text);

    $mail_text = str_replace('%pathway%', $pathway, $mail_text);

    $mail_text = str_replace('[#%unique_id%]', (!empty($stage_1->unique_id) ? "[#" . $stage_1->unique_id . "]" : ""), $mail_text);
    $mail_text = str_replace('%unique_id%', (!empty($stage_1->unique_id) ? "[#" . $stage_1->unique_id . "]" : ""), $mail_text);


    // berupiya find ------------------------------
    // 
    // 
    // Ignore CODE
    
    // $mail_text = str_replace('%email_signature%', $aqato_signature, $mail_text);
    
    
    //$aqato_email_signature='<div style="font-family: Arial, Helvetica, sans-serif;"><span id="docs-internal-guid-a55a4f32-7fff-89fd-d652-8c89da4febd6"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Dilpreet Singh Bagga</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Director (AQATO)</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">--</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC/AQATO India Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Office No. S-04, Regus Harmony, Level 4, Tower-A, Godrej Eternia,</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Plot Number 70, Industrial Area 1, Chandigarh - 160002</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +91-172-4071505 (M): +91-9888286702</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">294 Scarborough Road, Scarborough, QLD - 4020</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-7-3414 5908 (F): +61-7-3880 4339</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">AQATO Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">13 Villellla Drive, Pakenham, VIC - 3810</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-3-59184617 (M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><br></span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.attc.org.au</span></a><br></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.aqato.com.au" style="text-decoration: none;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.aqato.com.au</span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: rgb(51, 122, 183); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><span style="border: none; display: inline-block; overflow: hidden; width: 319px; height: 313px;"><img src="https://attc.aqato.com.au/public/Logos/Aqato_logo.png" width="319" height="313" style="margin-left: 0px; margin-top: 0px;"></span></span></p><pre style="font-family: var(--bs-font-monospace); margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span id="docs-internal-guid-b296c628-7fff-4b72-8d6f-5552d91f4e2a"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><b style="font-weight:normal;" id="docs-internal-guid-f1581e39-7fff-3061-9190-6c78ceee0d68"><br></b></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#000000;background-color:#ffffff;font-weight:700;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Disclaimer :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#afb5b9;background-color:#ffffff;font-weight:400;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">This email is intended only for the person(s) named in the message header. Unless otherwise indicated, it contains information that is confidential, privileged and/or exempt from disclosure under applicable law. If you have received this message in error, please notify the sender of the error and delete the message.</span></p></span></pre></span></div>';
     $aqato_email_signature='<img src="https://attc.aqato.com.au/public/Logos/Aqato_logo.png" width="120px" height="50px" style="margin-left: 0px; margin-top: 0px;">';

    // $attc_email_signature='<div style="font-family: Arial, Helvetica, sans-serif;"><span id="docs-internal-guid-a55a4f32-7fff-89fd-d652-8c89da4febd6"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Dilpreet Singh Bagga</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Director (AQATO)</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">--</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC/AQATO India Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Office No. S-04, Regus Harmony, Level 4, Tower-A, Godrej Eternia,</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Plot Number 70, Industrial Area 1, Chandigarh - 160002</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +91-172-4071505 (M): +91-9888286702</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">294 Scarborough Road, Scarborough, QLD - 4020</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-7-3414 5908 (F): +61-7-3880 4339</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">AQATO Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">13 Villellla Drive, Pakenham, VIC - 3810</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-3-59184617 (M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><br></span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.attc.org.au</span></a><br></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.aqato.com.au" style="text-decoration: none;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.aqato.com.au</span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: rgb(51, 122, 183); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><span style="border: none; display: inline-block; overflow: hidden; width: 319px; height: 313px;"><img src="https://attc.aqato.com.au/public/Logos/ATTC_logo.png" width="319" height="313" style="margin-left: 0px; margin-top: 0px;"></span></span></p><pre style="font-family: var(--bs-font-monospace); margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span id="docs-internal-guid-b296c628-7fff-4b72-8d6f-5552d91f4e2a"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><b style="font-weight:normal;" id="docs-internal-guid-f1581e39-7fff-3061-9190-6c78ceee0d68"><br></b></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#000000;background-color:#ffffff;font-weight:700;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Disclaimer :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#afb5b9;background-color:#ffffff;font-weight:400;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">This email is intended only for the person(s) named in the message header. Unless otherwise indicated, it contains information that is confidential, privileged and/or exempt from disclosure under applicable law. If you have received this message in error, please notify the sender of the error and delete the message.</span></p></span></pre></span></div>';
    $attc_email_signature='<img src="https://attc.aqato.com.au/public/Logos/ATTC_logo.png"  width="120px" height="50px" style="margin-left: 0px; margin-top: 0px;">';
    $attc_banner_email_signature='<div style="font-family: Arial, Helvetica, sans-serif;"><span id="docs-internal-guid-a55a4f32-7fff-89fd-d652-8c89da4febd6"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Dilpreet Singh Bagga</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Director (AQATO)</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">--</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC/AQATO India Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Office No. S-04, Regus Harmony, Level 4, Tower-A, Godrej Eternia,</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">Plot Number 70, Industrial Area 1, Chandigarh - 160002</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +91-172-4071505 (M): +91-9888286702</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">ATTC Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">294 Scarborough Road, Scarborough, QLD - 4020</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-7-3414 5908 (F): +61-7-3880 4339</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;"><br></span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-weight: 700; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">AQATO Australia Office :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">13 Villellla Drive, Pakenham, VIC - 3810</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; vertical-align: baseline; white-space: pre-wrap;">(P): +61-3-59184617 (M): +61-401200991</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><br></span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.2;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.attc.org.au" style="background-color: rgb(255, 255, 255);"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.attc.org.au</span></a><br></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><a href="https://attc.aqato.com.au/admin/mail_template/edit/www.aqato.com.au" style="text-decoration: none;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;">www.aqato.com.au</span></a></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span style="font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: rgb(51, 122, 183); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; font-variant-alternates: normal; text-decoration-line: underline; text-decoration-skip-ink: none; vertical-align: baseline; white-space: pre-wrap;"><span style="border: none; display: inline-block; overflow: hidden; width: 319px; height: 313px;"><img src="https://attc.aqato.com.au/public/Logos/Attc_banner.png" width="319" height="313" style="margin-left: 0px; margin-top: 0px;"></span></span></p><pre style="font-family: var(--bs-font-monospace); margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><span id="docs-internal-guid-b296c628-7fff-4b72-8d6f-5552d91f4e2a"><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"><b style="font-weight:normal;" id="docs-internal-guid-f1581e39-7fff-3061-9190-6c78ceee0d68"><br></b></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#000000;background-color:#ffffff;font-weight:700;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">Disclaimer :</span></p><p dir="ltr" style="margin-top: 0pt; margin-bottom: 0pt; line-height: 1.9872;"></p><p dir="ltr" style="line-height:2.38464;margin-top:0pt;margin-bottom:0pt;"><span style="font-size:10pt;font-family:Arial, Helvetica, sans-serif;color:#afb5b9;background-color:#ffffff;font-weight:400;font-style:italic;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;">This email is intended only for the person(s) named in the message header. Unless otherwise indicated, it contains information that is confidential, privileged and/or exempt from disclosure under applicable law. If you have received this message in error, please notify the sender of the error and delete the message.</span></p></span></pre></span></div>';
    
    // berupiya find ------------------------------
    // 
    // 
    // Ignore CODE
    
    // $mail_text = str_replace('%email_signature_Team_AQATO_Admin%', $aqato_email_signature, $mail_text);
    // $mail_text = str_replace('%email_signature_Team_ATTC_Admin%', $attc_email_signature, $mail_text);
    $mail_text = str_replace('%attc_banner_email_signature%', $attc_banner_email_signature, $mail_text);


    return $mail_text;
}


function countries()
{
    $db = db_connect();
    $sql = "SELECT DISTINCT country FROM `stage_3_offline_location` ORDER BY `stage_3_offline_location`.`country` ASC;";
    $res = $db->query($sql);
    return $res->getResult();
}

function assessment_documents($value)
{
    $db = db_connect();
    $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2' and ( employee_id=0 or  employee_id is NULL) AND required_document_id IN (15,16,22,30,34)";
    // $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2'";
    // echo $query;
    $sql = $db->query($query);
    return  $sql->getResult();
}

function supporting_documents($value)
{
    $db = db_connect();
    $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2' and  required_document_id=16";
    // $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2'";
    // echo $query;
    $sql = $db->query($query);
    return  $sql->getResult();
}


function Additional_Information_docs($value)
{
    $db = db_connect();
    $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2' and required_document_id=17";
    // $query =  "SELECT * FROM `documents` WHERE pointer_id = '" . $value . "'  and stage = 'stage_2'";
    // echo $query;
    $sql = $db->query($query);
    return  $sql->getResult();
}

// ---------------admin Applicant and Agent -> applicant name or agent company name -> Application Manager filter by user id---------------

function filter_company($id)
{
    $db = db_connect();
    $query =  "SELECT * FROM `stage_1` WHERE status IS NOT NULL and id IN (SELECT id FROM `application_pointer` where user_id =" . $id . ") ORDER BY `pointer_id` ASC";
    // print_r($query);
    $sql = $db->query($query);
    //  print_r($sql);
    // exit;
    return  $sql->getResult();
}
// admin->verification->email_stage_2
function emplo_email_verf($value)
{
    $db = db_connect();
    $query = "select * from email_verification where pointer_id = '" . $value . "' AND employer_id IS NOT NULL";
    $sql = $db->query($query);
    return  $sql->getResult();
}
function quali_email_verf($value)
{
    $db = db_connect();
    $query = "select * from email_verification where pointer_id = '" . $value . "' AND employer_id IS NOT NULL";
    $sql = $db->query($query);
    return  $sql->getRow();
}

function request_asses_doc($pointer_id)
{
    
    $db = db_connect();
    $query = "SELECT * FROM `additional_info_request` WHERE pointer_id ='" . $pointer_id . "' and document_id IN (SELECT id FROM `documents` where required_document_id in (15,30,34) ) and status ='send' and stage = 'stage_2'";
    $sql = $db->query($query);
    return  $sql->getResult();
    
}
function request_support_evidance($pointer_id)
{
    
    $db = db_connect();
    $query = "SELECT * FROM `additional_info_request` WHERE pointer_id ='" . $pointer_id . "' and document_id IN (SELECT id FROM `documents` where required_document_id in (16) ) and status ='send' and stage = 'stage_2'";
    $sql = $db->query($query);
    return  $sql->getResult();
    
}



