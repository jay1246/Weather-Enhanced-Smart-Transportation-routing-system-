<?php
if (isset($show_said_bar)) {
} else {
    $show_said_bar = true;
}
if ($show_said_bar) {
    
?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

    <style>
/*.sidebar_right {*/
/*    height: auto;*/
/*    position: fixed;*/
/*    right: 0;*/
/*    height: 86.5%;*/
/*    width: 100%;*/
/*    max-width: 300px !important;*/
/*    transition: all 0.3s;*/
/*    padding: 20px;*/
/*    top: 122px;*/
/*    scrollbar-width: thin;*/
/*    scrollbar-color: #aab7cf transparent;*/
/*    box-shadow: 0px 0px 20px rgba(1, 41, 112, 0.1);*/
/*    background-color: #fff;*/
/*        }*/
      

.sidebar_right {
    height: auto;
    position: fixed;
    right: 0rem;
    height: 81%;
    width: 394px !important;
    transition: all 0.3s;
    padding: 20px;
    top: 119px;
    scrollbar-width: thin;
    scrollbar-color: #aab7cf transparent;
    /*box-shadow: 0px 0px 20px rgba(1, 41, 112, 0.1);*/
    /*background-color: #fff;*/
    /*border: 1px solid white;*/
    border-radius: 10px;
}
@media (min-width: 1801px) {
    .sidebar_right {
        top: 132px !important;
    }
    
   }

        .shadow {
            box-shadow: none !important;
        }
        @media (max-width: 1199px) {
            .sidebar_right {
                left: -300px;
            }
        }
   
        .sidebar_right::-webkit-scrollbar {
            width: 5px;
            height: 8px;
            background-color: #fff;
        }

        .sidebar_right::-webkit-scrollbar-thumb {
            background-color: #aab7cf;
        }

        @media (max-width: 1199px) {
            .toggle-sidebar .sidebar {
                left: 0;
            }
        }

        @media (min-width: 1800px) {
             
            .toggle-sidebar #main,
            .toggle-sidebar #footer {
                margin-left: 0;
                background-color: red;
                
            }

            .toggle-sidebar .sidebar {
                left: -300px;
            }
        }
    </style>
    <style>
           .custom-background {
        background-color: #28a745; 
        color: #fff; 
        
    }
  
/*.chat {*/
/*       height: 95%;*/
/*    top: 0;*/
/*    position: absolute;*/
/*    bottom: 10px;*/
/*    left: 14.5%;*/
/*    z-index: 66;*/
/*    width: 86%;*/
/*}*/

.chat {
    height: 100%;
    top: 0;
    position: absolute;
    bottom: 10px;
    left: 0px;
    z-index: 66;
    width: 100%;
}
        }
.custom_footer{
    width: 296px;
    margin-left: 2px;
    height: 64px;
    position: relative;
    bottom: 0;
    
        }
.custom_tel{
     font-size: 39px;
    color: #28a745;
    transform: rotate(20deg);
    margin-left: -23px;
    left: 345px;
    position: relative
        }
.scroll_{
    position: relative;
    height: 650px; overflow-y: auto;
    overflow-x:hidden;

}        
/* width */
.scroll_::-webkit-scrollbar {
  width: 5px;
}

/* Track */
.scroll_::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
.scroll_::-webkit-scrollbar-thumb {
  background: grey; 
  border-radius: 10px;
}

/* Handle on hover */
.scroll_::-webkit-scrollbar-thumb:hover {
  background: grey; 
}    

.scroll_chat{
    position: relative;
    overflow-y: auto;
    overflow-x:hidden;

}        
/* width */
.scroll_chat::-webkit-scrollbar {
  width: 0px;
}

/* Track */
.scroll_chat::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
.scroll_chat::-webkit-scrollbar-thumb {
  background: grey; 
  border-radius: 10px;
}

/* Handle on hover */
.scroll_chat::-webkit-scrollbar-thumb:hover {
  background: grey; 
}    


@media (min-width: 1801px) {
    #main {
        margin-top: 104px !important;
    }
    
   }

    #chatbox {
    height: 10px;
    font-size: 18px;
    width: 100%;
    margin-left: -4px;
    height: "20px";
    resize: none;
        }
        #chatbox::placeholder {
       color: #999; 
       font-style: italic; 
       font-size:18px;
}
       .custom-icon {
        width: 33px;
        height: 28px;
        background: #cbd7ca;
        border: 1px solid white;
        border-radius: 12px;
    
}
.custom_style_icon {
    background: #f5f6f7;
    width: 25px;
    text-align: center;
    border: 1px solid white;
    border-radius: 18px;
    height: 24px;
    margin-bottom: -12px;
    z-index: 3;
    margin-right: 0px;
    margin-top: 27px;
    
}
.custom_style_del{
    color:red;
    margin-top: 28px
}
.previous_msg{
   margin-left: 0px;
    width: 87.5%;
    margin-top: -4px;
    height: 54px;
    border-top: 2px solid #e9edefcc;
    border-radius: 7px;
    background: #e9edefcc;
    border-left: 2px solid #e9edefcc;
    border-right: 2px solid #e9edefcc;
    margin-bottom: 5px;
}

    </style>
    <?php
     $current_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    ?>
        <?php   
  if (session()->has('admin_account_type')) {
       $admin_account_type =  session()->get('admin_account_type');
       $admin_id =  session()->get('admin_id');
       $admin_name=session()->get('admin_name');
       $admin_email=session()->get('admin_email');
  }     
  
  $_fname= find_one_row('admin_account', 'id', $admin_id)->first_name;
  $_lname= find_one_row('admin_account', 'id', $admin_id)->last_name_chat;
  $get_Admin_fname=$_fname.$_lname;
  
?>
    <aside id="sidebar_right" class="sidebar_right shadow mt-1 ">
                    <div class="card chat" id="chat_module" >
                        
        
                        <div class="card-header d-flex justify-content-between align-items-center p-3">
                            
                            <h5 class="mb-0">Chat</h5>
                            <button type="button" class="close" id="toggleButton_"  aria-label="Toggle_" onclick="Closechat();">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            
                        </div>
                        <!--<div><=$current_url?></div>-->
   <div class="card-body scroll_" id="chat_area" data-mdb-perfect-scrollbar="true" >
               <!--<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;"></p>-->
            <div id="result">
            <div class="d-flex flex-row justify-content-start">
                
              <!--<img src="<=base_url('public/assets/chat/user1.jpg')?>" alt="User Image"style="width: 44px; height: 100%;>-->
              <div id="result_oponent" >
               
              </div>
            </div>
</div>

          </div>
      
  
          <!--  <div class="card-footer text-muted d-flex justify-content-start align-items-center p-3 custom_footer">-->
                
          <!--  <textarea   class="form-control form-control-lg p-1 scroll_chat" id="chatbox"  -->
          <!--    placeholder="Type message" style="font-size: 18px; width: 100%; margin-left: -4px;" ></textarea>-->
          <!--  <a class="ms-1 text-muted" href="#!"><i class="fas fa-paperclip"></i></a>-->
          <!--  <a class="ms-3 text-muted" href="#!"><i class="fas fa-smile"></i></a>-->
          <!--  <a class="ms-3" href="#!"><i class="fas fa-paper-plane"></i></a>-->
          <!--  <i onclick="chatbox()"; class="bi bi-telegram custom_tel"></i>-->
          <!--</div>-->
         
  <div class="card-footer text-muted  custom_footer" id="custom_footer" style="height:62px;">
      <div style="display:none" class="row" id="showhidereply" height="15px"><div class="previous_msg" id="previous_msg"></div><button id="btn_close" class="btn-close" onclick="deleteDiv()" style="margin-top: 12px; margin-left: 14px "></button></div>
  <div class=" row " style="position: fixed;bottom:-8 px;">
<textarea class="form-control form-control-lg p-1 scroll_chat" id="chatbox" rows="3" placeholder="Type message" style="font-size: 18px; width: 94%; margin-left: 1px;"></textarea>  <a class="ms-1 text-muted" href="#!"><i class="fas fa-paperclip"></i></a>
  <a class="ms-3 text-muted" href="#!"><i class="fas fa-smile"></i></a>
  <a class="ms-3" href="#!"><i class="fas fa-paper-plane"></i></a>
  <i onclick="chatbox();" class="bi bi-telegram custom_tel"></i>
  
  </div>
 
</div>


     
     <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
//     $(document).ready(function () {
//       $('#chatbox').on('input', function () {
//   var custom_footer = document.getElementById('custom_footer');
//   custom_footer.style.height = "";
//   this.style.height = 'auto';
//   this.style.height = (this.scrollHeight) + 'px';
//   if (this.scrollHeight <= this.clientHeight) {
//     this.style.height = '2em';
//   }
  
      
// });
//     });
    
 



</script>
                    </div>
           
<?php  }?>

   

    </aside>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
var userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

 $(document).ready(function() {
      //check session value 
      getChatHistory();
     //fetch all chats very imp
     fetchData();
  var currentURL_ = window.location.href;
  var parts_ = currentURL_.split('/');
  var url_view_edit_ = parts_[7]; // view edit
  var pagetitle = document.querySelector(".pagetitle");
  if(url_view_edit_ == 'view_edit' || url_view_edit_ == 'all_documents' || url_view_edit_ == 'notes'){
  pagetitle.style.marginTop="-7px";  
  }else{
    pagetitle.style.marginTop="10px";
  }
          
                // getCurrentMessageCount();
                
        });
        
        
//scroll use for fetch data------------------   
        $('#chat_area').on('scroll', function () {
            //console.log($(this).scrollTop());
            if ($(this).scrollTop() < 50) {
                previous_date="";
                //daylabel_afterword="";
                // User scrolled to the top of the chat container
                // Load more messages
                setTimeout(() => {  
                    //console.log('World!'); 
                 fetchData("no_store_last_id");
                    
                }, 2000);
            }
        });
        
        
    
// ------------------ for open and closed chat
        const chatCard = document.getElementById("sidebar_right");
        const toggleButton = document.getElementById("toggleButton");
        const avatar = document.getElementById("avatar");
        let isChatOpen = false;
        chatCard.style.display = "none";
        
            //toggleButton.addEventListener("click", function() {
            function Closechat(){
                new_msg_received = 0;
                // Close
                 showSpans();
                 storeHistoryChat('close');
            isChatOpen = !isChatOpen;
            chatCard.style.display = isChatOpen ? "block" : "none";
      //  });
}
        //avatar.addEventListener("click", function() {
            // Open
            function openchat(){
            new_msg_received = 0;
            isChatOpen = true;
            chatCard.style.display = "block";
             setTimeout(() => {
                
                $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight}, 1000);    
            },200);
             hideSpans();
             storeHistoryChat('open');
            }
        //});
 // ------------------ after click enter send msg     
    var inputElement = document.getElementById('chatbox');
    inputElement.addEventListener('keydown', function(event) {
    if (event.keyCode === 13) { 
        event.preventDefault(); 
        chatbox();
    }
});

// ------------------ check last chat open or not 
function getChatHistory() {
    $.ajax({
        method: "GET",
        url: "<?= base_url("admin/admin_functions/chat_system_getsession") ?>",
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            //alert(response.operation);
            if (response.operation == 'open') {
                //alert('open');
            openchat();
            } else {
                //alert('closed');
            // Closechat();
            }
        },
        error: function(error) {
            console.error(error);
            // Handle the error here
        }
    });
}


// ------------------ store session for last chat..
function storeHistoryChat(operation){
  
     $.ajax({
        method: "POST",
        url: "<?= base_url("admin/admin_functions/chat_system_checksession") ?>",
        data: {
            operation
        },
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
        },
        error: function(error) {
            console.error(error);
        }
    });
 
}

// ------------------ this function for insert chat in database after insert show last msg
    function chatbox() {
        //alert(reply_id);
     var previous_msg = document.getElementById('previous_msg');
    // var currentValue = previous_msg.getAttribute('data-value');
     var chat = document.getElementById("chatbox").value;
     var admin_id = <?= $admin_id ?>;
     if (chat.trim() !== "") {
    $.ajax({
        method: "POST",
        url: "<?= base_url("admin/admin_functions/chat_system") ?>",
        data: {
            chat: chat,
            admin_id: admin_id,
            reply_id:reply_id,
            reply_msg_update,
            reply_user_name,
            reply_color
            
        },
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            if(response){
                reply_id='';
               reply_color='';
               reply_msg_update='';
               reply_user_name='';
               fetchData_last(true);
             }
    
        },
        error: function(error) {
            console.error(error);
            // Handle the error here
        }
    });
}
}

// ------------------ this function is use for automatic check msg by using per 5 seconds
 setInterval(function() {fetchData_last(false)}, 500);

// ------------------ for delete reply div when user can have to send reply 
function deleteDiv() {
    reply_id="";
    reply_msg_update="";
   // reply_user_name='';
    //reply_color='';
    var showhidereply = document.getElementById('showhidereply');
    var custom_footer = document.getElementById('custom_footer');
    var chatbox = document.getElementById('chatbox');
    var previousMsg = document.getElementById('previous_msg');

    showhidereply.style.display = 'none';
    custom_footer.style.height = "63px";
    previousMsg.innerHTML = '';
}


 // ------------------ show reply icon on every chat msg
function showReplyIcon(element) {
  var replyIcon = element.querySelector('.custom_style_icon');
  //var deleteIcon = element.querySelector('.custom_style_del');
  var replyIcon_left =  document.getElementById("left_reply");
  replyIcon.style.display = '';
 // deleteIcon.style.display = '';
  replyIcon_left.style.marginTop = '38px';
  
}


// ------------------ show reply icon on every chat msg
function hideReplyIcon(element) {
  var replyIcon = element.querySelector('.custom_style_icon');
 // var deleteIcon = element.querySelector('.custom_style_del');
   replyIcon.style.display = 'none';
   //deleteIcon.style.display = 'none';
}


// ------------------ This function use for reply the previous chat
var reply_msg_update='';
var reply_msg_;
var reply_user_name='';
var reply_color='';
var reply_id='';
function reply_msg(id) {
  var previous_msg = document.getElementById('previous_msg');
  var textarea = document.getElementById('chatbox');
  var showhidereply = document.getElementById('showhidereply');
  var custom_footer = document.getElementById('custom_footer');
  var admin_id=<?=$admin_id?>;
  custom_footer.style.height = "132px";
  showhidereply.style.display = '';
  previous_msg.innerHTML = '';
  $.ajax({
  url: '<?= base_url("admin/admin_functions/chat_system_fetch_reply") ?>',
  method: 'GET',
  data: { id: id },
  success: function(response) {
    if(response){
        if(admin_id == response.user_id){
            var username='you';
            //alert(username);
        }else{
             var username=response.user_name;
        }
     var truncatedMessage = response.message.length > 55 ? response.message.substring(20,55) + '...' : response.message;
     var msg = `<b style="color: ${response.color}; font-size: 13px;">${username}</b>&nbsp<span><b style="font-size: 15px;">Replying to:&nbsp</b> ${truncatedMessage}</span>`;
     $('#previous_msg').append(msg);
     
     //map global var
      reply_id=response.id;
      reply_msg_update=response.message;
      reply_msg_=truncatedMessage;
      reply_user_name=response.user_name;
      reply_color=response.color;
      //alert(reply_color);
      previous_msg.setAttribute('data-value', currentValue + '');
      var currentValue = parseInt(previous_msg.getAttribute('data-value')) || '';
      previous_msg.setAttribute('data-value', response.id);
      previous_msg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      textarea.focus();
    }
  },
  error: function(error) {
    console.error('Error:', error);
  }
});
}

function formatTimestamp_day(timestamp) {
  const options = { day: 'numeric', month: 'short', year: 'numeric' };
  return new Date(timestamp).toLocaleString('en-US', options);
}

// ------------------ this function is for fetch all data 
var offset_record = 0;
var prevoius_offset_record = -1;
var record_fetch = 10;
var last_msg__id = "";
//fetch all data
var previous_date="";
    async function fetchData(no_store_last_id = "") {
        if(prevoius_offset_record == offset_record){
            //console.log("Same Record");
            return;
        }
        prevoius_offset_record = offset_record;
        //daylabel_afterword_last="";
         try {
     const response = await $.ajax({
            // $.ajax({
                url: '<?= base_url("admin/admin_functions/chat_system_fetch") ?>', 
                method: 'POST',
                data:{
                    userTimezone,
                    record_fetch,
                    offset_record,
                },
            });
                 offset_record += record_fetch;
                 //await response;
                   //console.log(response);
                   var first_record = 0;
                  //var  label_text_date = response[response.length - 1]="";
               response.forEach(function(item) {
                  if(first_record == 0){
                      previous_date = item.date_label;
                  }
                  var label_text_date="";
                   if(previous_date != item.date_label){
                         label_text_date = previous_date;
                         previous_date = item.date_label;
                            }
                
                    //console.log(label_text_date);
                        
//--------------do not touch this code----------//                   
                   if(no_store_last_id == ""){
                       if(first_record == 0){
                       last_msg__id = item.id;
                       //alert(last_msg__id);
                       first_record = 2;
                       }
                   }
                   //console.log(item.userid);
                   var reply_change=item.reply_user_name;
                //   console.log("admin_id = ", '<?= $get_Admin_fname ?>');
                   
                //   console.log("item = ", item.reply_user_name);
                  if('<?= $get_Admin_fname ?>' == item.reply_user_name){
                         reply_change = 'You';
                          
                     }
              
            //   if (<= $admin_id ?> == 1) {
            //     delete_chat = `<i onclick="delete_chat(${item.id});" class="bi bi-trash-fill custom_style_del" style="display:none;"></i>`;
            //   }else{
            //       var delete_chat='';
            //   }
            //  console.log(item.reply_user_name);
             //console.log(reply_change);
           if (item.reply_msg != '') {
               //alert('fdsbgsdf');
        var width = 'width:90%;';
        var msg_add_left = `
        <div  class="d-flex justify-content-start message-container" style="margin-left:19px;width: 19rem; margin-top:-15px;margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p onclick="goto_up('target'+ ${item.reply_id})" data-target-id="target${item.reply_id}"  class="small p-2 mb-1 rounded-3 mt-3 text-start" style="${width}max-width: 90%;background-color:#d9fdd3;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${item.reply_color}">${item.reply_user_name}&nbsp;</span>
            ${item.reply_msg}
            </p>
         </div>
           `;
           
           var msg_add_right=`<div  class="d-flex justify-content-end message-container" style="width: 19rem;margin-left: 37px; margin-top: -14px;  margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p onclick="goto_up('target'+ ${item.reply_id})" data-target-id="target${item.reply_id}" class="small p-2 mb-1 rounded-3 mt-3 text-start" style="width:90%;background-color: #e9edefcc;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${item.reply_color}">${reply_change}&nbsp;</span>
           ${item.reply_msg}
            </p>
         </div>`;
           
        } else {
            var msg_add_left = '';
            var width = ' ';
            msg_add_right='';
        }
                  
      var id=item.id;
      var daylabel='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+label_text_date+'</p>';
      //alert(daylabel #a2aab7);
    //  right_div
                var paragraph = `
                
                ${msg_add_right}
<div  id="target${item.id}"  class="d-flex justify-content-end message-container" style="width: 19rem; margin-left: 68px; margin-top: -7px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
   
  <i onclick="reply_msg(${item.id});" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
  <p  class="small p-2 mb-1 rounded-3 mt-3 text-start" style="${width}max-width: 90%;background-color:#d9fdd3;"> ${item.message}
    <span class="small d-block text-end" style="font-size: 10px; margin-left: auto; font-style: bold;">
      <i>${formatTimestamp(item.created_at)}</i>
    </span>
  </p>
  <img src="<?=base_url('public/assets/chat/user3.png')?>" alt="avatar 1" style="width: 31px; height: 9%; margin-top: 20px;">
</div>
   ${daylabel}
   `;
    
    // divleft
                var paragraph_ = `    ${msg_add_left}
                
      <div   id="target${item.id }" class="d-flex justify-content-start message-container" style="margin-left: -12px;width: 19rem; margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
      <img   src="<?=base_url('public/assets/chat/user3.png')?>"alt="avatar 1" style="width: 31px;height: 9%;margin-top: 20px;">  
        <p  class="small p-2  mb-1 rounded-3 mt-3 text-start" style="${width}background-color: #f5f6f7;max-width: 90%;">
         <span class="small d-block text-start" style="font-size: 11px; margin-left: auto;font-weight: bold;color:${item.color};">${item.user_name}</span>
        ${item.message }<br><i class="ms-2" style="float: right;font-size: 10px;">${formatTimestamp(item.created_at)}</i></p>
         <i onclick="reply_msg(${item.id });" id="left_reply" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        
      </div> ${daylabel}
    `;
                    
                  if (item.user_id == <?= $admin_id ?>) {
                            $('#result_oponent').prepend(paragraph);
                            
                        } else {
                            $('#result_oponent').prepend(paragraph_);
                        }
                        
       
       first_record++;
       //console.log(previous_date  +'--->'+label_text_date);
     });
     
      var daylabel_afterword='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+previous_date+'</p>';
      $('#result_oponent').prepend(daylabel_afterword);
      previous_date = "";
      
       } catch (error) {
      console.error(error.responseText);
  }
        }   
        
//--------------------------------delete chat by super admin
// function delete_chat(id){
//       $.ajax({
//         method: "POST",
//         url: "<= base_url("admin/admin_functions/delete_chat_") ?>",
//         data: {
//             id
//         },
//         contentType: "application/x-www-form-urlencoded",
//         success: function(response) {
//             if(response){
//             }
    
//         },
//         error: function(error) {
//             console.error(error);
//             // Handle the error here
//         }
//     });
// }
// ------------------convert time to am pm
function formatTimestamp(timestamp) {
            var date = new Date(timestamp);
            //console.log(date);
            var timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            return timeString;
        }
        
// ----------------->fetch data by lastinsertedid<-----------------     
   var new_msg_received = 0;
   var daylabel_afterword_last="";
   function fetchData_last(sendByUser = true) {
       var input_resize = document.getElementById("chatbox");
       input_resize.setAttribute("placeholder","Type message");
            $.ajax({
                url: '<?= base_url("admin/admin_functions/last_one_data_fetch") ?>', 
                method: 'POST',
                data:{
                    userTimezone
                },
             success: function(response) {
                // offset_record = 0;
                input_resize.style.height="10px";
                var lastItem = response;
                 console.log(lastItem);
                // return;
                var self_reply= lastItem.reply_user_name;
               if('<?= $get_Admin_fname ?>' == lastItem.reply_user_name){
                   self_reply ='You';
                }
            daylabel_afterword_last='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+lastItem.date_label+'</p>';
                
              if (lastItem.reply_id != 0) {
               var width='width:100%;';
      var msg_add = `<div  class="d-flex justify-content-end message-container" style="width: 19rem;margin-left: 37px; margin-top: -14px;  margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p  onclick="goto_up('target'+ ${lastItem.reply_id})" id="target${lastItem.reply_id}" class="small p-2 mb-1 rounded-3 mt-3 text-start" style="width:90%;background-color: #e9edefcc;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${lastItem.reply_color}">${self_reply} &nbsp;</span>
            ${reply_msg_}
            </p>
         </div>`;
           var msg_add_right_single = `
        <div  class="d-flex justify-content-start message-container" style="margin-left:19px;width: 19rem; margin-top:-15px;margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p onclick="goto_up('target'+ ${lastItem.reply_id})" data-target-id="target${lastItem.reply_id}"  class="small p-2 mb-1 rounded-3 mt-3 text-start" style="${width}max-width: 90%;background-color:#d9fdd3;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${lastItem.reply_color}">${lastItem.reply_user_name}&nbsp;</span>
            ${lastItem.reply_msg}
            </p>
         </div>
           `;
            } else {
                var msg_add = '';
                var width='';
                msg_add_right_single='';
            }
            console.log(msg_add_right_single);
            //RIGHT SIDE DIV
            var paragraph = `${daylabel_afterword_last} ${msg_add}
     <div id="target${lastItem.id }" class="d-flex justify-content-end message-container" style="width: 19rem; margin-left: 68px;margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
    <i onclick="reply_msg(${lastItem.id });" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
      
       <p  class="small p-2  mb-1 rounded-3 mt-3 text-start" style="${width}background-color: #d9fdd3;">${lastItem.message }
         <span class="small d-block text-end" style="font-size: 11px;margin-left: auto;font-style: italic;"><i>${formatTimestamp(lastItem.created_at)}</i></span>
        </p>
      </div>
`;
        //left side div
        
              var paragraph_ = `${daylabel_afterword_last}  ${msg_add_right_single}
      <div id="target${lastItem.id }"  class="d-flex justify-content-start message-container" style="margin-left: -12px;width: 19rem; margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
      <img   src="<?=base_url('public/assets/chat/user3.png')?>"alt="avatar 1" style="width: 31px;height: 9%;margin-top: 20px;">  
        <p  class="small p-2  mb-1 rounded-3 mt-3 text-start" style="${width}background-color: #f5f6f7;max-width: 90%;">
         <span class="small d-block text-start" style="font-size: 11px; margin-left: auto;font-weight: bold;color:${lastItem.color};">${lastItem.user_name}</span>
        ${lastItem.message }<br><i class="ms-2" style="float: right;font-size: 10px;">${formatTimestamp(lastItem.created_at)}</i></p>
         <i onclick="reply_msg(${lastItem.id });" id="left_reply" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
      </div>
    `; 
         if(last_msg__id != lastItem.id){
             
              
              if (lastItem.user_id == <?= $admin_id ?>) {
                  new_msg_received = 0;
                            $('#result_oponent').append(paragraph);
              } else{
                  new_msg_received++;
                    play_sound();
                   $('#result_oponent').append(paragraph_);
              }
              last_msg__id = lastItem.id;               
         }          
         
                   $('#msg_count').text(new_msg_received);
                   if(new_msg_received != 0){
                   $('#msg_count').addClass('bg-danger');
                   }
             if(sendByUser){
                deleteDiv();
                input_resize.value="";
                $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight}, 1000);
            }
            
           
                         
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
            });
        }
        

// ----------------->this for notification sound<----------------- 
 function play_sound() {
    var audio = new Audio();
    audio.src = "<?=base_url('public/chat_notification/Iphone Notification.mp3')?>";
    audio.type = "audio/ogg";
    audio.play();
    console.log(' audio played');
  }
  
  // ----------------->this for scroll to parent msg<----------------- 
  
 

function goto_up(element) {
  $("#" + element).find("p").css({
  //backgroundColor: "rgb(146 247 135)", 
  border: "2px solid #FFCC01"
});
  $("#" + element).get(0).scrollIntoView();
  
   setTimeout(function() {
    $("#" + element).find("p").css({
     // backgroundColor: "#e9edefcc", 
      border: ""
    });
  }, 2000); // 2000 
}





// ----------------->this is use to hide span design purpose<----------------- 
  function hideSpans() {
      
  var currentURL = window.location.href;
  var parts = currentURL.split('/');
  
  var url_view_edit = parts[7]; // view edit
  var interview_booking=parts[4];
  //alert(interview_booking);
 //all code align for css and closed open chat box. 
  var sidebar = document.getElementById("sidebar");
  var sidebar_right = document.querySelector(".sidebar_right");
  var section = document.querySelector(".section");
  var main = document.getElementById("main");
  var spans = sidebar.getElementsByTagName("span");

  for (var i = 0; i < spans.length; i++) {
    spans[i].style.display = "none";
  }
  sidebar.style.width = "90px";
  main.style.padding = "20px 30px";
  main.style.transition = "all 0.3s";
  main.style.width = "100%";
  main.style.marginTop = "88px !important";
// sidebar.style.height="78%";
 var sidebarWidth = 90; 
var chatWidth = 390;  
if(url_view_edit == 'notes'){
   var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth) + 32; 
}else if(interview_booking = 'interview_booking' ){
var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth)-5; 
//alert(totalWidthMain);
}
else{
   var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth) + 10; 
}
//alert(window.innerWidth);
  if (window.innerWidth >= 1400) {
    main.style.marginLeft = "83px";
    main.style.width = totalWidthMain + "px";  
    
    
  }
  //check condition for view and update url
  if(url_view_edit == 'view_edit' || url_view_edit == 'all_documents' || url_view_edit == 'notes'){
      main.classList.remove('w-100');
      //section.style.width ="84%";
      if (window.innerWidth) {
    main.style.marginLeft = "73px";
    main.style.width = totalWidthMain + "px";  
    
  }
  }
}

// ----------------->this is use to show span design purpose<----------------- 
function showSpans() {
   var currentURL = window.location.href;
  var parts = currentURL.split('/');
  var url_view_edit = parts[7]; // view edit
  //check url
 //all code align for css and closed open chat box. 
  var section = document.querySelector(".section");
  var main = document.getElementById("main");
  var sidebar = document.getElementById("sidebar");
  var spans = sidebar.getElementsByTagName("span");

  for (var i = 0; i < spans.length; i++) {
    spans[i].style.display = "";
  }
  sidebar.style.width = "18%";
//   section.style.width ="100%";
  main.style.padding = "20px 30px";
  main.style.transition = "all 0.3s";
  main.style.width = "100%";
  main.style.marginLeft = "303px";
  main.style.marginTop = "116px !important";
  
  if(url_view_edit == 'view_edit'){
     
      section.style.width ="100%";
  }
} 

    </script>