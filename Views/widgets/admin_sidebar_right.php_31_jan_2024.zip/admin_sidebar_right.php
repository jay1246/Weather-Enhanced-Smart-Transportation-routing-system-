<?php

if (isset($show_said_bar)) {
} else {
    $show_said_bar = true;
}
if ($show_said_bar) {
    
?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

    <style>
/*.sidebar_right {*/
/*    height: auto;*/
/*    position: fixed;*/
/*    right: 0;*/
/*    height: 86.5%;*/
/*    width: 100%;*/
/*    max-width: 300px !important;*/
/*    transition: all 0.3s;*/
/*    padding: 20px;*/
/*    top: 122px;*/
/*    scrollbar-width: thin;*/
/*    scrollbar-color: #aab7cf transparent;*/
/*    box-shadow: 0px 0px 20px rgba(1, 41, 112, 0.1);*/
/*    background-color: #fff;*/
/*        }*/
      

.sidebar_right{
    height: auto;
    position: fixed;
    right: 0rem;
    height: 81%;
    width: 394px !important;
    transition: all 0.3s;
    padding: 20px;
    top: 119px;
    scrollbar-width: thin;
    scrollbar-color: #aab7cf transparent;
    /*box-shadow: 0px 0px 20px rgba(1, 41, 112, 0.1);*/
    /*background-color: #fff;*/
    /*border: 1px solid white;*/
    border-radius: 10px;
}
@media (min-width: 1801px) {
    .sidebar_right {
        top: 132px !important;
    }
    
   }

        .shadow {
            box-shadow: none !important;
        }
        @media (max-width: 1199px) {
            .sidebar_right {
                left: -300px;
            }
        }
   
        .sidebar_right::-webkit-scrollbar {
            width: 5px;
            height: 8px;
            background-color: #fff;
        }

        .sidebar_right::-webkit-scrollbar-thumb {
            background-color: #aab7cf;
        }

        @media (max-width: 1199px) {
            .toggle-sidebar .sidebar {
                left: 0;
            }
        }

        @media (min-width: 1800px) {
             
            .toggle-sidebar #main,
            .toggle-sidebar #footer {
                margin-left: 0;
                background-color: red;
                
            }

            .toggle-sidebar .sidebar {
                left: -300px;
            }
        }
    </style>
    <style>
           .custom-background {
        background-color: #28a745; 
        color: #fff; 
        
    }
  
/*.chat {*/
/*       height: 95%;*/
/*    top: 0;*/
/*    position: absolute;*/
/*    bottom: 10px;*/
/*    left: 14.5%;*/
/*    z-index: 66;*/
/*    width: 86%;*/
/*}*/

.chat {
    height: 100%;
    top: 0;
    position: absolute;
    bottom: 10px;
    left: 0px;
    z-index: 66;
    width: 100%;
}
        }
.custom_footer{
    width: 296px;
    margin-left: 2px;
    height: 64px;
    position: relative;
    bottom: 0;
    
        }
.custom_tel{
     font-size: 39px;
    color: #28a745;
    transform: rotate(20deg);
    margin-left: -23px;
    left: 345px;
    bottom: -55px;
    position: absolute;
        }
.scroll_{
    position: relative;
    height: 650px; overflow-y: auto;
    overflow-x:hidden;

}        
/* width */
.scroll_::-webkit-scrollbar {
  width: 2px;
}

/* Track */
.scroll_::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
.scroll_::-webkit-scrollbar-thumb {
  background: grey; 
  border-radius: 10px;
}

/* Handle on hover */
.scroll_::-webkit-scrollbar-thumb:hover {
  background: grey; 
}    

.scroll_chat{
    position: relative;
    overflow-y: auto;
    overflow-x:hidden;

}        
/* width */
.scroll_chat::-webkit-scrollbar {
  width: 5px;
}

/* Track */
.scroll_chat::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius: 10px;
}
 
/* Handle */
.scroll_chat::-webkit-scrollbar-thumb {
  background: grey; 
  border-radius: 10px;
}

/* Handle on hover */
.scroll_chat::-webkit-scrollbar-thumb:hover {
  background: grey; 
}    


@media (min-width: 1801px) {
    #main {
        margin-top: 104px !important;
    }
    
   }

    #chatbox {
   height: 40px;
    font-size: 18px;
    width: 100%;
    margin-left: -4px;
    resize: none;

    /*font-size: 10px;*/
    margin-left: 1px;
    width: 87%;
    padding: 6px 13px !important;
        }
        #chatbox::placeholder {
       color: #999; 
       font-style: italic; 
       font-size:18px;
}
       .custom-icon {
        width: 33px;
        height: 28px;
        background: #cbd7ca;
        border: 1px solid white;
        border-radius: 12px;
    
}
.custom_style_icon {
    background: #f5f6f7;
    width: 25px;
    text-align: center;
    border: 1px solid white;
    border-radius: 18px;
    height: 24px;
    margin-bottom: -12px;
    z-index: 3;
    margin-right: 0px;
    margin-top: 27px;
    
}
.custom_style_del{
    color:red;
    margin-top: 28px
}
.previous_msg{
   margin-left: 0px;
    width: 87.5%;
    margin-top: -4px;
    height: 54px;
    border-top: 2px solid #e9edefcc;
    border-radius: 7px;
    background: #e9edefcc;
    border-left: 2px solid #e9edefcc;
    border-right: 2px solid #e9edefcc;
    margin-bottom: 5px;
}
.cursor_{
    cursor:pointer;
}

    </style>
    <?php
     $current_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    ?>
        <?php   
  if (session()->has('admin_account_type')) {
    //   print_r($_SESSION);
       $admin_account_type =  session()->get('admin_account_type');
       $admin_id =  session()->get('admin_id');
       $admin_name=session()->get('admin_name');
       $admin_email=session()->get('admin_email');
       
           
  }     
//   echo $notification;
  $_fname= find_one_row('admin_account', 'id', $admin_id)->first_name;
  $_lname= find_one_row('admin_account', 'id', $admin_id)->last_name_chat;
  $get_Admin_fname=$_fname.$_lname;
  
  $admin_data=admin_data($admin_id);
  
?>
<style>
    .show_active{
    height: 350px;
    width: 310px;
    position: relative;
    right: -69px;
    background-color: #f0f0f0;;
    top: 181px;
    z-index: 3;
    border-radius: 10px;
    overflow-y:scroll;
   
    }
    .img{
    width: 35px;
    height: 35px;
    border-radius: 25px;
    margin-left: 8px;
    margin-top: 5px;
    }
    .custom_badge{
    top: 37px;
    left: 37px;
    }
    
</style>
 <div class="show_active text-center scroll_" id="show_active" style="display:none;">
    
 </div>
    <aside id="sidebar_right" class="sidebar_right shadow mt-1 " style="display: none;">
          
                     <div class="card chat" id="chat_module" >
                        
                        <!--onmouseout="hideActiveDiv() onmouseover="showActiveDiv()""-->
        
                        <div class="card-header d-flex justify-content-between align-items-center p-3" style="padding: 9px !important;">
                            
                            <h5 class="mb-0">Group Chat<i onclick="show_active_logins()"style="color: #055837;cursor:pointer;font-size: 1rem;" class=" ms-2 bi bi-info-square-fill"></i></h5>
                            <button type="button" class="close" id="toggleButton_"  aria-label="Toggle_" onclick="Closechat();">
                                <span style="padding-right: 9px;margin-right: 7px;opacity: 18.5 !important;" class="btn-close" aria-hidden="true"></span>
                            </button>
                            
                        </div>
                       
                        <!--<div><=$current_url?></div>-->
   <div class="card-body scroll_" id="chat_area" data-mdb-perfect-scrollbar="true" onscroll="remove_notification_count()" >
               <!--<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;"></p>-->
            <div id="result">
            <div class="d-flex flex-row justify-content-start">
                
              <!--<img src="<=base_url('public/assets/chat/user1.jpg')?>" alt="User Image"style="width: 44px; height: 100%;>-->
              <div id="result_oponent" >
               
              </div>
            </div>
</div>

          </div>
      
  
          <!--  <div class="card-footer text-muted d-flex justify-content-start align-items-center p-3 custom_footer">-->
                
          <!--  <textarea   class="form-control form-control-lg p-1 scroll_chat" id="chatbox"  -->
          <!--    placeholder="Type message" style="font-size: 18px; width: 100%; margin-left: -4px;" ></textarea>-->
          <!--  <a class="ms-1 text-muted" href="#!"><i class="fas fa-paperclip"></i></a>-->
          <!--  <a class="ms-3 text-muted" href="#!"><i class="fas fa-smile"></i></a>-->
          <!--  <a class="ms-3" href="#!"><i class="fas fa-paper-plane"></i></a>-->
          <!--  <i onclick="chatbox()"; class="bi bi-telegram custom_tel"></i>-->
          <!--</div>-->
         
  <div class="card-footer text-muted  custom_footer" id="custom_footer" >
      <div style="display:none" class="row" id="showhidereply" height="15px"><div class="previous_msg" id="previous_msg"></div><button id="btn_close" class="btn-close" onclick="deleteDiv()" style="margin-top: 12px; margin-left: 14px "></button></div>
  <div class=" row ">
      <p id="send_msg_" style="display:none;">Sending...</p>
 <!--<textarea class="form-control form-control-lg p-1 scroll_chat" id="chatbox" max_rows="5" placeholder="Type message" style="font-size: 18px; width: 94%; margin-left: 1px;"></textarea> -->
  <textarea class="form-control  p-1 scroll_chat" rows="1"  oninput="autoResize(this)" onpaste="autoResize(this, 'yes')"  id="chatbox" placeholder="Type message"></textarea>
  <a class="ms-1 text-muted" href="#!"><i class="fas fa-paperclip"></i></a>
  <a class="ms-3 text-muted" href="#!"><i class="fas fa-smile"></i></a>
  <a class="ms-3" href="#!"><i class="fas fa-paper-plane"></i></a>
  <i onclick="chatbox();" class="bi bi-telegram custom_tel" id="custom_playing_before_trigger"></i>
  
  </div>
 
</div>

            
            
             
<?php $base_url=base_url(); ?>

     
     <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
//   for show active users

     function show_active_logins(){
        var activeDiv = document.getElementById("show_active");
         
        if (activeDiv.style.display === "none") {
             check_active();
          //activeDiv.style.display = "block";
        } else {
          activeDiv.style.display = "none";
          while (activeDiv.firstChild) {
         activeDiv.removeChild(activeDiv.firstChild);
           }
        }
     }
    
//         function showActiveDiv() {
           
            
//     var activeDiv = document.getElementById("show_active");
//     activeDiv.style.display = "block";
//   }

  function hideActiveDiv() {
    var activeDiv = document.getElementById("show_active");
        activeDiv.style.display = "none";
    // Remove all child elements (appended data)
    while (activeDiv.firstChild) {
        activeDiv.removeChild(activeDiv.firstChild);
    }
  }
        function autoResize(textarea, __isPaste = "") {
          hideActiveDiv();
            var chat_length = $("#chatbox").val();
            chat_length = chat_length.length;
            //console.log("Height = ",textarea.scrollHeight);
            //console.log("Lenght = ", chat_length);
           
            if(textarea.scrollHeight != 40){
              // Reset the textarea height to a small value
              textarea.style.height = 'auto';
              //console.log(textarea.scrollHeight);
              if(textarea.scrollHeight >= 147){
                textarea.style.height ='147px';
              }
              else{
                textarea.style.height = (textarea.scrollHeight) + 'px';
              }
            //console.log("run code");
            }
            else{
                textarea.style.height ='40px';
            }
        }
</script>
                    </div>
           
<?php  }?>

   

    </aside>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
var userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

// function remove_notification_count() {
//     var chat_area = document.getElementById('chat_area');
//     if (chat_area) {
//         var scrollPosition = chat_area.scrollTop;
//         var maxScroll = chat_area.scrollHeight - chat_area.clientHeight;
//         var msg_count = document.getElementById('msg_count');
//         if (scrollPosition === maxScroll) {
//             if (msg_count) {
//                  new_msg_received = 0;
//                 msg_count.style.display = 'none';
//                 console.log('i am none ');
//             }
//         }  
//     }
// }
 
 var chatArea = document.getElementById('chat_area');

if (chatArea) {
    chatArea.addEventListener('scroll', remove_notification_count);
}

// function remove_notification_count() {
//     var scrollPosition = chatArea.scrollTop;
//     var maxScroll = chatArea.scrollHeight - chatArea.clientHeight;
//     var msgCount = document.getElementById('msg_count');

//     if (scrollPosition === maxScroll) {
//         if (msgCount) {
//             newMsgReceived = 0;
//             msgCount.style.display = 'none';
//             console.log('Message count is hidden.');
//         }
//     }
// }
function remove_notification_count() {
    var chatArea = document.getElementById('chat_area');
    if (chatArea) {
        var scrollPosition = chatArea.scrollTop;
        var maxScroll = chatArea.scrollHeight - chatArea.clientHeight;
        var msgCount = document.getElementById('msg_count');

        // Adjust the ratio based on your needs
        var scrollRatio = 0.95; // Example: 90% of the chat_area height

        if (scrollPosition >= maxScroll * scrollRatio) {
            if (msgCount) {
                 new_msg_received = 0;
                // msgCount.style.display = 'none';
                update_chat_aftershownotification();
                 
                //console.log('Message count is hidden.');
            }
        }
    }
}
//check all when page load 
 $(document).ready(function() {
      make_count_area();
      fetchData("","scroll");
      getChatHistory();
      
  var currentURL_ = window.location.href;
  var parts_ = currentURL_.split('/');
  var url_view_edit_ = parts_[7]; // view edit
  var pagetitle = document.querySelector(".pagetitle");
//   var main_ = document.querySelector(".main");
   var main_ = document.getElementById("main");
  if(url_view_edit_ == 'view_edit' || url_view_edit_ == 'all_documents' || url_view_edit_ == 'notes'){
      if(url_view_edit_ == 'notes'){
          main_.style.marginRight="-9px";
      }
  pagetitle.style.marginTop="-7px";  
  }else{
    pagetitle.style.marginTop="10px";
  }
          
                // getCurrentMessageCount();
                
        });
        
        
//scroll use for fetch data------------------   
        $('#chat_area').on('scroll', function () {
            //console.log($(this).scrollTop());
            if ($(this).scrollTop() < 50) {
                previous_date="";
                //daylabel_afterword="";
                // User scrolled to the top of the chat container
                // Load more messages
                setTimeout(() => {  
                    //console.log('World!'); 
                 fetchData("no_store_last_id");
                    
                }, 2000);
            }
        });
        
        
    
// ------------------ for open and closed chat
        const chatCard = document.getElementById("sidebar_right");
        const toggleButton = document.getElementById("toggleButton");
        const avatar = document.getElementById("avatar");
        var activeDiv = document.getElementById("show_active");
        let isChatOpen = false;
        chatCard.style.display = "none";
        
            //toggleButton.addEventListener("click", function() {
            function Closechat(){
                var msg_count = document.getElementById('msg_count');
                 msg_count.style.display = 'none';
                 activeDiv.style.display = "none";
                new_msg_received = 0;
                // Close
                 showSpans();
                 storeHistoryChat('close');
            isChatOpen = !isChatOpen;
            chatCard.style.display = isChatOpen ? "block" : "none";
      //  });
      
      //for update chat 0
      update_chat_aftershownotification();
       
       
}
        //avatar.addEventListener("click", function() {
            // Open
            function openchat(){
            new_msg_received = 0;
            isChatOpen = true;
            chatCard.style.display = "block";
            if(scroll_on_off <= 10 ){
                setTimeout(() => {
                
                $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight}, 1000);    
            },200);   
            }
             hideSpans();
             storeHistoryChat('open');
            }
        //});
 // ------------------ after click enter send msg     
    var inputElement = document.getElementById('chatbox');
    inputElement.addEventListener('keydown', function(event) {
    if (event.keyCode === 13) { 
        event.preventDefault(); 
        chatbox();
    }
});

// ------------------ check last chat open or not 
function getChatHistory() {
    $.ajax({
        method: "GET",
        url: "<?= base_url("admin/admin_functions/chat_system_getsession") ?>",
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            //alert(response.operation);
            if (response.operation == 'open') {
                //alert('open');
            openchat();
            } else {
                //alert('closed');
            // Closechat();
            }
        },
        error: function(error) {
            console.error(error);
            // Handle the error here
        }
    });
}


// ------------------ store session for last chat..
function storeHistoryChat(operation){
  
     $.ajax({
        method: "POST",
        url: "<?= base_url("admin/admin_functions/chat_system_checksession") ?>",
        data: {
            operation
        },
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
        },
        error: function(error) {
            console.error(error);
        }
    });
 
}
 
// ------------------ this function for insert chat in database after insert show last msg
    function chatbox() {
     var chat =  $("#chatbox").val();
     $("#chatbox").val("");
     var input_resize = document.getElementById("chatbox");
     var previous_msg = document.getElementById('previous_msg');
     var admin_id = <?= isset($admin_id) ? isset($admin_id) : "" ?>;
     var send_msg_ = document.getElementById('send_msg_');
        send_msg_.style.display="block";
     
     if (chat.trim() !== "") {
         play_sound_send();
    $.ajax({
        method: "POST",
        url: "<?= base_url("admin/admin_functions/chat_system") ?>",
        data: {
            chat: chat,
            admin_id: admin_id,
            reply_id:reply_id,
            reply_msg_update,
            reply_user_name,
            reply_color,
            
        },
        contentType: "application/x-www-form-urlencoded",
        success: function(response) {
            send_msg_.style.display="none";
            //console.log(response);
            if(response){
                reply_id='';
               reply_color='';
               reply_msg_update='';
               reply_user_name='';
               //fetchData_last(true);
               
               deleteDiv();
              input_resize.value="";
              $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight}, 0);

                setTimeout(function() {
                  
                   input_resize.style.height="10px";
               
                }, 200); // 2000 
             }
        },
        error: function(error) {
            console.error(error);
            // Handle the error here
            deleteDiv();
              input_resize.value="";
              $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight}, 0);

                setTimeout(function() {
                  
                   input_resize.style.height="10px";
               
                }, 200); // 2000 
        }
    });
}
}

// ------------------ this function is use for automatic check msg by using per 5 seconds
  // setInterval(function() {
      
      // fetchData_last(false);

//  }, 400);

//  setInterval(function() {
//       make_count_area();
//  }, 500);
 
  // if(typeof(Worker) !== "undefined") {
  //   if(typeof(w) == "undefined") {
  //     w = new Worker("https://at.aqato.com.au/public/worker.js");
  //   }
  //   w.onmessage = function(event) {
  //     // document.getElementById("result").innerHTML = event.data;
  //     console.log("here");
  //     fetchData_last(false);
  //   };
  // } else {
  //   // document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Workers...";
  // }

// ------------------ for delete reply div when user can have to send reply 
function deleteDiv() {
    reply_id="";
    reply_msg_update="";
   // reply_user_name='';
    //reply_color='';
    var showhidereply = document.getElementById('showhidereply');
    var custom_footer = document.getElementById('custom_footer');
    var chatbox = document.getElementById('chatbox');
    var previousMsg = document.getElementById('previous_msg');

    showhidereply.style.display = 'none';
   // custom_footer.style.height = "63px";
    previousMsg.innerHTML = '';
}


 // ------------------ show reply icon on every chat msg
function showReplyIcon(element) {
  var replyIcon = element.querySelector('.custom_style_icon');
  //var deleteIcon = element.querySelector('.custom_style_del');
  var replyIcon_left =  document.getElementById("left_reply");
  if(replyIcon_left){
  replyIcon.style.display = '';
 // deleteIcon.style.display = '';
  replyIcon_left.style.marginTop = '38px';
  }
}


// ------------------ show reply icon on every chat msg
function hideReplyIcon(element) {
  var replyIcon = element.querySelector('.custom_style_icon');
 // var deleteIcon = element.querySelector('.custom_style_del');
   replyIcon.style.display = 'none';
   //deleteIcon.style.display = 'none';
}


// ------------------ This function use for reply the previous chat
var reply_msg_update='';
var reply_msg_;
var reply_user_name='';
var reply_color='';
var reply_id='';

function reply_msg(id) {
  var previous_msg = document.getElementById('previous_msg');
  var textarea = document.getElementById('chatbox');
  var showhidereply = document.getElementById('showhidereply');
  var custom_footer = document.getElementById('custom_footer');
  var admin_id=<?= isset($admin_id) ? isset($admin_id) : "" ?>;
  //custom_footer.style.height = "132px";
  showhidereply.style.display = '';
  previous_msg.innerHTML = '';
  $.ajax({
  url: '<?= base_url("admin/admin_functions/chat_system_fetch_reply") ?>',
  method: 'GET',
  data: { id: id },
  success: function(response) {
    if(response){
        if(admin_id == response.user_id){
            var username='you';
            //alert(username);
        }else{
             var username=response.user_name;
        }
     var truncatedMessage = response.message.length > 35 ? response.message.substring(0,35) + '...' : response.message;
     var msg = `<b style="color: ${response.color}; font-size: 13px;">${username}</b> <br> ${truncatedMessage}`;
     $('#previous_msg').append(msg);
     
     //map global var
      reply_id=response.id;
      reply_msg_update=response.message;
      reply_msg_=truncatedMessage;
      reply_user_name=response.user_name;
      reply_color=response.color;
      //alert(reply_color);
      previous_msg.setAttribute('data-value', currentValue + '');
      var currentValue = parseInt(previous_msg.getAttribute('data-value')) || '';
      previous_msg.setAttribute('data-value', response.id);
      previous_msg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      textarea.focus();
    }
  },
  error: function(error) {
    console.error('Error:', error);
  }
});
}

function formatTimestamp_day(timestamp) {
  const options = { day: 'numeric', month: 'short', year: 'numeric' };
  return new Date(timestamp).toLocaleString('en-US', options);
}

// ------------------ this function is for fetch all data 

var offset_record = 0;
var prevoius_offset_record = -1;
var record_fetch = 0;  
var last_msg__id = "";


// make count box
var scroll_on_off;
function make_count_area(){
    var msg_count = document.getElementById('msg_count');
    $.get("<?= base_url("admin/admin_functions/notification_store") ?>",function(res){
        scroll_on_off=res;
        if(res > 0){
           // console.log("notification = ",res);
           $("#msg_count").text(res); 
           $('#msg_count').addClass('bg-danger');
            msg_count.style.display = 'block';
            if(res > 10){
                record_fetch = res;
            }
        }else{
            record_fetch = 10;
           msg_count.style.display = 'none'; 
        }
       // console.log("record_fetch = ",record_fetch);
    });
}


//fetch all data
var previous_date="";
var check_fetch_run = "";
    async function fetchData(no_store_last_id = "", scroll = "") {
        //console.log("from scroll function");
        if(prevoius_offset_record == offset_record){
            //console.log("Same Record");
            return;
        }
        prevoius_offset_record = offset_record;
        //daylabel_afterword_last="";
        // console.log("Feth = ",record_fetch,"offset=>",offset_record);
         try {
     const response = await $.ajax({
            // $.ajax({
                url: '<?= base_url("admin/admin_functions/chat_system_fetch") ?>', 
                method: 'POST',
                data:{
                    userTimezone,
                    record_fetch,
                    offset_record,
                    admin_id:<?= isset($admin_id) ? isset($admin_id) : "" ?>,
                },
            });
                 offset_record += record_fetch;
                 //await response;
                   //console.log(<=base_url()?>);
                   var first_record = 0;
                  //var  label_text_date = response[response.length - 1]="";
               response.forEach(function(item) {
                   if(response == null){
                       return;
                   }
                  // console.log(item);
                  if(first_record == 0){
                      previous_date = item.date_label;
                  }
                  var label_text_date="";
                   if(previous_date != item.date_label){
                         label_text_date = previous_date;
                         previous_date = item.date_label;
                            }
                
                    //console.log(label_text_date);
                        
//--------------do not touch this code----------//                   
                   if(no_store_last_id == ""){
                       if(first_record == 0){
                       last_msg__id = item.id;
                       //alert(last_msg__id);
                       first_record = 2;
                       }
                   }
                   
                   
                   //console.log(item.userid);
                   var reply_change=item.reply_user_name;
                   
                //   console.log("item = ", item.reply_user_name);
                  if('<?= $get_Admin_fname ?>' == item.reply_user_name){
                         reply_change = 'You';
                          
                     }
              
            //   if (<= $admin_id ?> == 1) {
            //     delete_chat = `<i onclick="delete_chat(${item.id});" class="bi bi-trash-fill custom_style_del" style="display:none;"></i>`;
            //   }else{
            //       var delete_chat='';
            //   }
            //  console.log(item.reply_user_name);
             //console.log(reply_change);
             var base_='<?=$base_url?>';
           if (item.reply_msg != '') {
                var truncate_msg = item.reply_msg.length > 35 ? item.reply_msg.substring(0,35) + '...' : item.reply_msg;
               //alert('fdsbgsdf');
        var width = 'width:90%;';
        var para_reply=`background-color: #d9fdd3;border-top-left-radius: 3px;border-top-right-radius: 3px;border-bottom: 0px;
                        margin-left: -1px;`
        var msg_add_left = `
        <div  class="d-flex justify-content-start message-container cursor_" style="margin-left:19px;width: 19rem; margin-top:-15px;margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p onclick="goto_up('target'+ ${item.reply_id})" data-target-id="target${item.reply_id}"  class="small p-2 mb-1  mt-3 text-start" style="${para_reply}${width}max-width: 90%;background-color:#d9fdd3;border: 8px solid #f5f6f7;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${item.reply_color}">${item.reply_user_name}&nbsp;</span>
          <br>  ${truncate_msg}
            </p>
         </div>
           `;
           
           var msg_add_right=`<div  class="d-flex justify-content-end message-container cursor_" style="width: 19rem;margin-left: 53px; margin-top: -14px;  margin-bottom: -20px">
        <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        <p onclick="goto_up('target'+ ${item.reply_id})" data-target-id="target${item.reply_id}" class="small p-2 mb-1  mt-3 text-start" style="${para_reply}width:90%;background-color: #e9edefcc;border: 8px solid #d9fdd3;">
            <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${item.reply_color}">${reply_change}&nbsp;</span>
          <br> ${truncate_msg}
            </p>
         </div>`;
           var border='';
           var border_para_main=`border-bottom-left-radius: 9px;border-bottom-right-radius: 9px;`;
        } else {
            var msg_add_left = '';
            var width = ' ';
            msg_add_right='';
            var border='rounded-3';
            var border_para_main='';
        }
                  
      var id=item.id;
      var daylabel='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+label_text_date+'</p>';
     // console.log("label=>",daylabel);
      //alert(daylabel #a2aab7);
    //  right_div
                  var paragraph = `
                
                ${msg_add_right}
<div  id="target${item.id}"  class="d-flex justify-content-end message-container" style="width: 19rem; margin-left: 53px; margin-top: -7px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
   
  <i onclick="reply_msg(${item.id});" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
  <p  class="small p-2 mb-1 ${border} mt-2 text-start cursor_" style="${width}${border_para_main}max-width: 90%;background-color:#d9fdd3;"> ${item.message}
    <span class="small d-block text-end" style="font-size: 10px; margin-left: auto; font-style: bold;">
      <i>${formatTimestamp(item.created_at)}</i>
    </span>
  </p>
</div>
   ${daylabel}
   `;
    
               
    // divleft
                var paragraph_ = `    ${msg_add_left}
                
      <div   id="target${item.id }" class="d-flex justify-content-start message-container" style="margin-left: -12px;width: 19rem; margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
      <img   src="${base_}${item.profileimg_path}"alt="avatar 1" style="width: 30px;height: 30px;margin-top: 19px; border-radius: 25px;">  
        <p  class="${border} small p-2  mb-1  mt-3 text-start cursor_" style="${width}${border_para_main}background-color: #f5f6f7;max-width: 90%;">
         <span class="small d-block text-start" style="font-size: 11px; margin-left: auto;font-weight: bold;color:${item.color};">${item.user_name}</span>
        ${item.message }<br><i class="ms-2" style="float: right;font-size: 10px;">${formatTimestamp(item.created_at)}</i></p>
         <i onclick="reply_msg(${item.id });" id="left_reply" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
        
      </div> ${daylabel}
    `;
                    
        var wrapper_reply_start = `<div class="wrapper_parent_reply">`;
        var wrapper_reply_end = `</div>`;
                  if (item.user_id == <?= $admin_id ?>) {
                            $('#result_oponent').prepend(wrapper_reply_start+paragraph+wrapper_reply_end);
                            
                        } else {
                            $('#result_oponent').prepend(wrapper_reply_start+paragraph_+wrapper_reply_end);
                        }
                        
       
       first_record++;
       //console.log(previous_date  +'--->'+label_text_date);
     });
     
      var daylabel_afterword='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+previous_date+'</p>';
      $('#result_oponent').prepend(daylabel_afterword);
      check_fetch_run = "yes";
      console.log("HHerees");
      // Fetching
      fetchData_last(false);
      console.log("Scrolling toward down");
      // End

      previous_date = "";
      if(scroll != ""){
         // console.log('scrolling');
          $('#chat_area').animate({scrollTop: $('#chat_area')[0].scrollHeight},0);
      }


       } catch (error) {
      console.error(error.responseText);
  }
        }   
        
//--------------------------------delete chat by super admin
// function delete_chat(id){
//       $.ajax({
//         method: "POST",
//         url: "<= base_url("admin/admin_functions/delete_chat_") ?>",
//         data: {
//             id
//         },
//         contentType: "application/x-www-form-urlencoded",
//         success: function(response) {
//             if(response){
//             }
    
//         },
//         error: function(error) {
//             console.error(error);
//             // Handle the error here
//         }
//     });
// }
// ------------------convert time to am pm
function formatTimestamp(timestamp) {
            var date = new Date(timestamp);
            //console.log(date);
            var timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            return timeString;
        }
        
// ----------------->fetch data by lastinsertedid<-----------------     
   var new_msg_received = 0;
   var daylabel_afterword_last="";

  //  Start
  let fetchDataRunning = false;

  async function fetchData_last(sendByUser = true) {

    if (fetchDataRunning) {
        // If fetchData_last is already running, wait for it to finish and return
        return;
    }


    fetchDataRunning = true;

    console.log("Check Fetch Run = ", check_fetch_run);

    if (check_fetch_run == "") {
        return;
    }

    var check_looping = 1;

    var input_resize = document.getElementById("chatbox");
    input_resize.setAttribute("placeholder", "Type message");

    try {
        const response_one = await fetchDataFromServer(userTimezone, last_msg__id);

        console.log("Last Message = ", last_msg__id);

        if (response_one && response_one.length > 0) {
            response_one.forEach(response => {
                // console.log(response);
                // Start
              if(response != null || response != ''){
              
              var lastItem = response;
            
               //console.log(lastItem);
              // return;
              var truncate_msg_last = lastItem.reply_msg.length > 35 ? lastItem.reply_msg.substring(0,35) + '...' : lastItem.reply_msg;
              var self_reply= lastItem.reply_user_name;
             if('<?= $get_Admin_fname ?>' == lastItem.reply_user_name){
                 self_reply ='You';
              }
             daylabel_afterword_last='<p id="days_label" class="text-center mx-3 mb-0" style="color: #a2aab7;">'+lastItem.date_label+'</p>';
          
              var para_reply=`background-color: #d9fdd3;border-top-left-radius: 3px;border-top-right-radius: 3px;border-bottom: 0px;
               margin-left: -1px;`
               
              
      
            if (lastItem.reply_id != 0) {
             var width='width:100%;';
    var msg_add = `<div  class="d-flex justify-content-end message-container cursor_" style="width: 19rem;margin-left: 53px; margin-top: -14px;  margin-bottom: -20px">
      <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
      <p  onclick="goto_up('target'+ ${lastItem.reply_id})" id="target${lastItem.reply_id}" class="small p-2 mb-1  mt-3 text-start" style="${para_reply}width:90%;background-color: #e9edefcc;border: 8px solid #d9fdd3;">
          <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${lastItem.reply_color}">${self_reply} &nbsp;</span>
          <br>${truncate_msg_last}
          </p>
       </div>`;
         var msg_add_right_single = `
      <div  class="d-flex justify-content-start message-container cursor_" style="margin-left:19px;width: 19rem; margin-top:-15px;margin-bottom: -20px">
      <i class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
      <p onclick="goto_up('target'+ ${lastItem.reply_id})" data-target-id="target${lastItem.reply_id}"  class="small p-2 mb-1  mt-3 text-start" style="${para_reply}${width}max-width: 90%;background-color:#d9fdd3;border: 8px solid #f5f6f7;">
          <span class="small d-block text-start" style="font-size: 11px;float:left;font-weight: bold;color:${lastItem.reply_color}">${lastItem.reply_user_name}&nbsp;</span>
          <br>${truncate_msg_last}
          </p>
       </div>
         `;
         var border='';
         var border_para_main=`border-bottom-left-radius: 9px;border-bottom-right-radius: 9px;`;
          } else {
              var msg_add = '';
              var width='';
              msg_add_right_single='';
          var border='rounded-3';
          var border_para_main='';
          }
        
           var base_='<?=$base_url?>';
           
          //console.log(msg_add_right_single);
          //RIGHT SIDE DIV
          var paragraph = `${daylabel_afterword_last} ${msg_add}
   <div id="target${lastItem.id }" class="d-flex justify-content-end message-container" style="width:19rem; margin-left: 53px;margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
  <i onclick="reply_msg(${lastItem.id });" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
    
     <p  class="small p-2  mb-1  mt-3 text-start cursor_ ${border}" style="${width}${border_para_main} background-color: #d9fdd3;max-width: 90%;">${lastItem.message }
       <span class="small d-block text-end" style="font-size: 11px;margin-left: auto;font-style: italic;"><i>${formatTimestamp(lastItem.created_at)}</i></span>
      </p>
    </div>
`;
      //left side div
      
            var paragraph_ = `${daylabel_afterword_last}  ${msg_add_right_single}
    <div id="target${lastItem.id }"  class="d-flex justify-content-start message-container" style="margin-left: -12px;width: 19rem; margin-top:-15px;" onmouseout="hideReplyIcon(this)" onmouseover="showReplyIcon(this)">
     <img   src="${base_}${lastItem.profileimg_path}"alt="avatar 1" style="width: 30px;height: 30px;margin-top: 19px; border-radius: 25px;">
      <p  class="small p-2  mb-1  mt-3 text-start cursor_  ${border}" style="${width}${border_para_main}background-color: #f5f6f7;max-width: 90%;">
       <span class="small d-block text-start" style="font-size: 11px; margin-left: auto;font-weight: bold;color:${lastItem.color};">${lastItem.user_name}</span>
      ${lastItem.message }<br><i class="ms-2" style="float: right;font-size: 10px;">${formatTimestamp(lastItem.created_at)}</i></p>
       <i onclick="reply_msg(${lastItem.id });" id="left_reply" class="bi bi-reply-fill custom_style_icon" style="display:none;"></i>
    </div>
  `; 
       if(last_msg__id != lastItem.id){
           var msg_count = document.getElementById('msg_count');
           
            
            if (lastItem.user_id == <?= $admin_id ?>) {
                
                          $('#result_oponent').append(paragraph);
            } else{
                new_msg_received++;
                
                //console.log(notification);
                // msg_count.style.display = 'block';
               // console.log(new_msg_received);
              //   $('#msg_count').text(new_msg_received);
              //   $('#msg_count').addClass('bg-danger');
                  
                 $('#result_oponent').append(paragraph_);
            }
            // if(check_looping == 0){
            //   last_msg__id = lastItem.id; 
            //   check_looping++;
            // }
            
                
       }        
         
           }
                  // End

              });


              
              console.log("Last Message = ", last_msg__id);
                
              last_msg__id = response_one[0].id;

        }

        if (new_msg_received != 0) {
            play_sound();
            new_msg_received = 0;
        }
        make_count_area();
        setTimeout(async () => {
            fetchDataRunning = false;
            await fetchData_last(false);
        }, 500);

        console.log("Running Last Function");
    } catch (error) {
        console.error(error);
        fetchDataRunning = false;
        // If an error occurs, clear the flag to allow future attempts
        setTimeout(() => {
            fetchData_last(false);
        }, 500);
    }
}

function fetchDataFromServer(userTimezone, last_msg__id) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '<?= base_url("admin/admin_functions/last_one_data_fetch") ?>',
            method: 'POST',
            data: {
                userTimezone,
                last_msg__id
            },
            success: function (response) {
                resolve(response);
            },
            error: function (xhr, status, error) {
                reject(error);
            }
        });
    });
}


  // End
        

//----------store notification-----//
var notify=0;
    // function notification_store(){
        
    //     $.ajax({
            
    //      url: '<= base_url("admin/admin_functions/notification_store") ?>', 
    //      method: 'POST',
    //      data:{
    //          admin_id:<?=$admin_id?>,
          
    //       },
    //     success: function(response) {
    //                  console.log(response);
    //                 //   if(response.notification != 0 ){
    //                 //  notify=response.notification;
    //                 //  console.log(notify);
    //                 //   $('#msg_count').text(notify);
    //                 //   $('#msg_count').addClass('bg-danger');
    //                 //  }
    //              },
    //              });
    // }

//after scroll and closed chat update 0 for same id
    function update_chat_aftershownotification(){
        
        $.ajax({
            
         url: '<?= base_url("admin/admin_functions/update_chat_aftershownotification") ?>', 
         method: 'POST',
         data:{
             admin_id:<?=$admin_id?>,
          
          },
        success: function(response) {
                     
                      
                 },
                 });
    }
// ----------------->when received msg this for notification sound<----------------- 
 function play_sound() {
    var audio = new Audio();
    audio.src = "<?= base_url('public/chat_notification/Iphone Notification.mp3') ?>";
    audio.type = "audio/ogg";
    audio.play();
    console.log(' audio played');
    
  }
  



  //when send msg 
  function play_sound_send() {
    var audio = new Audio();
    audio.src = "<?=base_url('public/chat_notification/google_glass_message.mp3')?>";
    audio.type = "audio/ogg";
    audio.play();
    console.log(' audio played');
  }
  // ----------------->this for scroll to parent msg<----------------- 
  
 

function goto_up(element) {
  $("#" + element).find("p").css({
  //backgroundColor: "rgb(146 247 135)", 
  border: "2px solid #FFCC01"
});
  $("#" + element).get(0).scrollIntoView();
  
   setTimeout(function() {
    $("#" + element).find("p").css({
     // backgroundColor: "#e9edefcc", 
      border: ""
    });
  }, 2000); // 2000 
}





// ----------------->this is use to hide span design purpose<----------------- 
  function hideSpans() {
         //for show tooltip
   var navLinks = document.querySelectorAll(".nav-link");
   var tooltips = ["Dashboard", "Application Manager", "Interview Bookings","Practical Bookings","Applicant / Agent","Staff Management","Occupation Manager","Locations","Verification","Archive","Mail Template","Offline Files","Admin Functions"];
   navLinks.forEach(function(linkElement, index) {
    var tooltipValue = tooltips[index % tooltips.length];
    linkElement.setAttribute("data-toggle", "tooltip");
    linkElement.setAttribute("data-placement", "top");
    linkElement.setAttribute("title", tooltipValue);
});

  var currentURL = window.location.href;
  var parts = currentURL.split('/');
  
  var url_view_edit = parts[7]; // view edit
  var interview_booking=parts[4];
  //alert(interview_booking);
 //all code align for css and closed open chat box. 
  var sidebar = document.getElementById("sidebar");
  var sidebar_right = document.querySelector(".sidebar_right");
  var section = document.querySelector(".section");
  var main = document.getElementById("main");
  var spans = sidebar.getElementsByTagName("span");
 
   
  for (var i = 0; i < spans.length; i++) {
    spans[i].style.display = "none";
  }
  sidebar.style.width = "90px";
  main.style.padding = "20px 30px";
  main.style.transition = "all 0.3s";
  main.style.width = "100%";
  main.style.marginTop = "88px !important";
// sidebar.style.height="78%";
 var sidebarWidth = 90; 
var chatWidth = 390;  
if(url_view_edit == 'notes'){
   var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth) + 32; 
}else if(interview_booking = 'interview_booking' ){
var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth)-5; 
//alert(totalWidthMain);
}
else{
   var totalWidthMain = window.innerWidth - (sidebarWidth + chatWidth) + 10; 
}
//alert(window.innerWidth);
  if (window.innerWidth >= 1400) {
    main.style.marginLeft = "83px";
    main.style.width = totalWidthMain +15+ "px";  
  }
  //check condition for view and update url
  if(url_view_edit == 'view_edit' || url_view_edit == 'all_documents' || url_view_edit == 'notes'){
      main.classList.remove('w-100');
      //section.style.width ="84%";
      if (window.innerWidth) {
          if(url_view_edit == 'all_documents'){
               main.style.marginLeft = "73px";
      main.style.width = totalWidthMain + 35 + "px";
          }else{
      main.style.marginLeft = "73px";
      main.style.width = totalWidthMain + 18 + "px";  
          }
  }
  }
}

// ----------------->this is use to show span design purpose<----------------- 
function showSpans() {
    
    //for  hide tooltip
  var navLinks = document.querySelectorAll(".nav-link");

// Iterate through each element and remove tooltip attributes
navLinks.forEach(function(linkElement) {
    linkElement.removeAttribute("data-toggle");
    linkElement.removeAttribute("data-placement");
    linkElement.removeAttribute("title");
});


   var currentURL = window.location.href;
  var parts = currentURL.split('/');
  var url_view_edit = parts[7]; // view edit
  //check url
 //all code align for css and closed open chat box. 
  var section = document.querySelector(".section");
  var main = document.getElementById("main");
  var sidebar = document.getElementById("sidebar");
  var spans = sidebar.getElementsByTagName("span");
  for (var i = 0; i < spans.length; i++) {
    spans[i].style.display = "";
  }
  sidebar.style.width = "18%";
//   section.style.width ="100%";
  main.style.padding = "20px 30px";
  main.style.transition = "all 0.3s";
  main.style.width = "100%";
  main.style.marginLeft = "303px";
  main.style.marginTop = "116px !important";
  
  if(url_view_edit == 'view_edit'){
     
      section.style.width ="100%";
  }
} 

 function check_active(){
         var activeDiv = document.getElementById("show_active");
        
        $.ajax({
         url: '<?= base_url("admin/admin_functions/check_active") ?>', 
         method: 'GET',
         success: function(response) {
              activeDiv.style.display = "block";
         //console.log(response);  
         response.forEach(function(adminData) {
         var path=adminData.profileimg_path;
         var bg=(adminData.is_active === 'yes') ? 'bg-success' : 'bg-danger';
         if(adminData.id == 1 || adminData.id == 2){
          var admin_name=adminData.first_name;   
         }else{
          var admin_name=adminData.first_name + " " + adminData.last_name; 
         }
         
        // console.log(admin_name);
         var html_show=`
         <div class="text-start">
         <div class="position-relative">
            <img src="${path}" alt="avatar" class="mb-1 img d-inline">
            <span style="padding: 5px;" class=" ${bg} position-absolute translate-middle border border-light rounded-circle custom_badge"></span>
             <p class="d-inline ms-2">${admin_name}</p>
        </div>
       
        </div>
        `;
             $('#show_active').append(html_show);
    });          
                 },
                 });
    }
    
    
//var evtSource = new EventSource("<= base_url("admin/admin_functions/check_date") ?>");

             //evtSource.onopen = function() {
			//	console.log("Connection to server opened.");
			 // };

		//	evtSource.onmessage = function(e) {
		     //textContent = "message: " + e.data;
			//console.log(textContent);
			//};

// 			evtSource.onerror = function() {
// 				console.log("EventSource failed.");
// 			};



    </script>