<?= $this->extend('template/admin_template') ?>
<?= $this->section('main') ?>

<style>
.text-color{
    color: black;
    font-size: 20px;
}
.text-color:hover{
    color: black; 
}
.accordion-button{
    font-size: 20px;
}
.nav-pills .nav-link.active, .nav-pills .show>.nav-link{
    background-color: var(--yellow);
    color: var(--green);
}
#cover-spin {
    position: fixed;
    width: 100%;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background-color: rgba(251, 251, 251, 0.6);
    z-index: 9999;
    display: none;
}
#loader_img{
    position: fixed;
    left: 50%;
    top: 50%;
}

</style>
<main id="main" class="main">

    <div class="pagetitle">
        <h1 class="text-green mt-3">View / Update </h1>
        <b>
            <snap  class="mt-2"><?php

               echo $s1_personal_details->first_or_given_name." ".$s1_personal_details->middle_names." ".$s1_personal_details->surname_family_name;
                    if (empty($stage_1->unique_id)) {
                        $unique_code = "[#T.B.A] - ";
                    }else{
                        $unique_code = "[#".$stage_1->unique_id."]- ";
                    }
                echo $unique_code;
               echo $s1_contact_details->state_proviance.", ";
               echo $s1_contact_details->country;
               ?>


            </snap>
            <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                <br>
                <snap  class="mt-1">
                    <?php 
                    
                     echo  $username->name." ". $username->middle_name." ". $username->last_name. " - " . $username->business_name; ?>
                </snap>
            <?php } ?>

        </b> 
    </div><!-- End Page Title -->

    <section class="section dashboard mt-5 shadow">
        <div class="card card-primary card-outline card-tabs">
            <div class="card-header p-0 pt-1 border-bottom-0">
                <?php
                if($tab=="view_edit"){
                    $view_tab = "active";               
                    $document_tab = "";
                    $btn_view= "btn_yellow_green";
                    $btn_doc ="";
                }else{
                    $view_tab = "";               
                    $document_tab = "active";
                    $btn_view= "";
                    $btn_doc ="btn_yellow_green";
                }?>
                <!-- ---------------tabs--------- -->
                <!-- Bordered Tabs Justified -->
                <ul class="nav nav-pills nav-fill">
                    <li class="nav-item">
                        <a class="nav-link text-center text-color <?=$view_tab?>" id="tabs_view_edit" href="<?= base_url("admin/application_manager/view_application/". $pointer_id. "/view_edit") ?>" role="tab" aria-controls="tabs_view_edit" aria-selected="true">View / Update</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-center text-color <?=$document_tab?>" id="tabs_documents" href="<?= base_url("admin/application_manager/view_application/" . $pointer_id. "/all_documents") ?>" role="tab" aria-controls="tabs_documents" aria-selected="false">Submitted Documents</a>
                    </li>
                </ul>
                
            </div> 
            <div class="tab-content">

                <!-- ------------view_edit tab starts--------- -->

                <div class="tab-pane fade show <?=$view_tab?>" id="view_view_edit" role="tabpanel" aria-labelledby="tabs_view_edit">
                    <!-- Table with stripped rows -->
                    <div class="card-body">
                        <form action="" method="post">
                            <table class="table table-striped border table-hover">
                                <tr>
                                    <td width="30%">Applicant's name</td>
                                    <td class="w-25">
                                        <?= $s1_personal_details->first_or_given_name." ".$s1_personal_details->middle_names." ".$s1_personal_details->surname_family_name; ?>
                                    </td>
                                </tr>
                                <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                                    <tr>
                                        <td width="30%">Contact Number</td>
                                        <td class="w-25">
                                            <?php
                                            if (!empty($s1_contact_details->mobile_number_code)) {
                                                echo "+" . $s1_contact_details->mobile_number_code;
                                            }
                                            ?> <?= $s1_contact_details->mobile_number ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <td>Occupation</td>
                                    <td class="w-25"><?= find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name ?></td>
                                </tr>
                                <tr>
                                    <td width="30%">Program</td>
                                    <td class="w-25">
                                        <?php
                                        echo  $s1_occupation->program;
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="30%">Pathway</td>
                                    <td class="w-25">
                                        <?php
                                        echo  $s1_occupation->pathway;
                                        ?> 
                                    </td>
                                </tr>
                                <tr>
                                    <td>Assigned to</td>
                                    <td class="w-25">
                                        <select class="form-select mb-3" aria-label="Default select example" name="assigned_to">
                                            <option selected value="Self"> Self </option>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </form>
                        <!--  -------------------Stage 1 - Self Assessment ---------------- -->
                        <?php if($stage_1 !=""){ 
                            echo $this->include("admin/application_manager/view_update/stage_1.php"); 
                        } ?>
                        <!--  -------------------End stage 1 self assesment ---------------- -->
                        <!-- -------------------Stage 2 - Documentary Evidence ---------------- -->
                        <?php
                        if($stage_2 !=""){ 
                            echo $this->include("admin/application_manager/view_update/stage_2.php");
                        } ?>
                        <!--  -------------------End stage 2 Documentary Evidence ---------------- -->
                        <!-- -------------------Stage 3 - Documentary Evidence ---------------- -->
                        <?php
                        if($stage_3 !=""){ 
                            echo $this->include("admin/application_manager/view_update/stage_3.php");
                        } ?>
                        <!--  -------------------End stage 3 Documentary Evidence ---------------- -->
                    </div>
                </div>
                <!-- ------view_edit tab ends------ -->

                <!-- ------documents tab starts------ -->

                <div class="tab-pane fade  show <?=$document_tab?>" id="view_documents" role="tabpanel" aria-labelledby="tabs_documents">

                    <div class="card-body">

                        <?php if (session()->has('zip_error')) { ?>
                            <br>
                            <div class="alert alert-danger alert-dismissible fade show mt-5 mb-3" role="alert" id="alert">
                                <p class="text-center"><?= session()->get('zip_error') ?></p>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php } ?>

                        <!-- ------------------stage 1 documents --------- -->
                        <?php if($stage_1 !=""){ 
                            echo $this->include("admin/application_manager/document/stage_1.php"); 
                        } ?>
                        <!-- ------------------stage 1 documents end --------- -->
                        <!-- ------------------stage 2 documents --------- -->
                        <?php if($stage_2 !=""){ 
                            echo $this->include("admin/application_manager/document/stage_2.php"); 
                        } ?>
                        <!-- ------------------stage 2 documents end --------- -->
                        <!-- ------------------stage 3 documents --------- -->
                        <?php 
                        if($stage_3 !=""){ 
                            echo $this->include("admin/application_manager/document/stage_3.php"); 
                        } ?>
                        <!-- ------------------stage 3 documents end --------- -->

                        
                        
                    </div>
                </div>

            </div>
        </div>
    </section>
    <div id="cover-spin">
        <div id="loader_img">
            <img src="<?= base_url("public/assets/image/admin/loader.gif") ?>" style="width: 100px; height:auto">
        </div>
    </div>
</main>


<?= $this->endSection() ?>
<?= $this->section('custom_script') ?>
<script>
    
    var pointer_id = <?=$pointer_id?>;
    var tab = '<?= $tab ?>';
   
// view updata ------------------------------  

    const readonlyInput = (element,read) => {
        console.log(read);
        if (read != "") {
            $(element).attr("readonly", "true");
            read = false;
        } else {
            $(element).removeAttr("readonly");
            read = true;
        }
    }
    // view updata->stage 1 ----------------------------
        var status = '<?=$stage_1->status?>';
        if(status =="Declined"){
            $("#reason_tr").show();
        }else{
            $("#reason_tr").hide();
        }
        if(status =="Lodged" || status =="Submitted"){
            $("#headoffice_no").hide();
        }else{
            $("#headoffice_no").show();
        }
        $("#reason_input").attr("required", "false");
        const change_status = (val) => {
            console.log(val);
            if (val == "Declined") {
                $("#reason_input").attr("required", "true");
                $("#reason_tr").show();
            } else {
                $("#reason_input").attr("required", "");
                $("#reason_tr").hide();
                $("#reason_input").removeAttr("required");
            }
            if (val == "In Progress") {
                $("#ho_input").attr("required", "true");
                $("#headoffice_no").show();
            } else {
                $("#ho_input").attr("required", "");
                $("#headoffice_no").hide();
            }
        }
       
        
        // change status stage 1 ----------------------------
        $("#stage_1_change_status").submit(function(e) {
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $('#cover-spin').show(0);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/status_change/stage_1") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    console.log(data);
                    data = JSON.parse(data);
                    // window.location.reload();
                    if(data["response"] == true) {
                        window.location.reload();
                        // window.location = "<?= base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 
    // view updata->stage 1 end ----------------------------
    // view updata->stage 2 ----------------------------
        <?php if($stage_2 !=""){ ?> 
            var status_2 = '<?=$stage_2->status?>';
        <?php }else{ ?>
            var status_2 = "";
        <?php } ?>
        if(status_2 =="Declined"){
            $("#reason_tr_2").show();
        }else{
            $("#reason_tr_2").hide();
        }
        $("#reason_input_2").attr("required", "false");
        const change_status_2 = (val) => {
            console.log(val);
            if (val == "Declined") {
                $("#reason_input_2").attr("required", "true");
                $("#reason_tr_2").show();
            } else {
                $("#reason_input_2").attr("required", "");
                $("#reason_tr_2").hide();
                $("#reason_input_2").removeAttr("required");
            }
        }
        // change status stage 2 ----------------------------
        $("#stage_2_change_status").submit(function(e) {
        e.preventDefault();
        $('#cover-spin').show(0);
        var formData = new FormData($(this)[0]);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/status_change/stage_2") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    data = JSON.parse(data);
                    if(data["response"] == true) {
                        window.location.reload();
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 
    // view updata->stage 2 end ----------------------------
    // view updata->stage 3 ----------------------------
        <?php if($stage_3 !=""){ ?>
            var status_3 = '<?=$stage_3->status?>';
        <?php }else{ ?>
            var status_3 = "";
        <?php } ?>
        if(status_3 =="Declined"){
            $("#reason_tr_3").show();
        }else{
            $("#reason_tr_3").hide();
        }
        $("#reason_input_3").attr("required", "false");
        const change_status_3 = (val) => {
            console.log(val);
            if (val == "Declined") {
                $("#reason_input_3").attr("required", "true");
                $("#reason_tr_3").show();
            } else {
                $("#reason_input_3").attr("required", "");
                $("#reason_tr_3").hide();
                $("#reason_input_3").removeAttr("required");
            }
        }
        // change status stage 3 ----------------------------
        $("#stage_3_change_status").submit(function(e) {
        e.preventDefault();
        $('#cover-spin').show(0);
        var formData = new FormData($(this)[0]);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/status_change/stage_3") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    data = JSON.parse(data);
                    if(data["response"] == true) {
                        window.location.reload();
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 
    // view updata->stage 3 end ----------------------------
// view updata end ------------------------------
// Documnents ------------------------------
    // Common function --------------------------- 
        // Delete function --------------------------- 
        function delete_document(id){
            //     custom_alert_popup_show(header = '', body_msg = "Are you sure you want to delete this file?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJD');
            // // check Btn click
            //     $("#AJD").click(function() {
            //         // if return true 
            //         if (custom_alert_popup_close('AJD')) {
                if (confirm("Are you sure you want to delete this file?")) {
                    $('#cover-spin').show(0);  
                    $.ajax({
                        url: "<?= base_url('admin/application_manager/delete_document/') ?>/" + id,
                        type: "POST",
                        dataType: "JSON",
                        success: function(data) {
                            data = JSON.parse(data);
                            if (data["response"] == true) {
                                window.location = "<?= base_url("admin/application_manager/view_application/") ?>/"+pointer_id+'/'+tab;
                            } else {
                                alert(data["msg"]);
                            }
                        },
                    });
                }
            //     });
        }
    // Common function end --------------------------- 
    // document->stage 1 ----------------------------
        function show_input(count_id) {
             if ($("#input_" + count_id).css("display") == "none") {
                $("#input_" + count_id).css("display", "block");
                $("#input_" + count_id).focus();
                $("#Dbtn_" + count_id).hide();
                $("#Xbtn_" + count_id).show();
                console.log("ch_3");
                check();
            }else {
                $("#input_" + count_id).val("");
                $("#input_" + count_id).css("display", "none")
                $("#Dbtn_" + count_id).show();
                $("#Xbtn_" + count_id).hide();
                $('#s1_doc_sub_btn').css("display", "block");
                console.log("check");
                check();
            }
        }
        function check() {
            var count_ = 0;
            var value = $('input[type="text"].s1').filter(function() {
                console.log(value);
                if (this.value.length > 0) {
                    count_++;
                }
            });
            console.log(count_);
            if (count_ > 0) {
                $('#s1_doc_sub_btn').css("display", "block");
            } else {
                $('#s1_doc_sub_btn').hide();
            }
        }
        // zip fpr all stage function --------------------------- 
        function download_zip(pointer_id,stage){
            // creat alert box 
            custom_alert_popup_show(header = '', body_msg = "Are you sure you want to download all files?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
            // check Btn click
            $("#AJDSAKAJLD").click(function() {
                // if return true 
                if (custom_alert_popup_close('AJDSAKAJLD')) {
                    $.ajax({
                        url: "<?= base_url('admin/application_manager/download_zip') ?>/"+ pointer_id + '/' + stage,
                        type: "POST",
                    data:{
                        "pointer_id":pointer_id,
                        "stage" :stage,
                    },
                    beforeSend: function() {},
                        success: function(data) {
                            console.log(data);
                            window.location = data;
                            
                        },
                    });
                }
            })
        }   
        // comments function ---------------------------   
        $("#reason_form_stage_1").submit(function(e) {
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $('#cover-spin').show(0);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/comment_document") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    data = JSON.parse(data);
                    if(data["response"] == true) {
                        window.location.reload();
                        // window.location = "<?= base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 

    // document->stage 1 end ----------------------------
    // document->stage 2 ----------------------------
        function show_input_s2(count_id) {
            if ($("#input_s2_" + count_id).css("display") == "none") {
                $("#input_s2_" + count_id).css("display", "block");
                $("#input_s2_" + count_id).focus();
                $("#Dbtn_s2_" + count_id).hide();
                $("#Xbtn_s2_" + count_id).show();
                check_s2();
            }else {
                $("#input_s2_" + count_id).val("");
                $("#input_s2_" + count_id).css("display", "none")
                $("#Dbtn_s2_" + count_id).show();
                $("#Xbtn_s2_" + count_id).hide();
                $('#s2_doc_sub_btn').css("display", "block");
                check_s2();
            }
        }
        function check_s2() {
            var count_ = 0;
            var value = $('input[type="text"].s1').filter(function() {
                console.log(value);
                if (this.value.length > 0) {
                    count_++;
                }
            });
            console.log(count_);
            if (count_ > 0) {
                $('#s2_doc_sub_btn').css("display", "block");
            } else {
                $('#s2_doc_sub_btn').hide();
            }
        }
        // comments function ---------------------------   
        $("#reason_form_stage_2").submit(function(e) {
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $('#cover-spin').show(0);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/comment_document") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    data = JSON.parse(data);
                    if(data["response"] == true) {
                        window.location.reload();
                        // window.location = "<?= base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 
    // document->stage 2 end ----------------------------
    // document->stage 3 ----------------------------
        function show_input_s3(count_id) {
            if ($("#input_s3_" + count_id).css("display") == "none") {
                $("#input_s3_" + count_id).css("display", "block");
                $("#input_s3_" + count_id).focus();
                $("#Dbtn_s3_" + count_id).hide();
                $("#Xbtn_s3_" + count_id).show();
                console.log("hfjhg");
                check_s3();
            }else {
                $("#input_s3_" + count_id).val("");
                $("#input_s3_" + count_id).css("display", "none")
                $("#Dbtn_s3_" + count_id).show();
                $("#Xbtn_s3_" + count_id).hide();
                $('#s3_doc_sub_btn').css("display", "block");
                check_s3();
            }
        }
        function check_s3() {
            var count_ = 0;
            var value = $('input[type="text"].s1').filter(function() {
                console.log(value);
                if (this.value.length > 0) {
                    count_++;
                }
            });
            console.log(count_);
            if (count_ > 0) {
                $('#s3_doc_sub_btn').css("display", "block");
            } else {
                $('#s3_doc_sub_btn').hide();
            }
        }
        // comments function ---------------------------   
        $("#reason_form_stage_3").submit(function(e) {
        e.preventDefault();
        var formData = new FormData($(this)[0]);
        $('#cover-spin').show(0);
            $.ajax({
                method: "POST",
                url: "<?= base_url("admin/application_manager/comment_document") ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    data = JSON.parse(data);
                    if(data["response"] == true) {
                        window.location.reload();
                        window.location = "<?= base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                    }else{
                        alert(data["msg"]);
                    }
                }
            });
        }); 
    // document->stage 3 end ----------------------------
// Documnents end ------------------------------
 var stage_level ='<?=$application_pointer->stage?>';
    if(stage_level =='stage_1'){
        var element = document.getElementById("view_stage_1");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_1");
        element_1.classList.add('show')
    }else if(stage_level =='stage_2'){
        var element = document.getElementById("stage_2");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_2");
        element_1.classList.add('show')
    }else if(stage_level =='stage_3'){
        var element = document.getElementById("stage_3");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_3");
        element_1.classList.add('show')
    }
</script>
                

<?= $this->endSection() ?>