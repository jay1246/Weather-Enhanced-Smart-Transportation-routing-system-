<div class="accordion" id="flip-view_stage_2">
    <div class="accordion-item">
        <h2 class="accordion-header" id="flush-headingOne">
            <button class="accordion-button collapsed text-green text-center" type="button" data-bs-toggle="collapse" data-bs-target="#stage_2" aria-expanded="false" aria-controls="stage_2" style="color:#012970;">
                Stage 2 - Documentary Evidence
            </button>
        </h2>

        <div id="stage_2" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#flip-view_stage_2">
            <div class="accordion-body">
                <form action="" id="stage_2_change_status" method="post">
                    <table class="table table-striped border table-hover"> 
                        <tr>
                            <td width="30%">Current Status</td>
                            <td class="w-25"><?= $stage_2->status ?></td>
                        </tr>
                        <tr> 
                            <td>Submitted Date</td>
                            <td class="w-25"><?=date('d/m/Y  H:i:s',strtotime($stage_2->submitted_date)) ?></td>
                        </tr>
                        <?php if ($stage_2->lodged_date !="0000-00-00 00:00:00" || $stage_2->lodged_date != null) { ?>
                            <tr>
                                <td>Lodged Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_2->lodged_date)) ; ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_2->status == 'Approved') { ?>
                            <tr>
                                <td>Approved Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_2->approved_date)) ; ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_2->status == 'Expired') { ?>
                            <tr>
                                <td style="width: 30%;">Approved Date</td>
                                <td>
                                    <?=date('d/m/Y  H:i:s',strtotime($stage_2->approved_date)) ; ?>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 30%;">Expired Date</td>
                                <td>
                                    
                                </td>
                            </tr>
                        <?php  } 
                        if ($stage_2->status == 'Declined') { ?>
                            <tr>
                                <td>Declined Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_2->declined_date)); ?>
                                </td>
                            </tr>
                        <?php }
                        if ($stage_2->status == 'Withdrawn') { ?>
                            <tr>
                                <td>Withdrawn Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_2->withdraw_date)) ; ?>
                                </td>
                            </tr>
                        <?php } ?>
                        <tr>
                            <td>Change Status</td>
                            <?php
                            $check = '';
                            if($stage_2->status=="Submitted"){
                                $log_active_2 = "";
                                $log_select_2 = $pro_select_2 = $app_select_2 = $dec_select_2 = $with_select_2 =  "";
                                $pro_active_2 = $app_active_2 = $dec_active_2 = $with_active_2 = "disabled";
                            }else if($stage_2->status=="Lodged"){
                                $log_select_2 ="selected";
                                $pro_active_2 = "";
                                $pro_select_2 = $app_select_2 = $dec_select_2 = $with_select_2 =  "";
                                $log_active_2 = $app_active_2 = $dec_active_2 = $with_active_2 = "disabled";
                            }else if($stage_2->status=="In Progress"){
                                $app_select_2 ="selected";
                                $dec_active_2 = $with_active_2 = "";
                                $pro_select_2 = $log_select_2 = $dec_select_2 = $with_select_2 =  "";
                                $log_active_2 = $app_active_2 = $pro_active_2  ="disabled";
                            }else if($stage_2->status=="Approved"){
                                $app_select_2 ="selected";
                                $dec_active_2 = $with_active_2 = "";
                                $pro_select_2 = $log_select_2 = $dec_select_2 = $with_select_2 =  "";
                                $log_active_2 = $app_active_2 = $pro_active_2  ="disabled";
                            }else if($stage_2->status=="Declined"){
                                $dec_select_2 ="selected";
                                $dec_active_2 = $with_active_2 = $log_active_2 = "";
                                $pro_select_2 = $app_select_2 = $log_select_2 = $with_select_2 =  "";
                                $app_active_2 = $pro_active_2  ="disabled";
                            }else if($stage_2->status=="Withdrawn"){
                                $with_select_2 ="selected";
                                $dec_active_2 = $with_active_2 = $log_active_2 = "";
                                $pro_select_2 = $app_select_2 = $dec_select_2 = $log_select_2 =  "";
                                $app_active_2 = $pro_active_2  ="disabled";
                            }
                            $check .= 'disabled';

                            ?>
                            <td class="w-25">
                                <select required class="form-select mb-3 stg_2_status_select" aria-label="Default select example" name="status" id="stage_2_status_drop" onchange="change_status_2(this.value)">
                                    <option disabled>Select</option>
                                    <option id="lodged_2" value="Lodged" <?=$log_active_2.$log_select_2?> >Lodged</option>
                                    <option id="in_progress_2" value="In Progress" <?=$pro_active_2.$pro_select_2?> >In Progress</option>
                                    <option id="approved_2" value="Approved" <?=$app_active_2.$app_select_2?>>Approved</option>
                                    <option id="declined_2" value="Declined" <?=$dec_active_2.$dec_select_2?>>Declined</option>
                                    <option id="Withdrawn_2" value="Withdrawn" <?=$with_active_2.$with_select_2?>>Withdrawn</option>
                                </select>
                                <input type="hidden" name="pointer_id" value="<?= $stage_2->pointer_id ?>"> 
                                <input type="hidden" name="user_id" value="<?= $user_id ?>"> 
                                <input type="hidden" name="stage_2_id" value="<?= $stage_2->id ?>"> 
                                
                            </td>
                        </tr>                      
                        <tr id="reason_tr_2" style="display: none;">
                            <td> Reason :</td>
                            <td class="w-20">
                                <div style="display: flex;" class="position-relative">
                                    <textarea class="form-control" 
                                    <?php
                                        if ($stage_2->status == 'Declined' ) {
                                            echo "readonly";
                                        }
                                    ?> id="reason_input_2" name="reason" rows="3"><?php
                                    if($stage_2->status == 'Declined'){
                                        echo $stage_2->declined_reason;
                                    } ?> </textarea>

                                    <a href="javascript:void(0)" id="stage_2_hide_show_btn_reson" style="vertical-align: bottom;" class="btn btn-sm btn_yellow_green position-absolute bottom-0 end-0" onclick="readonlyInput('#reason_input_2')">
                                                                <i class="bi bi-pencil-square"></i> </i></a>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="text-center">
                                <button type="submit" class="btn btn_green_yellow">Update</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>

