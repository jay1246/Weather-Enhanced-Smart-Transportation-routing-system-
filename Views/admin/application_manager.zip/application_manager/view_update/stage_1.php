<div class="accordion" id="flip-view_stage_1">
    <div class="accordion-item">
        <h2 class="accordion-header" id="view_head_stage_1">
            <button class="accordion-button collapsed text-green" type="button" data-bs-toggle="collapse" data-bs-target="#view_stage_1" aria-expanded="false" aria-controls="view_stage_1" >
                Stage 1 - Self Assessment
            </button>
        </h2>

        <div id="view_stage_1" class="accordion-collapse collapse" aria-labelledby="view_head_stage_1" data-bs-parent="#flip-view_stage_1">
            <div class="accordion-body">
                <form action="" id="stage_1_change_status" method="post">
                    <table class="table table-striped border table-hover">
                        <tbody>
                            <tr>
                                <td width="30%">Current Status</td>
                                <td class="w-25"><?= $stage_1->status ?></td>
                            </tr>
                            <tr>
                                <td>Submitted Date</td>
                                <td class="w-25"><?= date('d/m/Y  H:i:s',strtotime($stage_1->submitted_date)) ?></td>
                            </tr>
                            <?php if ($stage_1->lodged_date !="0000-00-00 00:00:00" || $stage_1->lodged_date != null) { ?>
                                <tr>
                                    <td>Lodged Date</td>
                                    <td class="w-25">
                                        <?php echo date('d/m/Y  H:i:s',strtotime($stage_1->lodged_date)); ?>
                                    </td>
                                </tr>
                            <?php } 
                            if ($stage_1->status == 'Approved') { ?>
                                <tr>
                                    <td>Approved Date</td>
                                    <td class="w-25">
                                        <?php echo date('d/m/Y  H:i:s',strtotime($stage_1->approved_date)); ?>
                                    </td>
                                </tr>
                            <?php } 
                            if ($stage_1->status == 'Expired') { ?>
                                <tr>
                                    <td style="width: 30%;">Approved Date</td>
                                    <td>
                                        <?= date('d/m/Y  H:i:s',strtotime($stage_1->approved_date)); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%;">Expired Date</td>
                                    <td>
                                        
                                    </td>
                                </tr>
                            <?php  } 
                            if ($stage_1->status == 'Declined') { ?>
                                <tr>
                                    <td>Declined Date</td>
                                    <td class="w-25">
                                        <?php echo date('d/m/Y  H:i:s',strtotime($stage_1->declined_date)); ?>
                                    </td>
                                </tr>
                            <?php }
                            if ($stage_1->status == 'Withdrawn') { ?>
                                <tr>
                                    <td>Withdrawn Date</td>
                                    <td class="w-25">
                                        <?php echo date('d/m/Y  H:i:s',strtotime($stage_1->withdraw_date)); ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td>Change Status</td>
                                <?php
                                $check = '';
                                if($stage_1->status=="Submitted"){
                                    $log_active = "";
                                    $log_select = $pro_select = $app_select = $dec_select = $with_select = $rei_select= "";
                                    $pro_active = $app_active = $dec_active = $with_active = $rei_active ="disabled";
                                }else if($stage_1->status=="Lodged"){
                                    $log_select ="selected";
                                    $pro_active = "";
                                    $pro_select = $app_select = $dec_select = $with_select = $rei_select= "";
                                    $log_active = $app_active = $dec_active = $with_active = $rei_active ="disabled";
                                }else if($stage_1->status=="In Progress"){
                                    $app_select ="selected";
                                    $dec_active = $with_active = $rei_active  = "";
                                    $pro_select = $log_select = $dec_select = $with_select = $rei_select= "";
                                    $log_active = $app_active = $pro_active  ="disabled";
                                }else if($stage_1->status=="Approved"){
                                    $app_select ="selected";
                                    $dec_active = $with_active = $rei_active  = "";
                                    $pro_select = $log_select = $dec_select = $with_select = $rei_select= "";
                                    $log_active = $app_active = $pro_active  ="disabled";
                                }else if($stage_1->status=="Declined"){
                                    $dec_select ="selected";
                                    $dec_active = $with_active = $rei_active  = $log_active = "";
                                    $pro_select = $app_select = $log_select = $with_select = $rei_select= "";
                                    $app_active = $pro_active  ="disabled";
                                }else if($stage_1->status=="Withdrawn"){
                                    $with_select ="selected";
                                    $dec_active = $with_active = $rei_active  = $log_active = "";
                                    $pro_select = $app_select = $dec_select = $log_select = $rei_select= "";
                                   $app_active = $pro_active  ="disabled";
                                }else if($stage_1->status=="Reinstate"){
                                    $rei_select ="selected";
                                    $dec_active = $with_active = $rei_active  = $log_active = "";
                                    $pro_select = $app_select = $dec_select = $with_select = $log_select= "";
                                     $app_active = $pro_active  ="disabled";
                                }
                                $check .= 'disabled';

                                ?>
                                <td class="w-25">
                                    <select required class="form-select mb-3 stg_1_status_select" aria-label="Default select example" name="status" id="stage_1_status_drop" onchange="change_status(this.value)">
                                        <option disabled>Select</option>
                                        <option id="lodged" value="Lodged" <?=$log_active.$log_select?> >Lodged</option>
                                        <option id="in_progress" value="In Progress" <?=$pro_active.$pro_select?> >In Progress</option>
                                        <option id="approved" value="Approved" <?=$app_active.$app_select?>>Approved</option>
                                        <option id="declined" value="Declined" <?=$dec_active.$dec_select?>>Declined</option>
                                        <option id="Withdrawn" value="Withdrawn" <?=$with_active.$with_select?>>Withdrawn</option>
                                        <option id="Reinstate" value="Reinstate" <?=$rei_active.$rei_select?>>Reinstate</option>
                                    </select>
                                    <input type="hidden" name="pointer_id" value="<?= $stage_1->pointer_id ?>"> 
                                    <input type="hidden" name="user_id" value="<?= $user_id ?>"> 
                                    <input type="hidden" name="stage_1_id" value="<?= $stage_1->id ?>"> 
                                    
                                </td>  
                            </tr>
                            <tr id="reason_tr" style="display: none;">
                                <td> Reason :</td>
                                <td class="w-20">
                                    <div style="display: flex;" class="position-relative">
                                        <textarea class="form-control" 
                                        <?php
                                            if ($stage_1->status == 'Declined' ) {
                                                echo "readonly";
                                            }else{
                                                echo 'required="not-required"';
                                            }
                                        ?> id="reason_input" name="reason" rows="3"><?php
                                        if($stage_1->status == 'Declined'){
                                            
                                            echo $stage_1->declined_reason;
                                        // }else if($stage_1->status == "Lodged"){
                                        //     echo $stage_1->lodged_comment;
                                        }
                                        // An invalid form control with name='reason' is not focusable. <textarea class=​"form-control" id=​"reason_input" name=​"reason" rows=​"3" required=​"required">​</textarea>​?> </textarea>

                                        <a href="javascript:void(0)" id="stage_1_hide_show_btn_reson" style="vertical-align: bottom;" class="btn btn-sm btn_yellow_green position-absolute bottom-0 end-0" onclick="readonlyInput('#reason_input')">
                                                                    <i class="bi bi-pencil-square"></i> </i></a>
                                    </div>
                                </td>
                            </tr>
                            <tr id="headoffice_no" style="display: none;">
                                <td>Head Office Unique Number</td>
                                <td class="w-25">
                                    <div class="row">
                                        <div class="col-6">
                                            <input type="text"  <?php if($stage_1->status == "Approved"){
                                                echo "readonly";
                                                ?> style="background-color: #e9ecef;"<?php  
                                            } ?> name="unique_id" id="ho_input" class="form-control" value="<?=$stage_1->unique_id?>" 
                                            maxlength="20">
                                        </div>
                                        <div class="col-4 bbg-info my-auto">
                                            <a id="stage_1_hide_show_btn" href="javascript:void(0)" class="btn btn-sm btn_yellow_green" onclick="readonlyInput('#ho_input','<?=$stage_1->unique_id?>')"><i class="bi bi-pencil-square"></i></a>
                                        </div>
                                    </div>
                                     
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" class="text-center">
                                    <button type="submit" class="btn btn_green_yellow">Update</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>

