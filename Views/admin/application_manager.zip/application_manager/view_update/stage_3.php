<div class="accordion" id="flip-view_stage_3">
    <div class="accordion-item">
        <h2 class="accordion-header" id="flush-headingOne">
            <button class="accordion-button collapsed text-green text-center" type="button" data-bs-toggle="collapse" data-bs-target="#stage_3" aria-expanded="false" aria-controls="stage_3" style="color:#012970;">
                Stage 3 - Technical Interview
            </button>
        </h2>

        <div id="stage_3" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#flip-view_stage_3">
            <div class="accordion-body">
                <form action="" id="stage_3_change_status" method="post">
                    <table class="table table-striped border table-hover"> 
                        <tr>
                            <td width="30%">Current Status</td>
                            <td class="w-25"><?= $stage_3->status ?></td>
                        </tr>
                        <tr> 
                            <td>Submitted Date</td>
                            <td class="w-25"><?= date('d/m/Y  H:i:s',strtotime($stage_3->submitted_date))  ?></td>
                        </tr>
                        <?php if ($stage_3->lodged_date !="0000-00-00 00:00:00" || $stage_3->lodged_date != null) { ?>
                            <tr>
                                <td>Lodged Date</td>
                                <td class="w-25">
                                    <?php echo ($stage_3->lodged_date) ? date('d/m/Y  H:i:s',strtotime($stage_3->lodged_date)) : '' ; ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_3->status == 'Approved') { ?>
                            <tr>
                                <td>Approved Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->approved_date)); ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_3->status == 'Expired') { ?>
                            <tr>
                                <td style="width: 30%;">Approved Date</td>
                                <td>
                                    <?= date('d/m/Y  H:i:s',strtotime($stage_3->approved_date)); ?>
                                </td>
                            </tr>
                            <tr>
                            <div class="accordion" id="flip-view_stage_3">
    <div class="accordion-item">
        <h2 class="accordion-header" id="flush-headingOne">
            <button class="accordion-button collapsed text-green text-center" type="button" data-bs-toggle="collapse" data-bs-target="#stage_3" aria-expanded="false" aria-controls="stage_3" style="color:#012970;">
                Stage 3 - Technical Interview
            </button>
        </h2>

        <div id="stage_3" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#flip-view_stage_3">
            <div class="accordion-body">
                <form action="" id="stage_3_change_status" method="post">
                    <table class="table table-striped border table-hover"> 
                        <tr>
                            <td width="30%">Current Status</td>
                            <td class="w-25"><?= $stage_3->status ?></td>
                        </tr>
                        <tr> 
                            <td>Submitted Date</td>
                            <td class="w-25"><?= date('d/m/Y  H:i:s',strtotime($stage_3->submitted_date))  ?></td>
                        </tr>
                        <?php if ($stage_3->lodged_date !="0000-00-00 00:00:00" || $stage_3->lodged_date != null) { ?>
                            <tr>
                                <td>Lodged Date</td>
                                <td class="w-25">
                                    <?php echo ($stage_3->lodged_date) ? date('d/m/Y  H:i:s',strtotime($stage_3->lodged_date)) : '' ; ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_3->status == 'Approved') { ?>
                            <tr>
                                <td>Approved Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->approved_date)); ?>
                                </td>
                            </tr>
                        <?php } 
                        if ($stage_3->status == 'Expired') { ?>
                            <tr>
                                <td style="width: 30%;">Approved Date</td>
                                <td>
                                    <?= date('d/m/Y  H:i:s',strtotime($stage_3->approved_date)); ?>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 30%;">Expired Date</td>
                                <td>
                                    
                                </td>
                            </tr>
                        <?php  } 
                        if ($stage_3->status == 'Declined') { ?>
                            <tr>
                                <td>Declined Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->declined_date)); ?>
                                </td>
                            </tr>
                        <?php }
                        if ($stage_3->status == 'Withdrawn') { ?>
                            <tr>
                                <td>Withdrawn Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->withdraw_date)) ; ?>
                                </td>
                            </tr>
                        <?php } ?>
                        <tr>
                            <td>Change Status</td>
                            <?php 
                            $check = '';
                            if($stage_3->status=="Submitted"){
                                $log_active_3 = $pro_active_3 ="";
                                $log_select_3 = $pro_select_3 = $app_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                 $app_active_3 = $dec_active_3 = $with_active_3 = $sch_active_3 = $con_active_3 ="disabled";
                            }else if($stage_3->status=="Lodged"){
                                $log_select_3 ="selected";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                $log_active_3 = $app_active_3 = $dec_active_3 = $with_active_3 = $sch_active_3 = $con_active_3 =  $pro_active_3 = "disabled";
                            }else if($stage_3->status=="In Progress"){
                                $log_select_3 ="selected";
                                $pro_select_3 =  $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3=  $app_select_3="";
                                $pro_active_3 = $log_active_3 = $app_active_3  = $sch_active_3 = $con_active_3 =  $dec_active_3 = $with_active_3 = "disabled";
                            }else if($stage_3->status=="Scheduled"){
                                $sch_select_3 ="selected";
                                $dec_active_3 = $with_active_3="";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $log_select_3 = $sch_active_3 = $con_select_3 = $with_select_3= "";
                                $log_active_3 = $app_active_3  = $pro_active_3 = $con_active_3 =  $dec_active_3 = $with_active_3 =  "disabled";
                            }else if($stage_3->status=="Conducted"){
                                $app_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = $con_active_3 = $app_active_3 = "";
                                $pro_select_3 = $dec_select_3 = $log_select_3 = $sch_active_3 = $with_select_3 = $sch_select_3 = "";
                                $log_active_3 =  $pro_active_3 = $sch_select_3  = $con_select_3="disabled";
                            }else if($stage_3->status=="Approved"){
                                $app_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = "";
                                $pro_select_3 = $log_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                $log_active_3 = $app_active_3 = $pro_active_3  = $sch_active_3 =$con_active_3 = "disabled";
                            }else if($stage_3->status=="Declined"){
                                $dec_select_3 ="selected";
                                $dec_active_3 = $with_active_3 =  $log_active_3 ="";
                                $pro_select_3 = $app_select_3 = $log_select_3 = $with_select_3 = $sch_select_3 = $con_select_3=  "";
                                $pro_active_3  = $sch_active_3 = $con_active_3 =$app_active_3 =  "disabled";
                            }else if($stage_3->status=="Withdrawn"){
                                $with_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = $log_active_3 = "";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $log_select_3 = $sch_select_3 = $con_select_3= "";
                                $con_active_3 = $app_active_3 = $pro_active_3 = $sch_active_3 =  "disabled";
                            }
                            $check .= 'disabled';

                            ?>
                            <td class="w-25">
                                <select required class="form-select mb-3 stg_3_status_select" aria-label="Default select example" name="status" id="stage_3_status_drop" onchange="change_status_3(this.value)">
                                    <option disabled>Select</option>
                                    <option id="lodged_3" value="Lodged" <?=$log_active_3.$log_select_3?> >Lodged</option>
                                    <option id="in_progress_3" value="In Progress" <?=$pro_active_3.$pro_select_3?> >In Progress</option>
                                    <option id="scheduled_3" value="Scheduled" <?=$sch_active_3.$sch_select_3?>>Scheduled</option>
                                    <option id="conducted_3" value="Conducted" <?=$con_active_3.$con_select_3?>>Conducted</option>
                                    <option id="approved_3" value="Approved" <?=$app_active_3.$app_select_3?>>Approved</option>
                                    <option id="declined_3" value="Declined" <?=$dec_active_3.$dec_select_3?>>Declined</option>
                                    <option id="Withdrawn_3" value="Withdrawn" <?=$with_active_3.$with_select_3?>>Withdrawn</option>
                                </select>
                                <input type="hidden" name="pointer_id" value="<?= $stage_3->pointer_id ?>"> 
                                <input type="hidden" name="user_id" value="<?= $user_id ?>"> 
                                <input type="hidden" name="stage_3_id" value="<?= $stage_3->id ?>"> 
                                
                            </td>
                        </tr>
                        
                        <tr id="reason_tr_3" style="display: none;">
                            <td> Reason :</td>
                            <td class="w-20">
                                <div style="display: flex;" class="position-relative">
                                    <textarea class="form-control" 
                                    <?php
                                        if ($stage_3->status == 'Declined' ) {
                                            echo "readonly";
                                        }
                                    ?> id="reason_input_3" name="reason" rows="3"><?php
                                    if($stage_3->status == 'Declined'){
                                        echo $stage_3->declined_reason;
                                    } ?> </textarea>

                                    <a href="javascript:void(0)" id="stage_3_hide_show_btn_reson" style="vertical-align: bottom;" class="btn btn-sm btn_yellow_green position-absolute bottom-0 end-0" onclick="readonlyInput('#reason_input_3')">
                                        <i class="bi bi-pencil-square"></i> </i></a>
                                </div>
                            </td>
                        </tr>
                        <tr>
                        <td colspan="2" class="text-center">
                                <button type="submit" class="btn btn_green_yellow">Update</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>

<td style="width: 30%;">Expired Date</td>
                                <td>
                                    
                                </td>
                            </tr>
                        <?php  } 
                        if ($stage_3->status == 'Declined') { ?>
                            <tr>
                                <td>Declined Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->declined_date)); ?>
                                </td>
                            </tr>
                        <?php }
                        if ($stage_3->status == 'Withdrawn') { ?>
                            <tr>
                                <td>Withdrawn Date</td>
                                <td class="w-25">
                                    <?php echo date('d/m/Y  H:i:s',strtotime($stage_3->withdraw_date)) ; ?>
                                </td>
                            </tr>
                        <?php } ?>
                        <tr>
                            <td>Change Status</td>
                            <?php 
                            $check = '';
                            if($stage_3->status=="Submitted"){
                                $log_active_3 = $pro_active_3 ="";
                                $log_select_3 = $pro_select_3 = $app_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                 $app_active_3 = $dec_active_3 = $with_active_3 = $sch_active_3 = $con_active_3 ="disabled";
                            }else if($stage_3->status=="Lodged"){
                                $log_select_3 ="selected";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                $log_active_3 = $app_active_3 = $dec_active_3 = $with_active_3 = $sch_active_3 = $con_active_3 =  $pro_active_3 = "disabled";
                            }else if($stage_3->status=="In Progress"){
                                $log_select_3 ="selected";
                                $pro_select_3 =  $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3=  $app_select_3="";
                                $pro_active_3 = $log_active_3 = $app_active_3  = $sch_active_3 = $con_active_3 =  $dec_active_3 = $with_active_3 = "disabled";
                            }else if($stage_3->status=="Scheduled"){
                                $sch_select_3 ="selected";
                                $dec_active_3 = $with_active_3="";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $log_select_3 = $sch_active_3 = $con_select_3 = $with_select_3= "";
                                $log_active_3 = $app_active_3  = $pro_active_3 = $con_active_3 =  $dec_active_3 = $with_active_3 =  "disabled";
                            }else if($stage_3->status=="Conducted"){
                                $app_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = $con_active_3 = $app_active_3 = "";
                                $pro_select_3 = $dec_select_3 = $log_select_3 = $sch_active_3 = $with_select_3 = $sch_select_3 = "";
                                $log_active_3 =  $pro_active_3 = $sch_select_3  = $con_select_3="disabled";
                            }else if($stage_3->status=="Approved"){
                                $app_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = "";
                                $pro_select_3 = $log_select_3 = $dec_select_3 = $with_select_3 = $sch_select_3 = $con_select_3= "";
                                $log_active_3 = $app_active_3 = $pro_active_3  = $sch_active_3 =$con_active_3 = "disabled";
                            }else if($stage_3->status=="Declined"){
                                $dec_select_3 ="selected";
                                $dec_active_3 = $with_active_3 =  $log_active_3 ="";
                                $pro_select_3 = $app_select_3 = $log_select_3 = $with_select_3 = $sch_select_3 = $con_select_3=  "";
                                $pro_active_3  = $sch_active_3 = $con_active_3 =$app_active_3 =  "disabled";
                            }else if($stage_3->status=="Withdrawn"){
                                $with_select_3 ="selected";
                                $dec_active_3 = $with_active_3 = $log_active_3 = "";
                                $pro_select_3 = $app_select_3 = $dec_select_3 = $log_select_3 = $sch_select_3 = $con_select_3= "";
                                $con_active_3 = $app_active_3 = $pro_active_3 = $sch_active_3 =  "disabled";
                            }
                            $check .= 'disabled';

                            ?>
                            <td class="w-25">
                                <select required class="form-select mb-3 stg_3_status_select" aria-label="Default select example" name="status" id="stage_3_status_drop" onchange="change_status_3(this.value)">
                                    <option disabled>Select</option>
                                    <option id="lodged_3" value="Lodged" <?=$log_active_3.$log_select_3?> >Lodged</option>
                                    <option id="in_progress_3" value="In Progress" <?=$pro_active_3.$pro_select_3?> >In Progress</option>
                                    <option id="scheduled_3" value="Scheduled" <?=$sch_active_3.$sch_select_3?>>Scheduled</option>
                                    <option id="conducted_3" value="Conducted" <?=$con_active_3.$con_select_3?>>Conducted</option>
                                    <option id="approved_3" value="Approved" <?=$app_active_3.$app_select_3?>>Approved</option>
                                    <option id="declined_3" value="Declined" <?=$dec_active_3.$dec_select_3?>>Declined</option>
                                    <option id="Withdrawn_3" value="Withdrawn" <?=$with_active_3.$with_select_3?>>Withdrawn</option>
                                </select>
                                <input type="hidden" name="pointer_id" value="<?= $stage_3->pointer_id ?>"> 
                                <input type="hidden" name="user_id" value="<?= $user_id ?>"> 
                                <input type="hidden" name="stage_3_id" value="<?= $stage_3->id ?>"> 
                                
                            </td>
                        </tr>
                        
                        <tr id="reason_tr_3" style="display: none;">
                            <td> Reason :</td>
                            <td class="w-20">
                                <div style="display: flex;" class="position-relative">
                                    <textarea class="form-control" 
                                    <?php
                                        if ($stage_3->status == 'Declined' ) {
                                            echo "readonly";
                                        }
                                    ?> id="reason_input_3" name="reason" rows="3"><?php
                                    if($stage_3->status == 'Declined'){
                                        echo $stage_3->declined_reason;
                                    } ?> </textarea>

                                    <a href="javascript:void(0)" id="stage_3_hide_show_btn_reson" style="vertical-align: bottom;" class="btn btn-sm btn_yellow_green position-absolute bottom-0 end-0" onclick="readonlyInput('#reason_input_3')">
                                        <i class="bi bi-pencil-square"></i> </i></a>
                                </div>
                            </td>
                        </tr>
                        <tr>
                        <td colspan="2" class="text-center">
                                <button type="submit" class="btn btn_green_yellow">Update</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>

