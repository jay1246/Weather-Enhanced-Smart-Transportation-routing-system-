<?= $this->extend('template/admin_template') ?>
<?= $this->section('main') ?>
<main id="main" class="main">
    <style>
        .flag_img {
            width: 18px;

        }

        .filter_flag {
            height: 40px;
            position: absolute;
            padding-left: 15px;
            padding-right: 15px;
            right: 0;
        }
        table.dataTable thead tr th{
            text-align: center;
        }
    </style>
    <div class="pagetitle">
        <h1 class="text-green">Application Manager</h1>
    </div><!-- End Page Title -->
    <section class="section dashboard mt-5 shadow">
        <div class="row">
            <div class="card shadow">
                <div class="card-body">

                    <div class="table">

                        <!--  Table with stripped rows starts -->
 
                        <table id="staff_table" class="table table-striped datatable" style="text-align: center;">
                            <?php
                            if (session()->get('admin_account_type') == 'admin') {
                            ?>
                                <img id="id_flag_green" style="margin-right: 350px;" class="filter_flag green_flag" src="<?= base_url("public/assets/icon/flag-green.png") ?>">
                                <img id="id_flag_red" style="margin-right: 300px;" class="filter_flag red_flag" src="<?= base_url("public/assets/icon/flag-red.png") ?>">
                            <?php } ?>
                            <thead>
                                <tr>
                                    <th>Sr.No.</th>
                                    <?php if (session()->get('admin_account_type') == 'admin') { ?>
                                        <th class="flag_img_td">Addition Infomation Status</th>
                                    <?php } ?>
                                    <th>Application No.</th>
                                    <th>Applicant Name </th>
                                    <th>D.O.B</th>
                                    <th>Occupation</th>
                                    <th>Current Status</th>
                                    <th>Submitted Date </th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                foreach ($stage_1 as $stage) { ?>
                                    <tr>
                                        <?php
                                        $get_id = find_one_row('application_pointer', 'id', $stage->pointer_id);
                                        // $application_id = $get_id->application_id;
                                        $user_id = $get_id->user_id;
                                        $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $stage->pointer_id);
                                        $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $stage->pointer_id);
                                        ?>
                                        <td><?= $count ?></td>
                                        <?php if (session()->get('admin_account_type') == 'admin') { ?>
                                            <td>
                                                <?php
                                                $additional_info_request = find_one_row('additional_info_request', 'pointer_id', $stage->pointer_id);
                                                if ($additional_info_request != "") {
                                                    if ($additional_info_request->status = "request") {
                                                ?>
                                                        <a href="" data-bs-toggle="modal" data-bs-target="#flag_model<?= $count ?>">
                                                            <img class="flag_img" src="<?= base_url("public/assets/icon/flag-red.png") ?>">
                                                        </a>
                                                    <?php
                                                    } else if ($additional_info_request->status = "uploded") {
                                                    ?>
                                                        <a href="" data-bs-toggle="modal" data-bs-target="#flag_model<?= $count ?>">
                                                            <img class="flag_img" src="<?= base_url("public/assets/icon/flag-green.png") ?>">
                                                        </a>
                                                <?php
                                                    } else if ($additional_info_request->status = "verified") {
                                                        echo "verified";
                                                    }
                                                } else {
                                                    echo "No request";
                                                }
                                                ?>
                                                <!-- model box for flag -->
                                                <div class="modal" id="flag_model<?= $count ?>">
                                                    <div class="modal-dialog  modal-lg">
                                                        <div class="modal-content" style="background-color: white;">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title text-center text-success">Additional Information Requested</h5>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="table">

                                                                    <!--  Table with stripped rows starts -->

                                                                    <table class="table table-striped datatable">
                                                                        <thead>
                                                                            <tr>
                                                                                <th> Sr.No </th>
                                                                                <th> Comments </th>
                                                                                <th> Document Name</th>
                                                                                <th> Status </th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php
                                                                            $sr = 1;
                                                                            $additional_infos = find_multiple_rows('additional_info_request', 'pointer_id', $stage->pointer_id);
                                                                            foreach ($additional_infos as $additional_info) {
                                                                            ?><tr>
                                                                                <td><?= $sr ?></td>
                                                                                <td><?= $additional_info->reason ?></td>

                                                                                <td><?php 
                                                                                    if($additional_info->document_id !=""){
                                                                                        echo  find_one_row('documents', 'id', $additional_info->document_id)->document_name;
                                                                                    } ?></td>

                                                                                <td><?= $additional_info->status ?></td>
                                                                            </tr>
                                                                            <?php
                                                                                $sr++;
                                                                            }
                                                                            ?>
                                                                            
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- model box for flag end -->
                                            </td>
                                        <?php } ?>
                                        <td><?php
                                            if (empty($stage->unique_id)) {
                                                $unique_code = "[#T.B.A]";
                                            } else {
                                                $unique_code = "[#" . $stage->unique_id . "]";
                                            }
                                            echo $unique_code ?>
                                        </td>
                                        <td><?= $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name ?></td>
                                        <td><?= $s1_personal_details->date_of_birth ?></td>
                                        <td><?= find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name ?></td>
                                        <td><?php $stage_index = application_stage_no($stage->pointer_id);
                                            if(create_status_format($stage_index) == 'S2 - Start'){
                                                $stage_status = 'S1 - '.$stage->status;
                                            }else if(create_status_format($stage_index) == 'S3 - Start'){
                                                $stage_status = 'S2 - '.find_one_row('stage_2','pointer_id',$stage->pointer_id)->status;
                                            }else{
                                                $stage_status = create_status_format($stage_index);
                                            }
                                            echo $stage_status;  ?></td>
                                        <td><?php $stage_ = explode(" ",create_status_format($stage_index));
                                        if($stage_[0]=='S1'){
                                            $get_submit_date = $stage->submitted_date;
                                        }else if(create_status_format($stage_index) == 'S2 - Start'){
                                            $get_submit_date =  $stage->submitted_date;
                                        }else if($stage_[0]=='S2'){
                                            $get_submit_date = find_one_row('stage_2','pointer_id',$stage->pointer_id)->submitted_date;
                                        }else if ( create_status_format($stage_index) == 'S3 - Start'){
                                            $get_submit_date = find_one_row('stage_2','pointer_id',$stage->pointer_id)->submitted_date;
                                        }else if($stage_[0]=='S3'){
                                            $get_submit_date = find_one_row('stage_3','pointer_id',$stage->pointer_id)->submitted_date;
                                        }
                                         echo date('d/m/Y  H:i:s',strtotime($get_submit_date)) ?></td>
                                         <td>
                                            <a href="<?= base_url('admin/application_manager/view_application') ?>/<?= $stage->pointer_id ?>/view_edit" class="btn btn-sm btn_yellow_green"> <i class="bi bi-pencil-square"></i></a>
                                        </td>

                                    </tr>

                                <?php
                                    $count++;
                                }  ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>


</main>



<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    $(document).ready(function() {
        $('#staff_table').DataTable();
    });

    $(document).ready(function() {
        $('#flag_table').DataTable();
    });
</script>

<?= $this->endSection() ?>