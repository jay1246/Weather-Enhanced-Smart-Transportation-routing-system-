<div class="accordion" id="document_stage_2">
    <div class="accordion-item">
        <h2 class="accordion-header" id="doc_head_stage_2">
            <button class="accordion-button collapsed  text-green" type="button" data-bs-toggle="collapse" data-bs-target="#doc_stage_2" aria-expanded="false" aria-controls="doc_stage_2">
                <i class="bi bi-folder-fill mx-2"></i> Stage 2 Documents
            </button>
        </h2>

        <div id="doc_stage_2" class="accordion-collapse collapse" aria-labelledby="doc_head_stage_2" data-bs-parent="#document_stage_2">
            <div class="accordion-body">
                <div id="download_div" class="mb-3 text-end">
                    <a onclick="download_zip(<?=$pointer_id?>,'stage_2')" class="btn_green_yellow btn mx-3"> Download All Stage 2 Documents <i class="bi bi-download"></i></a>
                </div>

                <form action="" id="reason_form_stage_2" method="post">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Document Name</th>
                                <th style="width: 150px;text-align: center;">Action</th>
                                <th>Comments</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sr = 1;
                            foreach ($stage_2_add_employees as $stage_2_employee){ ?>
                                <tr>
                                    <td colspan="3" class="text-green" style="background-color: hsl(0, 0%, 80%); font-size: 1.1rem;"><i class="bi bi-briefcase-fill"></i>  <?= $stage_2_employee->company_organisation_name?></td>
                                </tr>                              
                            <?php
                                $stage_2_documents = find_multiple_row_3_field('documents','pointer_id',$pointer_id,'stage','stage_2','employee_id',$stage_2_employee->id);
                                $count = 1;
                                foreach ($stage_2_documents as $s2_document) {  ?>
                                    <!-- All Basic Documents ----------------------------->
                                    <tr>
                                        <td class="w-50">
                                            <a target="_blank" href="<?= base_url() ?>/<?= $s2_document->document_path ?>/<?= $s2_document->document_name ?>"> <?= $s2_document->name  ?> </a>
                                        </td>
                                        <td style="text-align: center;">
                                            <!-- download  -->
                                            <a href="<?= base_url() ?>/<?= $s2_document->document_path  ?>/<?= $s2_document->document_name  ?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>
                                            <?php
                                                $s2_disabled_comment = "";
                                                if (isset($s2_document->name )) {
                                                    if ($s2_document->name  == "Verification Email - Qualification" || $s2_document->name  == "Verification Email - Employment") {
                                                        $s2_disabled_comment = "disabled";
                                                    }
                                                }
                                            ?>
                                            <!-- Delete  -->
                                            <a onclick="delete_document(<?=$s2_document->id?>)" href="" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash-fill"></i>
                                            </a>                          
                                            <!-- comment  -->
                                            <a href="javascript:void(0)" class="btn <?= $s2_disabled_comment ?> btn-sm btn_green_yellow"  id="Dbtn_s2_<?=$sr.$count?>" onclick="show_input_s2('<?=$sr.$count?>')">
                                                <i class="bi bi-chat-left-dots"></i>
                                            </a>
                                            <a href="javascript:void(0)" style="display: none;"  id="Xbtn_s2_<?=$sr.$count?>" class="btn btn_yellow_green btn-sm" onclick="show_input_s2('<?=$sr.$count?>')">
                                                <i class="bi bi-x-lg"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <input type="text" name="reason[]" style="display: none;" onkeyup=check_s2()  id="input_s2_<?=$sr.$count?>" class="form-control s1">
                                            <input type="hidden" name="document_id[]" value="<?= $s2_document->id  ?>">
                                            <input type="hidden" name="pointer_id[]" value="<?= $s2_document->pointer_id ?>">
                                            <input type="hidden" name="stage[]" value="<?= $s2_document->stage ?>">
                                        </td>
                                    </tr>
                                <?php 
                                $count++;
                                } 
                               $sr++;
                            }
                            ?>
                            <!-- Additional Information (if admin want more information) ----------------------->
                            <tr>
                                <td class="w-50">
                                    <b> Additional Information </b>
                                </td>
                                <td style="text-align: center;">
                                    <!-- download  -->
                                    <a herf="" class="btn btn-sm btn_yellow_green disabled" ><i class="bi bi-download"></i></a>
                                    <!-- delete  -->
                                    <a class="btn btn-sm btn-danger disabled"><i class="bi bi-trash-fill"></i></a>
                                    <!-- comment  -->
                                    <a href="javascript:void(0)" class="btn btn-sm btn-sm btn_green_yellow" id="Dbtn_s2_Additional" onclick="show_input_s2('Additional')">
                                        <i class="bi bi-chat-left-dots"></i>
                                    </a>
                                    <a href="javascript:void(0)"  class="btn btn-sm btn_yellow_green" style="display: none;" id="Xbtn_s2_Additional" onclick="show_input_s2('Additional')">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                </td>
                                <td>
                                    <input type="text" id="input_s2_Additional" style="display: none;" onkeyup=check_s2() class="form-control s1" name="request_additional">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <button type="submit" class="btn btn_green_yellow" style="display: none; float:right"  id="s2_doc_sub_btn">Request Additional Info</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>                       
                </form>
                
            </div>
        </div>
    </div>
</div>
