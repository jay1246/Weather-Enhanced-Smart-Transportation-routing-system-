<div class="accordion" id="document_stage_1">
    <div class="accordion-item">
        <h2 class="accordion-header" id="doc_head_stage_1">
            <button class="accordion-button collapsed  text-green" type="button" data-bs-toggle="collapse" data-bs-target="#doc_stage_1" aria-expanded="false" aria-controls="doc_stage_1">
                <i class="bi bi-folder-fill mx-2"></i> Stage 1 Documents
            </button>
        </h2>

        <div id="doc_stage_1" class="accordion-collapse collapse" aria-labelledby="doc_head_stage_1" data-bs-parent="#document_stage_1">
            <div class="accordion-body">
                <div id="download_div" class="mb-3 text-end">
                    <a onclick="download_zip(<?=$pointer_id?>,'stage_1')" class="btn_green_yellow btn mx-3"> Download All Stage 1 Documents <i class="bi bi-download"></i></a>
                </div>
 
                <form action="" id="reason_form_stage_1" method="post">
                    <table class="table table-striped table-bordered">
                        <thead> 
                            <tr>
                                <th>Document Name</th>
                                <th style="width: 150px;text-align: center;">Action</th>
                                <th>Comments</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 1;
                            $verify_email = 0;
                            foreach ($stage_1_documents as $s1_document) {  ?>
                            <!-- All Basic Documents ----------------------------->
                            <tr>
                                <td class="w-50">
                                    <a target="_blank" href="<?= base_url() ?>/<?= $s1_document->document_path ?>/<?= $s1_document->document_name ?>"> <?= $s1_document->name  ?> </a>
                                </td>
                                <td style="text-align: center;">
                                    <!-- download  -->
                                    <a href="<?= base_url() ?>/<?= $s1_document->document_path  ?>/<?= $s1_document->document_name  ?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>
                                    <?php
                                        $s1_disabled_comment = "";
                                        if (isset($s1_document->name )) {
                                            if ($s1_document->name  == "Verification Email - Qualification") {
                                                $s1_disabled_comment = "disabled";
                                                $verify_email = 1;
                                            }
                                        }
                                    ?>
                                    <!-- Delete  -->
                                    <a onclick="delete_document(<?=$s1_document->id?>)" href="" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash-fill"></i>
                                    </a>                          
                                    <!-- comment  -->
                                    <a href="javascript:void(0)" class="btn <?= $s1_disabled_comment ?> btn-sm btn_green_yellow"  id="Dbtn_<?= $count ?>" onclick="show_input('<?= $count ?>')">
                                        <i class="bi bi-chat-left-dots"></i>
                                    </a>
                                    <a href="javascript:void(0)" style="display: none;"  id="Xbtn_<?= $count ?>" class="btn btn_yellow_green btn-sm" onclick="show_input('<?= $count ?>')">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                </td>
                                <td>
                                    <input type="text" name="reason[]" style="display: none;" onkeyup=check()  id="input_<?= $count ?>" class="form-control s1">
                                    <input type="hidden" name="document_id[]" value="<?= $s1_document->id  ?>">
                                    <input type="hidden" name="pointer_id[]" value="<?= $s1_document->pointer_id ?>">
                                    <input type="hidden" name="stage[]" value="<?= $s1_document->stage ?>">
                                </td>
                            </tr>
                            <?php 
                            $count++;
                            }
                            ?>
                            <!-- TRA Application Form ----------------------->
                            <tr>
                                <td>
                                    <a target="_blank" href="<?= base_url().'/public/application/'.$pointer_id.'/stage_1/TRA Application Form.pdf'?>">TRA Application Form </a>
                                </td>
                                <td style="text-align: center;">
                                    <!-- download  -->
                                    <a href="<?= base_url().'/public/application/'.$pointer_id.'/stage_1/TRA Application Form.pdf'?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>
                                    <!-- delete  -->
                                    <a class="btn btn-sm btn-danger disabled"><i class="bi bi-trash-fill"></i></a>
                                    <!-- comment  -->
                                    <a href="" class="btn btn-sm disabled btn_green_yellow"><i class="bi bi-chat-left-dots"></i></a>
                                </td>
                                <td></td>
                            </tr>
                            <!-- Additional Information (if admin want more information) ----------------------->
                            <tr>
                                <td class="w-50">
                                    <b> Additional Information </b>
                                </td>
                                <td style="text-align: center;">
                                    <!-- download  -->
                                    <a herf="" class="btn btn-sm btn_yellow_green disabled" ><i class="bi bi-download"></i></a>
                                    <!-- delete  -->
                                    <a class="btn btn-sm btn-danger disabled"><i class="bi bi-trash-fill"></i></a>
                                    <!-- comment  -->
                                    <a href="javascript:void(0)" class="btn btn-sm btn-sm btn_green_yellow" id="Dbtn_Additional" onclick="show_input('Additional')">
                                        <i class="bi bi-chat-left-dots"></i>
                                    </a>
                                    <a href="javascript:void(0)"  class="btn btn-sm btn_yellow_green" style="display: none;" id="Xbtn_Additional" onclick="show_input('Additional')">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                </td>
                                <td>
                                    <input type="text" id="input_Additional" style="display: none;" onkeyup=check() class="form-control s1" name="request_additional">
                                    <input type="hidden" name="pointer_id[]" value="<?= $pointer_id ?>">
                                    <input type="hidden" name="stage[]" value="stage_1">
                            
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <button type="submit" class="btn btn_green_yellow" style="display: none; float:right"  id="s1_doc_sub_btn">Request Additional Info</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>  
               
                </form>
                <?php
                if($verify_email != 1){
                ?>
                <form  action="" id="verify_email_stage_1" method="post">
                    <h5> Verification Email - Qualification </h5>
                    <div class="row">
                        <div class="col-4">
                        <input name="file" type="file" class="form-control s1">
                        <input name="pointer_id" type="hidden" class="form-control s1" value="<?=$pointer_id?>">
                        </div>
                        <div class="col-2">
                        <button type="submit" class="btn btn_green_yellow">upload</button>
                        </div>
                    </div>
                </form>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
