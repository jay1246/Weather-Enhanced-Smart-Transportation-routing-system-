<?= $this->extend('template/admin_template') ?>
<?= $this->section('main') ?>

<link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
<style>
    .normal_link {
        color: #4154f1 !important;
    }

    .text-color {
        color: black;
        font-size: 18px;
    }

    .text-color:hover {
        color: black;
    }

    .tab {
        font-size: 18px !important;
        text-decoration: none;

    }

    .tab:hover {
        color: #055837;
        text-decoration: none;

    }

    .accordion-button {
        font-size: 16px;


    }

    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        background-color: var(--yellow);
        color: var(--green);
    }

    #cover-spin {
        position: fixed;
        width: 100%;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background-color: rgba(251, 251, 251, 0.6);
        z-index: 9999;
        display: none;
    }

    #loader_img {
        position: fixed;
        left: 50%;
        top: 50%;
    }

    .form-control:disabled,
    .form-control[readonly] {
        background-color: #e9ecef;

    }

    tbody,
    td,
    tfoot,
    th,
    thead,
    tr {
        border-color: inherit;
        border-style: solid;
    }

    select :disabled {
        /* color: #f59595 !important; */
        background-color: #f2f2f3 !important;
    }

    /* .sidebar {
        height: 2500px !important;
    } */
</style>
<main id="main" class="main w-100">
    <!-- style="height: 4000px;" -->
    <div class="pagetitle">
        <h4 class="text-green mt-3" style="font-size:24px">View / Update </h4>
        <b>
            <snap class="mt-2" style="font-size:16px"><?php

                                                        echo $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name . " ";
                                                        if (empty($stage_1->unique_id)) {
                                                            $unique_code = "[#T.B.A] - ";
                                                        } else {
                                                            $unique_code = " [#" . $stage_1->unique_id . "] - ";
                                                        }
                                                        echo $unique_code;
                                                        echo $s1_contact_details->state_proviance . ", ";
                                                        echo $s1_contact_details->country;
                                                        ?>


            </snap>
            <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                <br>


                <snap class="mt-1">
                    <?php
                    $mobile_code = find_one_row('country', 'id', $username->mobile_code);
                    echo  $username->name . " " . $username->middle_name . " " . $username->last_name . " - " . $username->business_name . " (+" . country_phonecode($username->mobile_code) . " " . $username->mobile_no . ")";
                    $info_name =  $username->name;
                    $info_middle_name =  " " . $username->middle_name;
                    $info_last_name =  " " . $username->last_name;
                    if (!empty($username->business_name)) {
                        $info_business_name =  " - " . $username->business_name;
                    } else {
                        $info_business_name = "";
                    }
                    $info_mobile = " (+" . country_phonecode($username->mobile_code) . " " . $username->mobile_no . ")";
                    // echo $info_name . $info_middle_name . $info_last_name . $info_business_name;
                    ?>
                    <a href="<?= base_url('application_transfer/' . $pointer_id) ?>" title="Application Transfer." class="btn_green_yellow btn btn-sm p-0" style="font-size: 70%; padding-left: 3px !important; padding-right: 3px !important;">
                        <i class="bi bi-pencil-square"></i>
                    </a>

                </snap>
            <?php } ?>

        </b>
    </div><!-- End Page Title -->

    <section class="section dashboard mt-3 shadow">
        <div class="card card-primary card-outline card-tabs">
            <div class="card-header p-0 pt-1 border-bottom-0">
                <?php
                if ($tab == "view_edit") {
                    $view_tab = "active";
                    $document_tab = "";
                    $btn_view = "btn_yellow_green";
                    $btn_doc = "";
                } else {
                    $view_tab = "";
                    $document_tab = "active";
                    $btn_view = "";
                    $btn_doc = "btn_green_yellow";
                } ?>
                <!-- ---------------tabs--------- -->
                <!-- Bordered Tabs Justified -->
                <ul class="nav nav-pills nav-fill" style="margin-right: 15px;
    margin-left: 15px;
    margin-top: 20px;">
                    <li class="nav-item">
                        <a class="nav-link text-center tab shadow-sm text-color <?= $view_tab ?>" id="tabs_view_edit" href="<?= base_url("admin/application_manager/view_application/" . $pointer_id . "/view_edit") ?>" role="tab" aria-controls="tabs_view_edit" aria-selected="true">View / Update</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  shadow-sm text-center tab text-color <?= $document_tab ?>" id="tabs_documents" href="<?= base_url("admin/application_manager/view_application/" . $pointer_id . "/all_documents") ?>" role="tab" aria-controls="tabs_documents" aria-selected="false">Submitted Documents</a>
                    </li>
                </ul>

            </div>
            <div class="tab-content">

                <!-- ------------view_edit tab starts--------- -->

                <div class="tab-pane fade show <?= $view_tab ?>" id="view_view_edit" role="tabpanel" aria-labelledby="tabs_view_edit">
                    <!-- Table with stripped rows -->
                    <div class="card-body">
                        <!--  -------------------Stage 1 - Self Assessment ---------------- -->
                        <?php
                        echo $this->include("admin/application_manager/view_update/applicant_data.php");
                        ?>
                        <!--  -------------------End stage 1 self assesment ---------------- -->

                        <!--  -------------------Stage 1 - Self Assessment ---------------- -->
                        <?php if ($stage_1 != "") {
                            echo $this->include("admin/application_manager/view_update/stage_1.php");
                        } ?>
                        <!--  -------------------End stage 1 self assesment ---------------- -->
                        <!-- -------------------Stage 2 - Documentary Evidence ---------------- -->
                        <?php
                        if ($stage_2 != "") {
                            if (!empty($stage_2->status) and $stage_2->status != 'Start') {
                                echo $this->include("admin/application_manager/view_update/stage_2.php");
                            }
                        } ?>
                        <!--  -------------------End stage 2 Documentary Evidence ---------------- -->
                        <!-- -------------------Stage 3 - Documentary Evidence ---------------- -->
                        <?php
                        if ($stage_3 != "") {
                            if (!empty($stage_3->status) and $stage_3->status != 'Start') {
                                echo $this->include("admin/application_manager/view_update/stage_3.php");
                            }
                        } ?>
                        <!--  -------------------End stage 3 Documentary Evidence ---------------- -->
                        
                           <!-- -------------------Stage 4 - Documentary Evidence ---------------- -->
                         <?php
                         if (!empty($stage_4)) {
                                  $pathway=$s1_occupation->pathway;
                                if($pathway=="Pathway 1"){
                                    if($s1_occupation->occupation_id==7||$s1_occupation->occupation_id==18){
                              
                                                              echo $this->include("admin/application_manager/view_update/stage_4.php");
                                    }
                                }
                         }
                        // if ($stage_4 != "") {
                        //     if (!empty($stage_4->status)) {
                        //         $occupation= find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name;
                        //         $pathway=$s1_occupation->pathway;
                        //         if($pathway=="Pathway"){
                        //             if($occupation=="Electrician (General)"||$occupation=="Plumber (General)"){
                        //              echo $this->include("admin/application_manager/view_update/stage_4.phpdd

                        //             }
                                    
                        //         }
                        //     }
                        // } 
                        ?>
                           <!-- ------------------- end Stage 4 - Documentary Evidence ---------------- -->
                       
                    </div>
                </div>
                <!-- ------view_edit tab ends------ -->

                <!-- ------documents tab starts------ -->

                <div class="tab-pane fade  show <?= $document_tab ?>" id="view_documents" role="tabpanel" aria-labelledby="tabs_documents">

                    <div class="card-body">

                        <?php if (session()->has('zip_error')) { ?>
                            <br>
                            <div class="alert alert-danger alert-dismissible fade show mt-5 mb-3" role="alert" id="alert">
                                <p class="text-center"><?= session()->get('zip_error') ?></p>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php } ?>

                        <!-- ------------------stage 1 documents --------- -->
                        <?php if ($stage_1 != "") {
                            if (!empty($stage_1->status)) {
                                if ($stage_1->status != "Start") {
                                    echo $this->include("admin/application_manager/document/stage_1.php");
                                }
                            }
                        } ?>
                        <!-- ------------------stage 1 documents end --------- -->
                        <!-- ------------------stage 2 documents --------- -->
                        <?php if ($stage_2 != "") {
                            if (!empty($stage_2->status)) {
                                if ($stage_2->status != "Start") {
                                            echo $this->include("admin/application_manager/document/stage_2.php");
                                      
                                }
                            }
                        } ?>
                        <!-- ------------------stage 2 documents end --------- -->
                        <!-- ------------------stage 3 documents --------- -->
                        <?php
                        if ($stage_3 != "") {
                            if (!empty($stage_3->status)) {
                                if ($stage_3->status != "Start") {
                                    // echo $stage_3->status;
                                    // exit;
                                    echo $this->include("admin/application_manager/document/stage_3.php");
                                }
                            }
                        } ?>
                        <!-- ------------------stage 3 documents end --------- -->

                            <!-- ------------------stage 4 documents --------- -->
                        <?php
                         if (!empty($stage_4)) {
                                  $pathway=$s1_occupation->pathway;
                                if($pathway=="Pathway 1"){
                                    if($s1_occupation->occupation_id==7||$s1_occupation->occupation_id==18){
                                    echo $this->include("admin/application_manager/document/stage_4.php");
                                    }
                                }
                         }
                    
                        ?>
                        <!-- ------------------stage 4 documents end --------- -->


                    </div>
                </div>

            </div>
        </div>
    </section>
    <div id="cover-spin">
        <div id="loader_img">
            <img src="<?= base_url("public/assets/image/admin/loader.gif") ?>" style="width: 100px; height:auto">
        </div>
    </div>
</main>


<?= $this->endSection() ?>
<?= $this->section('custom_script') ?>
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>

<!--stg_2_status_select-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<!--stg_1_status_select-->
<script>
 $( document ).ready(function() {


    var location=$('#preference_location').val();
    var real_location=$('#original_location').val();
    if(location == real_location){
           $('#stage_3_prefered_location_edit').hide();

    }else{
         // $('#stage_3_prefered_location_edit').show();
    }

    if(location=="Online (Via Zoom)"){
        $('.online_docs').show();
    }
    else{
        $('.online_docs').hide();
    }

});
    var pointer_id = <?= $pointer_id ?>;
    var tab = '<?= $tab ?>';

    // view updata ------------------------------  
    <?php
    if (isset($stage_1->unique_id) && !empty($stage_1->unique_id)) {
    ?>
        var read = false;
    <?php
    } else {
    ?>
        var read = true;
    <?php
    }
    ?>
    const readonlyInput = (element) => {
        console.log(read + "________________");
        if (read != "") {
            console.log('gngj');
            $(element).attr("readonly", "true");
            read = false;
            if (element == "#unique_no_stage_1") {
                update_unique_no_stage_1()
                $("#stage_1_hide_show_btn").html("<i class='bi bi-pencil-square'></i>");
            }
        } else {
            console.log('gj');
            $(element).removeAttr("readonly");
            read = true;
            if (element == "#unique_no_stage_1") {
                $("#stage_1_hide_show_btn").html("<i class='bi bi-check-circle'title='Save'></i>");
            }
        }
    }

    // view updata->stage 1 ----------------------------
    var status = '<?= $stage_1->status ?>';
    if (status == "Declined") {
        $("#reason_tr").show();
    } else {
        $("#reason_tr").hide();
    }


    if (status == "Submitted") {
        $("#headoffice_no").hide();
        $("#allocate_team_member").hide();

    } else {
        $("#headoffice_no").show();
        $("#allocate_team_member").show();
    }


    // if (status == "Lodged" || status == "Submitted") {
    //     $("#headoffice_no").hide();
    //     $("#allocate_team_member").hide();

    // } else {
    //     $("#headoffice_no").show();
    //     $("#allocate_team_member").show();
    // }




    $("#reason_input").removeAttr("required");
    const change_status = (val) => {
        console.log(val);
        if (val == "Declined") {
            $("#reason_input").attr("required", "true");
            $("#reason_tr").show();
        } else {
            $("#reason_input").removeAttr("required");
            $("#reason_tr").hide();
            $("#reason_input").removeAttr("required");
        }

        if (val == "Lodged" || val == "In Progress") {
            $("#unique_no_stage_1").attr("required", "true");
            $("#headoffice_no").show();
            $("#allocate_team_member").show();

        } else {
            $("#unique_no_stage_1").removeAttr("required");
        }
        if (val == "Start" || val == "Submitted") {
            $("#unique_no_stage_1").removeAttr("required");
            $("#headoffice_no").hide();
            $("#allocate_team_member").hide();
        }

        // if (val == "In Progress") {
        //     $("#unique_no_stage_1").attr("required", "true");
        //     $("#headoffice_no").show();
        //     $("#allocate_team_member").show();

        // } else {
        //     $("#unique_no_stage_1").removeAttr("required");
        //     $("#headoffice_no").hide();
        //     $("#allocate_team_member").hide();

        // }
    }
    // change unique no (head office no) stage 1 ----------------------------
    function update_unique_no_stage_1() {

        // Assigned Team Member
        var selectElement = document.getElementById("allocate_team_member_select_id");
        var Assigned_Team_Member_id = selectElement.value;

        // ATTC_Ticket_No
        var unique_head_office_no = $("#unique_no_stage_1").val();

        if (Assigned_Team_Member_id == "") {
            custom_alert_popup_show(header = '', body_msg = "Select Assigned Team Member", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_1_pop_btn');
            return;
        }
        if (unique_head_office_no == "") {
            custom_alert_popup_show(header = '', body_msg = "Enter ATTC Ticket No.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_1_pop_btn');
            return;
        }


        console.log(unique_head_office_no);
        // return;
        $.post("<?= base_url("admin/application_manager/update_unique_no/stage_1") ?>", {
            pointer_id,
            unique_head_office_no,
            Assigned_Team_Member_id,
        }, function(data) {
            // let data = JSON.parse(data);
            // location.reload();
            // console.log(data.msg);
            console.log(JSON.parse(data).msg);
        });
    }
    // change status stage 1 ----------------------------
    $("#stage_1_change_status").submit(function(e) {
       // alert("sads");
        //return;
        
        e.preventDefault();
        var selectedValue;
        var selete_status;
        var status__now = '<?= $stage_1->status ?>';
        selectedValue = (status__now == "Submitted") ? "1" : "";
        // console.log(status__now);
        // return;
        if (selectedValue === "") {
            var selectElement = document.getElementById("allocate_team_member_select_id");
            if (selectElement) {
                var selectedValue = selectElement.value;
            }
        }
        var status_element = document.getElementById("stage_1_status_drop");
        if (status_element) {
            var selete_status = status_element.value;
        }
    
        console.log(selete_status);
        if (selectedValue !== "") {
            if (selete_status != "Select Status"){
                custom_alert_popup_show(header = '', body_msg = "Are you sure you want to change status?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_1_pop_btn');
                // check Btn click
                $("#stage_1_pop_btn").click(function() {
                    // if return true 
                    if (custom_alert_popup_close('stage_1_pop_btn')) {
                        // var formData = new FormData($(this)[0]);
                        var formData = new FormData(document.getElementById("stage_1_change_status"));
                        $('#cover-spin').show(0);
                        $.ajax({
                            method: "POST",
                            url: "<?php echo base_url('admin/application_manager/status_change/stage_1'); ?>",
                            data: formData,
                            processData: false,
                            contentType: false,
                            success: function(data) {
                                console.log(data);
                                data = JSON.parse(data);
                                if (data["response"] == true) {
                                    window.location.reload();
                                } else {
                                    alert(data["msg"]);
                                }
                            }
                        });
                    }
                });
            }else{
                custom_alert_popup_show(header = '', body_msg = "Please Select Status", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false);
                return;
           
            }
        } else {
            // alert('Select Assigned Team Member');
            custom_alert_popup_show(header = '', body_msg = "Select Assigned Team Member", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false);
            return;
            // custom_alert_popup_show(header = '', body_msg = "Select allocated", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = false);
        }
    });

    // view updata->stage 1 end ----------------------------
    // view updata->stage 2 ----------------------------
    <?php if ($stage_2 != "") { ?>
        var status_2 = '<?= $stage_2->status ?>';
    <?php } else { ?>
        var status_2 = "";
    <?php } ?>
    if (status_2 == "Declined") {
        // $("#reason_tr_2").show();
        
        $("#reason_tr_1_2").show();
        $("#reason_tr_2_2").show();
        
    } else {
        // $("#reason_tr_2").hide();
        
        $("#reason_tr_1_2").hide();
        $("#reason_tr_2_2").hide();
    
    }
    $("#reason_input_2").removeAttr("required");
    const change_status_2 = (val) => {
        console.log(val);
        if (val == "Declined") {
            // $("#reason_input_2").attr("required", "true");
            // $("#reason_tr_2").show();
            <?php $outcome = 0;
            $statement_resone = 0;
            $outcome_letter = find_one_row_3_field('documents','stage','stage_2','pointer_id',$pointer_id,'required_document_id',51);
            if ($outcome_letter) {
                $outcome = 1;
                }// Outcome Letter
            $statement_of_reasons = find_one_row_3_field('documents','stage','stage_2','pointer_id',$pointer_id,'required_document_id',52);
                 if ($statement_of_reasons) {
                     $statement_resone = 1;
                     } // Outcome Letter
            ?>
            var outcome = <?=$outcome?>;
            var statement_resone = <?=$statement_resone?>;
            $("#reason_tr_1_2").show();
            $("#reason_tr_2_2").show();
            if(outcome==0){
            $("#s2_outcome").attr("required", "true");
            }
            if(statement_resone == 0){
            $("#s2_dec_Statement_of_Reasons").attr("required", "true");
            }
        } else {
            // $("#reason_input_2").removeAttr("required");
            // $("#reason_tr_2").hide();
            
            $("#reason_tr_1_2").hide();
            $("#reason_tr_2_2").hide();
            $("#s2_outcome").removeAttr("required");
            $("#s2_dec_Statement_of_Reasons").removeAttr("required");

        }
    }
       
    // change status stage 2 ----------------------------
    
    $("#stage_2_change_status").submit(function(e) {
    e.preventDefault();
    var selete_status ="";   
    var status_element = document.getElementById("stage_2_status_drop");
    if (status_element) {
        var selete_status = status_element.value;
    }
        if (selete_status != "Select Status"){

            custom_alert_popup_show(header = '', body_msg = "Are you sure you want to change status?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_2_pop_btn');
            // check Btn click
            $("#stage_2_pop_btn").click(function() {
                // if return true 
                if (custom_alert_popup_close('stage_2_pop_btn')) {
                    var formData = new FormData(document.getElementById("stage_2_change_status"));
                    $('#cover-spin').show(0);
                    $.ajax({
                        method: "POST",
                        url: "<?= base_url("admin/application_manager/status_change/stage_2") ?>",
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(data) {
                            data = JSON.parse(data);
                            if (data["response"] == true) {
                                window.location.reload();
                            } else {
                                alert(data["msg"]);
                            }
                        }
                    });
                }
            })
        }else{
            custom_alert_popup_show(header = '', body_msg = "Please Select Status", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false);
            // window.location.reload();

            // return;
           
            }
        
    }); // view updata->stage 2 end ----------------------------
    // view updata->stage 3 ----------------------------

    var pathway ="<?= $s1_occupation->pathway ?>";
    var ocupation_id = "<?=$s1_occupation->occupation_id?>"
    <?php if (!empty($stage_3)) { ?>
        var status_3 = '<?= $stage_3->status ?>';
    <?php } else { ?>
        var status_3 = "";
    <?php } ?>
    console.log(pathway);
    if (status_3 == "Declined") {
        $("#reason_tr_1_3").show();
        $("#reason_tr_2_3").show();
    } else {
        $("#reason_tr_1_3").hide();
        $("#reason_tr_2_3").hide();
    }
    
    if (status_3 == "Approved") {
        console.log(pathway);
            console.log(ocupation_id);
        if(ocupation_id == 7 || ocupation_id == 18 && pathway =='Pathway 1'){
            console.log("condition 1");
        }else{   
            console.log('condition 2');
            $("#appr_tr_1_3").show();
            $("#appr_path").attr("required", "true");
            if(pathway =='Pathway 1'){
                console.log('condition 3');
                $("#appr_path_1").attr("required", "true");  
                $("#appr_tr_2_3").show();
            }
        }
    }else{
        $("#appr_path").removeAttr("required");
        $("#appr_path_1").removeAttr("required");  
        $("#appr_tr_1_3").hide();
        $("#appr_tr_2_3").hide();
    }
    const change_status_3 = (val) => {
        console.log(val);
        // 3 july 2023
        <?php 
    // approved
    $appr_path_1 = 0;
    $appr_path = 0;
    $outcome_letter_3 = find_one_row_3_field('documents','stage','stage_3','pointer_id',$pointer_id,'required_document_id',26);
    if ($outcome_letter_3) {
        $appr_path_1 = 1;
        }
    $qualification_doc_3 = find_one_row_3_field('documents','stage','stage_3','pointer_id',$pointer_id,'required_document_id',25);
    if ($qualification_doc_3) {
         $appr_path = 1;
         } 
    // decline
    $dec_path_1 = 0;
    $dec_path_2 = 0;
    $dec_3_1 = find_one_row_3_field('documents','stage','stage_3','pointer_id',$pointer_id,'required_document_id',23);
    if ($dec_3_1) {
        $dec_path_1 = 1;
        }
    $dec_3_2 = find_one_row_3_field('documents','stage','stage_3','pointer_id',$pointer_id,'required_document_id',24);
    if ($dec_3_2) {
         $dec_path_2 = 1;
         } 
    
    ?>
    var dec_path_1 = <?=$dec_path_1?>;
    var dec_path_2 = <?=$dec_path_2?>;
    var appr_path = <?=$appr_path?>;
    var appr_path_1 = <?=$appr_path_1?>;
   
        if (val == "Declined") {
            $("#reason_tr_1_3").show();
            $("#reason_tr_2_3").show();
            if(dec_path_1 == 0){
            $("#dec_path_1").attr("required", "true");
            }
            if(dec_path_2 == 0){
            $("#dec_path_2").attr("required", "true");
            }
        } else {
            
            $("#dec_path_1").removeAttr("required");
            $("#dec_path_2").removeAttr("required");
            $("#reason_tr_1_3").hide();
            $("#reason_tr_2_3").hide();
        }
        // akanksha 28 june 2023
        if(val == "Approved"){
                console.log(pathway);
                console.log(ocupation_id);
            if(ocupation_id == 7 || ocupation_id == 18 && pathway =='Pathway 1'){
                console.log("condition 1");
            }else{   
                console.log('condition 2');
                $("#appr_tr_1_3").show();
                if(appr_path == 0){
                    $("#appr_path").attr("required", "true");
                }
                if(pathway =='Pathway 1'){
                    console.log('condition 3');
                    if(appr_path_1 == 0){
                    $("#appr_path_1").attr("required", "true");
                    }
                    $("#appr_tr_2_3").show();
                }
            }
        }else{
            $("#appr_path").removeAttr("required");
            $("#appr_path_1").removeAttr("required");  
            $("#appr_tr_1_3").hide();
            $("#appr_tr_2_3").hide();
        }
    }
    //stage 4
            const change_status_4 = (val) => {
        console.log(val);
         <?php 
    // approved
    $appr_path_1 = 0;
    $appr_path = 0;
    $outcome_letter_4 = find_one_row_3_field('documents','stage','stage_4','pointer_id',$pointer_id,'required_document_id',47);
    if ($outcome_letter_4) {
        $appr_path = 1;
        }
    $qualification_doc_4 = find_one_row_3_field('documents','stage','stage_4','pointer_id',$pointer_id,'required_document_id',48);
    if ($qualification_doc_4) {
        //  s4_appr_path_1
        $appr_path_1 = 1;
         } 
    // decline
    $s4_dec_path_1 = 0;
    $s4_dec_path_2 = 0;
    $dec_3_1 = find_one_row_3_field('documents','stage','stage_4','pointer_id',$pointer_id,'required_document_id',45);
    if ($dec_3_1) {
        $s4_dec_path_1 = 1;
        }
    $dec_3_2 = find_one_row_3_field('documents','stage','stage_4','pointer_id',$pointer_id,'required_document_id',46);
    if ($dec_3_2) {
         $s4_dec_path_2 = 1;
         } 
    // s4_dec_path_1
    ?>
    var s4_dec_path_1 = <?=$s4_dec_path_1?>;
    var s4_dec_path_2 = <?=$s4_dec_path_2?>;
    var s4_appr_path = <?=$appr_path?>;
    var s4_appr_path_1 = <?=$appr_path_1?>;
   
                        
        if (val == "Declined") {
            $("#s4_reason_tr_1_4").show();
            $("#s4_reason_tr_2_4").show();
            if(s4_dec_path_1 == 0){
            $("#s4_dec_path_1").attr("required", "true");
            }
            if(s4_dec_path_2 == 0){
            $("#s4_dec_path_2").attr("required", "true");
            }
        } else {
            $("#s4_dec_path_1").removeAttr("required");
            $("#s4_dec_path_2").removeAttr("required");
            $("#s4_reason_tr_1_4").hide();
            $("#s4_reason_tr_2_4").hide();

        }
        // code block
        if (val == "Approved") {
            $("#s4_appr_tr_1_4").show();
            // s4_appr_tr_2_4
            if(s4_appr_path == 0){
            $("#s4_appr_path").attr("required", "true");
            }
            if(s4_appr_path_1 == 0){
            $("#s4_appr_path_1").attr("required", "true");
            }
            $("#s4_appr_tr_2_4").show();
            
        } else {
            $("#s4_appr_path").removeAttr("required");
            $("#s4_appr_path_1").removeAttr("required");
            $("#s4_appr_tr_1_4").hide();
            $("#s4_appr_tr_2_4").hide();
        }
        
        
    }
    // change status stage 3 ----------------------------
    $("#stage_3_change_status").submit(function(e) {
        e.preventDefault();
    var selete_status ="";   
    var status_element = document.getElementById("stage_3_status_drop");
        if (status_element) {
            var selete_status = status_element.value;
        }
        if (selete_status != "Select Status"){

            custom_alert_popup_show(header = '', body_msg = "Are you sure you want to change status?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_3_pop_btn');
            // check Btn click
            $("#stage_3_pop_btn").click(function() {
                // if return true 
                if (custom_alert_popup_close('stage_3_pop_btn')) {
                    $('#cover-spin').show(0);
                	$('#preference_location').attr('disabled',false);
                    var formData = new FormData(document.getElementById("stage_3_change_status"));
                    $.ajax({
                        method: "POST",
                        url: "<?= base_url("admin/application_manager/status_change/stage_3") ?>",
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(data) {
                            // return;
                            $('#cover-spin').hide(0);
                            console.log(data);
                            console.log("-------------------------------- vishal ---------------------------------------------------");
    
                            data = JSON.parse(data);
                            if (data["response"] == true) {
                                window.location.reload();
                            } else {
                                alert(data["msg"]);
                            }
    
                        }
                    });
                    $('#preference_location').attr('disabled',true);
    
                }
            })
        }else{
            custom_alert_popup_show(header = '', body_msg = "Please Select Status", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false);
            return;
           
        }
        
    
    }); // view updata->stage 3 end ----------------------------
    
    
    
    
    
        // change status stage 4 ----------------------------
    $("#stage_4_change_status").submit(function(e) {
        e.preventDefault();
        var selete_status =  $("#stage_4_status_drop").val();
        console.log(selete_status);
        if (selete_status == "Select Status" || selete_status == null){
             custom_alert_popup_show(header = '', body_msg = "Please Select Status", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false);
            return;
        }
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to change status?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_4_pop_btn');
        // check Btn click
        $("#stage_4_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_4_pop_btn')) {
                $('#cover-spin').show(0);
            	$('#s4_preference_location').attr('disabled',false);
                var formData = new FormData(document.getElementById("stage_4_change_status"));
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/status_change/stage_4") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        $('#cover-spin').hide(0);
                        console.log(data);
                        console.log("-------------------------------- vishal ---------------------------------------------------");

                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                        } else {
                            alert(data["msg"]);
                        }

                    }
                });
                $('#s4_preference_location').attr('disabled',true);

            }
        })
    }); 
    
        // view status 4 updata end ------------------------------

    
    
    
    
    
    // view updata end ------------------------------
    // Documnents ------------------------------

    // document->stage 1 ----------------------------
    function show_input(count_id) {
        if ($("#input_" + count_id).css("display") == "none") {
            $("#input_" + count_id).css("display", "block");
            $("#input_" + count_id).focus();
            $("#Dbtn_" + count_id).hide();
            $("#Xbtn_" + count_id).show();
            console.log("ch_3");
            check();
        } else {
            $("#input_" + count_id).val("");
            $("#input_" + count_id).css("display", "none")
            $("#Dbtn_" + count_id).show();
            $("#Xbtn_" + count_id).hide();
            $('#s1_doc_sub_btn').css("display", "block");
            console.log("check");
            check();
        }
    }

    function check() {
        var count_ = 0;
        var value = $('input[type="text"].s1').filter(function() {
            console.log(value);
            if (this.value.length > 0) {
                count_++;
            }
        });
        console.log(count_);
        if (count_ > 0) {
            $('#s1_doc_sub_btn').css("display", "block");
        } else {
            $('#s1_doc_sub_btn').hide();
        }
    }

    // comments function ---------------------------  
    // function reason_form_stage_1(){
    //     //  e.preventDefault();
    //     var formData = document.getElementById("reason_form_stage_1");
    //     console.log(formData);
    //     return;
        
    //     custom_alert_popup_show(header = '', body_msg = "Do you want to send  the additional info request ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_doc_1_pop_btn');
    //     // check Btn click
    //     $("#stage_doc_1_pop_btn").click(function() {
    //                 //  e.preventDefault();
    //         // if return true 
    //         if (custom_alert_popup_close('stage_doc_1_pop_btn')) {
    //     //         var form = document.getElementById("reason_form_stage_1");
        
                // var form = new FormData(document.getElementById("reason_form_stage_1"));
        //   $reasons = $this->request->getPost('reason');
        // $stages = $this->request->getPost('stage');
        // $pointer_ids = $this->request->getPost('pointer_id');
        // $document_ids = $this->request->getPost('document_id');
        // $request_additional = $this->request->getPost("request_additional");
    //       var formData = new FormData();
    // formData.append('file', file);

    // var pointer_id = '<?=$pointer_id?>';
    // formData.append("reason", reason);
    // formData.append("stage", stage);
    // formData.append("pointer_id", pointer_id);
    // formData.append("document_id", document_id);
    // formData.append("request_additional", request_additional);

        // var formData = new FormData(form);
        // var reason = formData.get("reason");
        // var stage = formData.get("stage");
        // var pointer_id = formData.get("pointer_id");
        // var document_id = formData.get("document_id");
        // var request_additional = formData.get("request_additional");
    //             $('#cover-spin').show(0);
    //             $.ajax({
    //                 method: "POST",
    //                 url: "<?= base_url("admin/application_manager/comment_document") ?>",
    //                 data: formData,
    //                 processData: false,
    //                 contentType: false,
    //                 success: function(data) {
    //                     data = JSON.parse(data);
    //                     if (data["response"] == true) {
    //                         window.location.reload();
    //                         // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
    //                     } else {
    //                         alert(data["msg"]);
    //                     }
    //                 }
    //             });
    //         }
    //     })
    // }
    
    $("#reason_form_stage_1").submit(function(e) {
        e.preventDefault();
        custom_alert_popup_show(header = '', body_msg = "Do you want to send  the additional info request ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_doc_1_pop_btn');
        // check Btn click
        $("#stage_doc_1_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_doc_1_pop_btn')) {
                var formData = new FormData(document.getElementById("reason_form_stage_1"));
                $('#cover-spin').show(0);
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/comment_document") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                        } else {
                            alert(data["msg"]);
                        }
                    }
                });
            }
        })
    });

    $("#verify_email_stage_1").submit(function(e) {
        e.preventDefault();
        // custom_alert_popup_show(header = '', body_msg = "Are you sure you want to Add Employment Email Verification ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_1_verfi_emil_pop_btn');
        // // check Btn click
        // $("#stage_1_verfi_emil_pop_btn").click(function() {
        //     // if return true 
        //     if (custom_alert_popup_close('stage_1_verfi_emil_pop_btn')) {}
        // });
        $('#cover-spin').show(0);
        var formData = new FormData(document.getElementById("verify_email_stage_1"));
        $.ajax({
            method: "POST",
            url: "<?= base_url("admin/application_manager/verify_email_stage_1") ?>",
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                data = JSON.parse(data);
                if (data["response"] == true) {
                    window.location.reload();
                } else {
                    alert(data["msg"]);
                    $('#cover-spin').hide(0);
                }
            }
        });

    });
    
    $("#quali_verify_form").submit(function(e) {
        e.preventDefault();
        $("#loader-please-wait").show();
        var formData = new FormData($(this)[0]);
         custom_alert_popup_show(header = '', body_msg = "Are you sure you want to Send Qualification Verification Email ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_1_quali_verfi_emil_pop_btn');
        // check Btn click
        $("#stage_1_quali_verfi_emil_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_1_quali_verfi_emil_pop_btn')) {
                $('#cover-spin').show(0);
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/qualification_verification_form") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            $('#cover-spin').hide(0);
                            window.location.reload();
                        } else {
                            alert(data["msg"]);
                            $('#cover-spin').hide(0);
                        }
                    }
                });
            }
        });
    });
    
    // document->stage 1 end ----------------------------
    // document->stage 2 ----------------------------
    function show_input_s2(count_id) {
        if ($("#input_s2_" + count_id).css("display") == "none") {
            $("#input_s2_" + count_id).css("display", "block");
            $("#input_s2_" + count_id).focus();
            $("#Dbtn_s2_" + count_id).hide();
            $("#Xbtn_s2_" + count_id).show();
            check_s2();
        } else {
            $("#input_s2_" + count_id).val("");
            $("#input_s2_" + count_id).css("display", "none")
            $("#Dbtn_s2_" + count_id).show();
            $("#Xbtn_s2_" + count_id).hide();
            $('#s2_doc_sub_btn').css("display", "block");
            check_s2();
        }
    }

    function check_s2() {
        var count_ = 0;
        var value = $('input[type="text"].s1').filter(function() {
            console.log(value);
            if (this.value.length > 0) {
                count_++;
            }
        });
        console.log(count_);
        if (count_ > 0) {
            $('#s2_doc_sub_btn').css("display", "block");
        } else {
            $('#s2_doc_sub_btn').hide();
        }
    }
    // comments function ---------------------------   
    $("#reason_form_stage_2").submit(function(e) {
        e.preventDefault();


        custom_alert_popup_show(header = '', body_msg = "Do you want to send  the additional info request ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_doc_2_pop_btn');
        // check Btn click
        $("#stage_doc_2_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_doc_2_pop_btn')) {
                var formData = new FormData(document.getElementById("reason_form_stage_2"));
                $('#cover-spin').show(0);
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/comment_document") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {

                        console.log(data);

                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                        } else {
                            $('#cover-spin').hide(0);

                            alert(data["msg"]);
                        }
                    }
                });
            }
        })
    });
    // send mail to employes function ---------------------------   
    function send_emp_email() {
        // creat alert box 
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to send Employment Verification Email ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDS');
        // check Btn click
        $("#AJDS").click(function() {
            // if return true 
            if (custom_alert_popup_close('AJDS')) {
                $('#cover-spin').show(100);
                $.ajax({
                    url: "<?= base_url('admin/application_manager/send_employ_email_stage_2') ?>",
                    method: "POST",
                    data: {
                        "pointer_id": pointer_id,
                    },
                    success: function(data) {
                        $('#cover-spin').hide(200);
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                        } else {
                            alert(data["msg"]);
                        }
                    }
                });
            }
        })
    }
    // verify employee mail function ---------------------------   
    $("#verify_email_stage_2").submit(function(e) {
        e.preventDefault();
        // custom_alert_popup_show(header = '', body_msg = "Are you sure you want to Add Employment Email Verification  ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_ver_emp_2_pop_btn');
        // check Btn click
        // $("#stage_ver_emp_2_pop_btn").click(function() {
        //     // if return true 
        //     if (custom_alert_popup_close('stage_ver_emp_2_pop_btn')) {}
        // });

        var formData = new FormData(document.getElementById("verify_email_stage_2"));
        $('#cover-spin').show(0);
        $.ajax({
            method: "POST",
            url: "<?= base_url("admin/application_manager/verify_email_stage_2") ?>",
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                data = JSON.parse(data);
                if (data["response"] == true) {
                    window.location.reload();
                } else {
                    alert(data["msg"]);
                }
            }
        });

    });
    // document->stage 2 end ----------------------------
    // document->stage 3 ----------------------------
    function show_input_s3(count_id) {
        if ($("#input_s3_" + count_id).css("display") == "none") {
            $("#input_s3_" + count_id).css("display", "block");
            $("#input_s3_" + count_id).focus();
            $("#Dbtn_s3_" + count_id).hide();
            $("#Xbtn_s3_" + count_id).show();
            console.log("hfjhg");
            check_s3();
        } else {
            $("#input_s3_" + count_id).val("");
            $("#input_s3_" + count_id).css("display", "none")
            $("#Dbtn_s3_" + count_id).show();
            $("#Xbtn_s3_" + count_id).hide();
            $('#s3_doc_sub_btn').css("display", "block");
            check_s3();
        }
    }
    
    function check_s3() {
        var count_ = 0;
        var value = $('input[type="text"].s1').filter(function() {
            console.log(value);
            if (this.value.length > 0) {
                count_++;
            }
        });
        console.log(count_);
        if (count_ > 0) {
            $('#s3_doc_sub_btn').css("display", "block");
        } else {
            $('#s3_doc_sub_btn').hide();
        }
    }

    // comments function ---------------------------   
    $("#reason_form_stage_3").submit(function(e) {
        e.preventDefault();
        custom_alert_popup_show(header = '', body_msg = "Do you want to send  the additional info request ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_doc_3_pop_btn');
        // check Btn click
        $("#stage_doc_3_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_doc_3_pop_btn')) {
                var formData = new FormData(document.getElementById("reason_form_stage_3"));
                $('#cover-spin').show(0);
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/comment_document") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                        } else {
                            alert(data["msg"]);
                        }
                    }
                });
            }
        })
    });
    // document->stage 3 end ----------------------------
    
    // document->stage 4 ----------------------------
    function show_input_s4(count_id) {
        if ($("#input_s4_" + count_id).css("display") == "none") {
            $("#input_s4_" + count_id).css("display", "block");
            $("#input_s4_" + count_id).focus();
            $("#Dbtn_s4_" + count_id).hide();
            $("#Xbtn_s4_" + count_id).show();
            console.log("hfjhg");
            check_s4();
        } else {
            $("#input_s4_" + count_id).val("");
            $("#input_s4_" + count_id).css("display", "none")
            $("#Dbtn_s4_" + count_id).show();
            $("#Xbtn_s4_" + count_id).hide();
            $('#s4_doc_sub_btn').css("display", "block");
            check_s4();
        }
    }

    function check_s4() {
        var count_ = 0;
        var value = $('input[type="text"].s1').filter(function() {
            console.log(value);
            if (this.value.length > 0) {
                count_++;
            }
        });
        console.log(count_);
        if (count_ > 0) {
            $('#s4_doc_sub_btn').css("display", "block");
        } else {
            $('#s4_doc_sub_btn').hide();
        }
    }
    
    // document->stage 4  ----------------------------
    $("#reason_form_stage_4").submit(function(e) {
        e.preventDefault();
        custom_alert_popup_show(header = '', body_msg = "Do you want to send  the additional info request ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'stage_doc_4_pop_btn');
        // check Btn click
        $("#stage_doc_4_pop_btn").click(function() {
            // if return true 
            if (custom_alert_popup_close('stage_doc_4_pop_btn')) {
                var formData = new FormData(document.getElementById("reason_form_stage_4"));
                $('#cover-spin').show(0);
                $.ajax({
                    method: "POST",
                    url: "<?= base_url("admin/application_manager/comment_document") ?>",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+data['pointer_id']+tab;
                        } else {
                            alert(data["msg"]);
                        }
                    }
                });
            }
        })
    });
    // document->stage 4 end ----------------------------
    
    
    // Common function --------------------------- 
    // table should not sort
    $(document).ready(function() {
        $('no_filter_table').DataTable({
            "columnDefs": [{
                    "orderable": false,
                    "aTargets": [0, 1, 2]
                },
                // { "bSearchable": false, "aTargets": [ 0, 1, 2 ] }
            ]
        });
    });

    // Delete function --------------------------- 
    function delete_document(id) {
        // return;
        // var form = $("#reason_form_stage_3");
        // form.preventDefault();
        custom_alert_popup_show(header = '', body_msg = "Are you sure that you would like to permanently delete this file ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'delete_pop_btn');
        $("#delete_pop_btn").click(function() {
            if (custom_alert_popup_close('delete_pop_btn')) {
                $('#cover-spin').show(0);
                $.ajax({
                    url: "<?= base_url('admin/application_manager/delete_document') ?>/" + id,
                    method: "POST",
                    data: {
                        "id": id,
                    },
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php // base_url("admin/application_manager/view_application/") ?>/"+pointer_id+'/'+tab;
                        } else {
                            alert(data["msg"]);
                        }
                    },
                });
            }
        });
    }

    function delete_employe(id) {
        // return;
        // var form = $("#reason_form_stage_3");
        // form.preventDefault();
        custom_alert_popup_show(header = '', body_msg = "Are you sure that you would like to permanently delete this Organization ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'delete_pop_btn_s2');
        $("#delete_pop_btn_s2").click(function() {
            if (custom_alert_popup_close('delete_pop_btn_s2')) {

                $('#cover-spin').show(0);
                $.ajax({
                    url: "<?= base_url('admin/application_manager/delete_company') ?>/" + id,
                    method: "POST",
                    data: {
                        "id": id,
                    },
                    success: function(data) {
                        data = JSON.parse(data);
                        if (data["response"] == true) {
                            window.location.reload();
                            // window.location = "<?php base_url("admin/application_manager/view_application/") ?>/"+pointer_id+'/'+tab;
                        } else {
                            alert(data["msg"]);
                        }
                    },
                });

            }
        });
    }
    // zip for all stage function --------------------------- 
    function download_zip(pointer_id, stage) {
        // creat alert box 
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to download all files?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
        // check Btn click
        $("#AJDSAKAJLD").click(function() {
            // if return true 
            if (custom_alert_popup_close('AJDSAKAJLD')) {
                $.ajax({
                    url: "<?= base_url('admin/application_manager/download_zip') ?>/" + pointer_id + '/' + stage,
                    type: "POST",
                    data: {
                        "pointer_id": pointer_id,
                        "stage": stage,
                    },
                    beforeSend: function() {},
                    success: function(data) {
                        console.log(data);

                        window.location = data;
                        
                        setTimeout(function() {
                              location.reload();
                            }, 5000);

                    // header("Refresh: 5; URL=http://example.com/newpage.php");

                    },
                });
            }
        })
    }
    // Common function end --------------------------- 
    // Documnents end ------------------------------
    var stage_level = '<?= $application_pointer->stage ?>';
    console.log(stage_level);
    if (stage_level == 'stage_1') {
        var element = document.getElementById("view_stage_1");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_1");
        element_1.classList.add('show')
    } else if (stage_level == 'stage_2') {
        var element = document.getElementById("stage_2");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_2");
        element_1.classList.add('show')
    } else if (stage_level == 'stage_3') {
        var element = document.getElementById("stage_3");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_3");
        element_1.classList.add('show')
    } else if (stage_level == 'stage_4') {
        var element = document.getElementById("stage_4");
        element.classList.add('show')
        var element_1 = document.getElementById("doc_stage_4");
        element_1.classList.add('show')
    }
    
    // -------------------
    // Tab Change Here Code
    // -------------------


    // vishal patel  26-04-2023   &#9786;
    $('.auto_file_upload').hide();
    $('.auto_file_upload_appr_path').hide();
    // vishal 27-04-2023 
    $('.auto_file_upload_dec_path_1').hide();
    $('.auto_file_upload_dec_Statement_of_Reasons').hide();

    $('.auto_file_upload_dec_statement_reason_s2').hide();
    $('.auto_file_upload_dec_path_2').hide();
    // Akanksha falle  16-6-2023   
        function s2_show_upload_file(id) {
        var check = $(id).is(":hidden");
        if (check) {
            if (id == "#s2_outcome") {
                $('.auto_file_upload_dec_path_2').show();
            }
            if (id == "#s2_dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_statement_reason_s2').show();
            }
            $(id).show();
             $(id).prop('required', true);

            var occupation= "<?php echo find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name; ?>";
            var pathway="<?php echo  $s1_occupation->pathway; ?>";
            if(pathway=="Pathway 1"){
                if(occupation=="Electrician (General)"||occupation=="Plumber (General)"){
                    $(id).prop('required', false);
                }
            }
        } else {
            if (id == "#s2_outcome") {
                $('.auto_file_upload_dec_path_2').hide();
            }
            if (id == "#s2_dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_statement_reason_s2').hide();
            }
            $(id).hide();
            $(id).prop('required', false);
        }
    }
    
    // vishal patel  26-04-2023   &#9786;
    function show_upload_file(id) {
        var check = $(id).is(":hidden");
        if (check) {
            if (id == "#appr_path") {
                $('.auto_file_upload_appr_path').show();
            }
            if (id == "#appr_path_1") {
                $('.auto_file_upload').show();
            }
            // vishal 27-04-2023 
            if (id == "#dec_path_1") {
                $('.auto_file_upload_dec_path_1').show();
            }
            if (id == "#dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_Statement_of_Reasons').show();
            }
            $(id).show();
             $(id).prop('required', true);

            var occupation= "<?php echo find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name; ?>";
            var pathway="<?php echo  $s1_occupation->pathway; ?>";
            if(pathway=="Pathway 1"){
                 if(occupation=="Electrician (General)"||occupation=="Plumber (General)"){
                            $(id).prop('required', false);

            }
           
            }
            
            

        } else {
            if (id == "#appr_path") {
                $('.auto_file_upload_appr_path').hide();
            }
            if (id == "#appr_path_1") {
                $('.auto_file_upload').hide();
            }
            // vishal 27-04-2023 
            if (id == "#dec_path_1") {
                $('.auto_file_upload_dec_path_1').hide();
            }
            if (id == "#dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_Statement_of_Reasons').hide();
            }
            $(id).hide();
            $(id).prop('required', false);
        }
    }
    
    
    function s4_show_upload_file(id) {
        var check = $(id).is(":hidden");
        if (check) {
            if (id == "#s4_appr_path") {
                $('.auto_file_upload_appr_path').show();
            }
            if (id == "#s4_appr_path_1") {
                $('.auto_file_upload').show();
            }
            // vishal 27-04-2023 
            if (id == "#s4_dec_path_1") {
                $('.auto_file_upload_dec_path_1').show();
            }
            if (id == "#s4_dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_Statement_of_Reasons').show();
            }
            $(id).show();
             $(id).prop('required', true);

            var occupation= "<?php echo find_one_row('occupation_list', 'id', $s1_occupation->occupation_id)->name; ?>";
            var pathway="<?php echo  $s1_occupation->pathway; ?>";
            if(pathway=="Pathway 1"){
                 if(occupation=="Electrician (General)"||occupation=="Plumber (General)"){
                            $(id).prop('required', false);

            }
           
            }
            
            

        } else {
            if (id == "#s4_appr_path") {
                $('.auto_file_upload_appr_path').hide();
            }
            if (id == "#s4_appr_path_1") {
                $('.auto_file_upload').hide();
            }
            // vishal 27-04-2023 
            if (id == "#s4_dec_path_1") {
                $('.auto_file_upload_dec_path_1').hide();
            }
            if (id == "#s4_dec_Statement_of_Reasons") {
                $('.auto_file_upload_dec_Statement_of_Reasons').hide();
            }
            $(id).hide();
            $(id).prop('required', false);
        }
    }
// akanksha 16 june 2023
 function s2_auto_file_upload(file_id, file_upload_name) {
     console.log(file_upload_name);
    //  return;
        const fileData = $("#" + file_id)[0].files[0];
        const pointer_id = "<?= $pointer_id ?>";
        const formData = new FormData();
        formData.append("file", fileData);
        formData.append("pointer_id", pointer_id);
        formData.append("file_upload_name", file_upload_name);
        if (fileData && fileData.size > 0) {
            $('#cover-spin').show(0);

            $.ajax({
                url: "<?= base_url('admin/File_update_stage_2') ?>",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log("File uploaded successfully!");
                    console.log(response);
                    if (response == "ok") {
                        location.reload();
                    }
                },
                error: function(xhr, status, error) {
                    $('#cover-spin').hide(0);
                    console.error("Error uploading file: " + error);
                    custom_alert_popup_show(header = '', body_msg = "Sorry, file is not uploaded.Successfully some technical issue was found.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

                }
            });
        } else {
            custom_alert_popup_show(header = '', body_msg = "Please select file then try to upload.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

        }
    }
    
   
    // vishal patel  26-04-2023   &#9786;
    function auto_file_upload(file_id, file_upload_name) {
        const fileData = $("#" + file_id)[0].files[0];
        const pointer_id = "<?= $pointer_id ?>";
        const formData = new FormData();
        formData.append("file", fileData);
        formData.append("pointer_id", pointer_id);
        formData.append("file_upload_name", file_upload_name);
        // console.log(fileData);
        // console.log(pointer_id);
        // console.log(file_upload_name);
        // console.log("vishal:-------------");
        // return;
        if (fileData && fileData.size > 0) {
            $('#cover-spin').show(0);

            $.ajax({
                url: "<?= base_url('admin/File_update_stage_3') ?>",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log("File uploaded successfully!");
                    console.log(response);
                    if (response == "ok") {
                        location.reload();
                    }
                },
                error: function(xhr, status, error) {
                    $('#cover-spin').hide(0);
                    console.error("Error uploading file: " + error);
                    custom_alert_popup_show(header = '', body_msg = "Sorry, file is not uploaded.Successfully some technical issue was found.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

                }
            });
        } else {
            custom_alert_popup_show(header = '', body_msg = "Please select file then try to upload.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

        }
    }
    
    
    function s4_auto_file_upload(file_id, file_upload_name) {
        
        const fileData = $("#" + file_id)[0].files[0];
        const pointer_id = "<?= $pointer_id ?>";
        const formData = new FormData();
        formData.append("file", fileData);
        formData.append("pointer_id", pointer_id);
        formData.append("file_upload_name", file_upload_name);
        // console.log(fileData);
        // console.log(pointer_id);
        // console.log(file_upload_name);
        // console.log("vishal:-------------");
        // return;
        if (fileData && fileData.size > 0) {
            $('#cover-spin').show(0);

            $.ajax({
                url: "<?= base_url('admin/File_update_stage_4') ?>",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log("File uploaded successfully!");
                    console.log(response);
                    if (response == "ok") {
                        location.reload();
                    }
                },
                error: function(xhr, status, error) {
                    $('#cover-spin').hide(0);
                    console.error("Error uploading file: " + error);
                    custom_alert_popup_show(header = '', body_msg = "Sorry, file is not uploaded.Successfully some technical issue was found.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

                }
            });
        } else {
            custom_alert_popup_show(header = '', body_msg = "Please select file then try to upload.", close_btn_text = 'Ok', close_btn_css = 'btn-danger', other_btn = false, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');

        }
    }



    function re_create_TRA() {
        $.ajax({
            url: "<?= base_url('auto_save_download_PDF_admin/' . pointer_id_encrypt($pointer_id) . '/TRA%20Application%20Form'); ?>",
            type: "GET",
            beforeSend: function() {},
            success: function(data) {
                // console.log(data);
                window.location = data;
            },
        });
    }
    
        function eddit() {

            new TomSelect("#select_edite_time_zone", {
                plugins: ['dropdown_input']
            });
        }
        
         new TomSelect("#time_zone", {
            // create: true,
            // sortField: {
            //     field: "text",
            //     direction: "asc"
            // }
            plugins: ['dropdown_input']
        });

</script>


<?= $this->endSection() ?>