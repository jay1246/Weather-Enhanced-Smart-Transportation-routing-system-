<?= $this->extend('template/login_template') ?>
<?= $this->section('main') ?>

<!-- inner heading  -->
<div class="bg-green text-white text-center">
    <span class="a">
        Welcome to the Skills Assessment Online Portal
    </span>
</div>


<div class="container mt-4 mb-4 ">

    <div class="row">
        <div class="col-md-3"></div>

        <div class="col-md-6 shadow bg-white">
            <!-- Alert on set - Flashdata -->
            <?= $this->include("alert_box.php") ?>

            <form action="<?= base_url('user_Forgot_Password_check') ?>" id="forgot_Password_form" method="post" class="row needs-validation">
                <div class="col-sm-12" style="text-align: center;">
                    <h6 style="padding-top: 10px; padding-bottom: 10px;  font-weight:bold;"> Forgot Password ?<br></h6>
                    <h8 class="">Please Enter your Registerd Email</h8>

                    <hr>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text"> Email <span class="text-danger">*</span></div>
                        </div>
                        <input type="text" name="email" class="form-control" id="inlineFormInputGroupUsername" required placeholder="Please Enter your Registerd Email.." />
                        <input type="hidden" name="type" value="user" class="form-control">
                    </div>
                    <br>
                    <!-- google  re capchur alert  -->
                    <div class="alert alert-danger" style="display: none;" id="alert">Please fill the captcha!</div>
                    <div class="text-center" id="recaptcha">
                        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                        <div class="g-recaptcha" data-callback="recaptchaCallback" data-sitekey="<?= env('Google_your_site_key') ?>"></div>
                    </div>
                    <br>
                    <input type="submit" name="submit" class="btn btn_green_yellow" value="Retrieve Password">
                    <br>
                    <br>
                    <a class="text-green" href="<?= base_url('user/login') ?>">Back To Login</a>
                    <br>
                    <br>
                </div>
            </form>

        </div>

        <div class="col-md-3"></div>


    </div>
</div>
<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<script>
    var recaptchachecked;
    $("#alert").hide();

    function recaptchaCallback() {
        recaptchachecked = true;
        if (recaptchachecked) {
            $("#alert").fadeOut("slow");
        }
    }
    $("#forgot_Password_form").submit(function(e) {
        if (recaptchachecked) {
            return true;
        } else {
            $("#alert").fadeIn("slow");
            return false;
        }
    });
</script>

<?= $this->endSection() ?>