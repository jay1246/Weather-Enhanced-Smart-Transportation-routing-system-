<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>


<!-- inner heading  -->
<div class=" bg-green text-white text-center">
    Stage 1 - Self Assessment
</div>



<style>
    .arrow {
        border-radius: 0px !important;
        clip-path: polygon(93% 0, 100% 50%, 93% 100%, 0% 100%, 6% 50%, 0% 0%);
    }

    a.active {
        background-color: var(--yellow) !important;
        color: var(--green) !important;
    }

    .active {
        border: 1px solid var(--yellow) !important;

    }

    .staper_btn {
        max-width: 400px;
    }
</style>


<!-- start body  -->
<div class="container mt-4 mb-4 p-4 bg-white shadow">
    <!-- Application Details  -->
    <div class="row">
        <div class="col-sm-6">
            <h2 class="text-green"><b> Application Details </b></h2>

            <table class="table">
                <tr>
                    <td>
                        Application No.
                    </td>
                    <td>
                        <!-- <?= $pointer_id ?> -->
                        <?= $Application_Details['unique_id'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Applicant's Name
                    </td>
                    <td>
                        <?= $Application_Details['name'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Occupation
                    </td>
                    <td>
                        <?= $Application_Details['occupation'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Pathway
                    </td>
                    <td>
                        <?= $Application_Details['pathway'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Program
                    </td>
                    <td>
                        <?= $Application_Details['program'] ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-sm-6 d-flex align-items-center justify-content-center">
            <img src="https://cdn-icons-png.flaticon.com/512/180/180658.png" width="170px" height="170px" class="shadow">

        </div>
    </div>

    <?php
    // echo $stage_index."<br/>mohhshshshsh";
    ?>

    <!-- all stage Stapper Button  -->
    <div class="row nav nav-tabs" id="nav-tab" role="tablist">
        <?php
        // echo $stage_index;
        ?>
        <!-- <?= $stage_index ?>
        <?= $is_active ?> -->

        <?php if ($stage_index >= 2) {  ?>
            <a href="" type="button" class=" staper_btn  <?= ($is_active == "stage_1") ? "active" : ""; ?> col-sm btn arrow bg-green text-yellow" id="stage_1-tab" data-bs-toggle="tab" data-bs-target="#stage_1" role="tab" aria-controls="stage_1" aria-selected="<?= ($is_active == "stage_1") ? "true" : "false"; ?>">
                Stage 1 - Self Assessment
            </a>
        <?php } ?>

        <?php if ($stage_index == 5 || $stage_index >= 11) { ?>
            <a href="" type="button" class="staper_btn <?= ($is_active == "stage_2") ? "active" : ""; ?> col-sm btn arrow bg-green text-yellow" id="stage_2-tab" data-bs-toggle="tab" data-bs-target="#stage_2" role="tab" aria-controls="stage_2" aria-selected="<?= ($is_active == "stage_2") ? "true" : "false"; ?>">
                Stage 2 - Documentry Evidence
            </a>
        <?php } else { ?>
            <button class="disabled col-sm btn arrow bg-green text-yellow"> Stage 2 - Documentry Evidence </button>
        <?php } ?>

        <?php
        // echo $is_active;
        // echo $stage_index;
        if ($stage_index == 15 || ($stage_index >= 21)) { ?>
            <a href="" class="staper_btn <?= ($is_active == "stage_3") ? "active" : ""; ?> col-sm btn arrow bg-green text-yellow" id="stage_3-tab" data-bs-toggle="tab" data-bs-target="#stage_3" role="tab" aria-controls="stage_3" aria-selected="<?= ($is_active == "stage_3") ? "true" : "false"; ?>">
                Stage 3 -Technical Interview
            </a>
        <?php } else { ?>
            <button class="disabled col-sm btn arrow bg-green text-yellow"> Stage 3 -Technical Interview </button>
        <?php } ?>



        <?php if ($stage_index >= 41 && $stage_index <= 50) { ?>
            <a href="" class=" staper_btn col-sm btn arrow bg-green text-yellow" id="Complete-tab" data-bs-toggle="tab" data-bs-target="#Complete" role="tab" aria-controls="Complete" aria-selected="false">
                Complete
            </a>
        <?php } else { ?>
            <button class="disabled col-sm btn arrow bg-green text-yellow"> Complete </button>
        <?php } ?>
    </div>


    <!-- stage 1 TO stage 5  data  -->
    <div class="tab-content" id="nav-tabContent">
        <?= $stage_index ?>
        <!-- stage 1  -->
        <?php if ($stage_index >= 2) { ?>
            <div class="tab-pane fade <?= ($is_active == "stage_1") ? "show active " : ""; ?>  bg-white shadow- p-3" id="stage_1" role="tabpanel" aria-labelledby="stage_1-tab">
                <div class="row mt-3">
                    <!-- left  -->
                    <div class="col-sm-6">
                        <table class="table">
                            <thead>
                                <!-- Submitted  -->
                                <?php if (isset($stage_1['status']) && !empty($stage_1['status'])) { ?>
                                    <tr>
                                        <th>
                                            Status
                                        </th>
                                        <td>
                                            <?= $stage_1['status'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            Date Submitted
                                        </th>
                                        <td>
                                            <?= date("d/m/Y H:i:s", strtotime($stage_1['submitted_date'])) ?>
                                        </td>
                                    </tr>
                                <?php } ?>

                                <!-- Lodged  date  -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Lodged") { ?>
                                    <?php if (isset($stage_1['lodged_date']) && !empty($stage_1['lodged_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Lodged
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_1['lodged_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- In Progress  date  -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "In Progress") { ?>
                                    <?php if (isset($stage_1['in_progress_date']) && !empty($stage_1['in_progress_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date In Progress
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_1['in_progress_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Approved  date -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Approved") { ?>
                                    <?php if (isset($stage_1['approved_date']) && !empty($stage_1['approved_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Approved
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_1['approved_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Decline  date / Reason -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Declined") { ?>
                                    <?php if (isset($stage_1['declined_date']) && !empty($stage_1['declined_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Declined
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_1['declined_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <?php if (isset($stage_1['declined_reason']) && !empty($stage_1['declined_reason']) && strlen($stage_1['declined_reason']) > 2) { ?>
                                        <tr>
                                            <th>
                                                Reason for Decline
                                            </th>
                                            <td>
                                                <?= $stage_1['declined_reason'] ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Withdrawn  date  -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Withdrawn") { ?>
                                    <?php if (isset($stage_1['withdraw_date']) && !empty($stage_1['withdraw_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Withdrawn
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_1['withdraw_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!--  Archive  -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Archive") { ?>

                                    <!-- Date Archive  -->
                                    <?php if (isset($stage_1['archive_date']) && !empty($stage_1['archive_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Archive
                                            </th>
                                            <td>
                                                <?= $stage_1['archive_date'] ?>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                    <!-- Archive yellow alert box  -->
                                    <tr>
                                        <td colspan="2">
                                            <div class="p-2 bg-yellow rounded">
                                                Kindly reach out on <a href="tel:+61-401200991">+61-401200991</a> or email to <a href="mail:dilpreet.bagga@attc.org.au">dilpreet.bagga@attc.org.au</a> to re-instate the application. The applications can only be re-instated within 60 days from the date of Stage 1 approval, conditional to the applicant still meeting the eligibility requirements.
                                            </div>
                                        </td>
                                    </tr>

                                <?php } ?>

                            </thead>
                        </table>
                        <div class="col-sm-12 d-flex align-items-center justify-content-center">
                            <div class="col-sm-7 p-3">
                                <div class="col-sm-12 p-3">
                                    <div id="download_outcome_letter_3" class="">
                                        <a href="<?= $TRA_Application_Form_url ?>" class="btn btn_green_yellow w-100" download>Download Submitted Application <i class="bi bi-download"></i> </a>
                                    </div>
                                </div>
                                <?php if ($stage_index == 5) {  ?>
                                    <div class="col-sm-12 p-3">
                                        <div id="download_outcome_letter_3" class="">
                                            <a href="<?= base_url('public/assets/PDF/Stage%202%20Applicant%20Checklist.pdf') ?>" class="btn btn_green_yellow p-2 w-100" download>Download Stage 2 Checklist <i class="bi bi-download "></i></a>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>

                    <!-- stage 1 documents  -->
                    <div class="col-sm-6">

                        <div class="card">
                            <a class="btn p-0 collapsed" data-bs-toggle="collapse" href="#collapseOne">
                                <div class="card-header">

                                    <h4 class="text-green"><b> Uploaded Documents </b></h4>
                                </div>

                            </a>
                            <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th> Sr.No. </th>
                                                <th> Document Name </th>
                                                <!-- <td> Document </td> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 0;
                                            foreach ($documents as $key => $value) {
                                                if ($value['stage'] == "stage_1") {
                                                    if ($value['required_document_id'] > 0) {
                                                        $i++;
                                                        $required_document_id = $value['required_document_id'];

                                            ?>
                                                        <tr>
                                                            <td> <?= $i; ?> </td>
                                                            <td>
                                                                <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                    <?= $value['name']; ?>
                                                                </a>
                                                            </td>
                                                            <!-- <td> <img src="<?= base_url($value['document_path'] . '/' . $value['document_name']) ?>" width="150px"> </td> -->
                                                        </tr>
                                            <?php
                                                    } // required_document_id
                                                } // stage
                                            } // forech 
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                    </div>

                    <!-- stage 1 Action Requad  -->
                    <?php if ($stage_index >= 2 && $stage_index < 5) {  ?>
                        <?php
                        $show_Additional_Information_Request = false;
                        foreach ($additional_info_request as $key_1 => $value_1) {
                            $stage = $value_1['stage'];
                            $status = $value_1['status'];
                            if ($stage == "stage_1" && $status == "send") {
                                $show_Additional_Information_Request = true;
                            }
                        }
                        ?>
                        <?php if ($show_Additional_Information_Request) { ?>
                            <div class="col-sm-12">
                                <hr>
                                <h4 class="text-green"><b> Additional Information Request</b></h4>
                                <br>


                                <form action="<?= base_url('user/additional_information_request/stage_1/' . $ENC_pointer_id) ?>" id="add_info_req_stage_1" method="post" enctype="multipart/form-data">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Comment</th>
                                                <th>Document Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $i = 1;
                                        foreach ($additional_info_request as $key => $value) {
                                            $pointer_id = $value['pointer_id'];
                                            $document_id = $value['document_id'];
                                            $stage = $value['stage'];
                                            $reason = $value['reason'];
                                            $status = $value['status'];
                                            $update_date = $value['update_date'];
                                            if ($stage == "stage_1" && $status == "send") {
                                                $doc_info = documents_info($pointer_id, $document_id);
                                                // if (!empty($doc_info)) {
                                                // echo "jfgj";
                                                if (isset($doc_info['required_document_id'])) {
                                                    $doc_required_document_id = $doc_info['required_document_id'];
                                                } else {
                                                    $doc_required_document_id = "";
                                                }
                                                if ($doc_info) {
                                                    $doc_id = $doc_info['id'];
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"  value="' . $doc_info['name'] . '" readonly>';
                                                } else {
                                                    $doc_id = '';
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"   required>';
                                                }

                                        ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <td><?= $reason ?></td>
                                                    <td><?= $doc_name ?></td>
                                                    <td>
                                                        <input type="file" class="form-control" name="file[]" accept="" required />

                                                        <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                        <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                        <input type="hidden" name="document_id[]" value="<?= $doc_id ?>">
                                                        <input type="hidden" name="stage" value="stage_1">

                                                    </td>
                                                </tr>
                                        <?php

                                                $i++;
                                            } // if stage_1
                                        } // forech
                                        ?>
                                    </table>
                                    <div class="mb-3 text-end">
                                        <!-- <button type="button" class="btn btn_green_yellow" onclick="add_info_req('stage_1')">upload</button> -->
                                        <button type="submit" class="btn btn_green_yellow" onclick="add_info_req('stage_1')">upload</button>
                                    </div>
                                </form>

                            </div>

                        <?php      } // dcon_info    
                        ?>
                    <?php    } // if stage_1   
                    ?>

                </div>
            </div>
        <?php  }  ?>
        <!--/ stage 1 -->

        <!-- stage 2  -->
        <?php if ($stage_index == 5 || $stage_index >= 11) { ?>
            <div class="tab-pane fade <?= ($is_active == "stage_2") ? "show active " : ""; ?> bg-white shadow p-3" id="stage_2" role="tabpanel" aria-labelledby="stage_2-tab">
                <div class="row mt-3">
                    <!--stage 2  status info  and button -->
                    <div class="<?= (empty($stage_2)) ? "col-sm-6" : "col-sm-6"; ?> ">
                        <!-- info table  -->
                        <table class="table <?= (isset($stage_2) && empty($stage_2)) ? "d-none " : ""; ?>">
                            <thead>
                                <!-- Status -->
                                <?php if (isset($stage_2['status']) && !empty($stage_2['status'])) { ?>
                                    <tr>
                                        <th>
                                            Status
                                        </th>
                                        <td>
                                            <?= $stage_2['status'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            Date Submitted
                                        </th>
                                        <td>
                                            <?= date("d/m/Y H:i:s", strtotime($stage_2['submitted_date'])) ?>
                                        </td>
                                    </tr>
                                <?php } ?>

                                <!-- Lodged  date  -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Lodged") { ?>
                                    <?php if (isset($stage_2['lodged_date']) && !empty($stage_2['lodged_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Lodged
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_2['lodged_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- In Progress  date  -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "In Progress") { ?>
                                    <?php if (isset($stage_2['in_progress_date']) && !empty($stage_2['in_progress_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date In Progress
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_2['in_progress_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Approved  date -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Approved") { ?>
                                    <?php if (isset($stage_2['approved_date']) && !empty($stage_2['approved_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Approved
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_2['approved_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Decline  date / Reason -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Declined") { ?>
                                    <?php if (isset($stage_2['declined_date']) && !empty($stage_2['declined_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Declined
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_2['declined_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <?php if (isset($stage_2['declined_reason']) && !empty($stage_2['declined_reason']) && strlen($stage_2['declined_reason']) > 2) { ?>
                                        <tr>
                                            <th>
                                                Reason for Decline
                                            </th>
                                            <td>
                                                <?= $stage_2['declined_reason'] ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Withdrawn  date  -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Withdrawn") { ?>
                                    <?php if (isset($stage_2['withdraw_date']) && !empty($stage_2['withdraw_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Withdrawn
                                            </th>
                                            <td>
                                                <?= date("d/m/Y H:i:s", strtotime($stage_2['withdraw_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>


                                <?php if (isset($stage_2['archive_date']) && $stage_2['archive_date'] == 0) { ?>
                                    <tr>
                                        <th>
                                            Date archive_date
                                        </th>
                                        <td>
                                            <?= $stage_2['archive_date'] ?>
                                        </td>
                                    </tr>
                                <?php } ?>

                            </thead>
                        </table>
                        <!-- button  -->
                        <div class="d-flex align-items-center justify-content-center">

                            <div class="<?= (empty($stage_2)) ? "row w-100 col-sm-12" : ""; ?> " style="max-width:600px;">
                                <div class="<?= (empty($stage_2)) ? "col-sm-6" : "col-sm-12"; ?>  mb-2">
                                    <div id="download_outcome_letter_3" class="">
                                        <a href="<?= base_url('public/assets/PDF/Stage%202%20Applicant%20Checklist.pdf') ?>" class="btn btn_green_yellow w-100" download="">Download Stage 2 Checklist <i class="bi bi-download "></i></a>
                                    </div>
                                </div>
                                <div class="<?= (empty($stage_2)) ? "col-sm-6" : "col-sm-12"; ?>  mb-2">
                                    <div id="download_outcome_letter_3" class="">
                                        <a href="https://at.aqato.com.au/public/backend/applicant_kit/Applicant_Kits_new/Cook.docx " class="btn btn_green_yellow w-100" download="Cook - Applicant Kit">Download Applicant Kit <i class="bi bi-download"></i> </a>
                                    </div>
                                </div>
                                <!-- stage 2 start only  -->

                                <?php
                                // echo $stage_index;
                                if ($stage_index == 11 || $stage_index == 5) { ?>
                                    <div class="<?= (empty($stage_2)) ? "col-sm-12" : "col-sm-12"; ?>  mb-2">
                                        <div id="download_outcome_letter_3" class="">
                                            <?php
                                            if (!$is_employe_add) { ?>
                                                <a href="<?= base_url('user/stage_2/add_employment') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                                    Start Stage 2 Submission
                                                </a>
                                            <?php } else { ?>
                                                <a href="<?= base_url('user/stage_2/add_employment_document') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                                    Continue Stage 2 Submission
                                                </a>
                                            <?php } ?>
                                        </div>
                                    </div>
                                <?php } ?>

                            </div>
                        </div>
                    </div>

                    <!-- stage 2 Uploaded documents  -->
                    <?php
                    // check stage 2 documant availebal to show 
                    $show_stage_2_documents = false;
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $show_stage_2_documents = true;
                            }
                        }
                    }
                    // create employee name list for filter 
                    $total_employee = array();
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $i++;
                                $required_document_id = $value['required_document_id'];
                                $employee_id = $value['employee_id'];
                                $employment_info = stage_2_employment_info($employee_id);
                                if (!empty($employment_info)) {
                                    $data = [
                                        "id" => $employment_info['id'],
                                        "company_organisation_name" => $employment_info['company_organisation_name'],
                                    ];
                                    if (!in_array($data, $total_employee)) {
                                        $total_employee[] = $data;
                                    }
                                }
                            }
                        }
                    }
                    ?>
                    <!-- show stage 2 Uploaded document -->
                    <?php if ($show_stage_2_documents) {  ?>
                        <div class="col-sm-6">

                            <div class="card">
                                <a class="btn p-0 collapsed" data-bs-toggle="collapse" href="#collapseOne">
                                    <div class="card-header">

                                        <h4 class="text-green"><b> Uploaded Documents </b></h4>
                                    </div>

                                </a>
                                <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
                                    <div class="card-body bg-white  w-100 col-sm-12">
                                        <form action="" id="add_info_req_stage_2" method="post">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Sr.No.</th>
                                                        <th>Company Organisation Name</th>
                                                        <th>Comment</th>
                                                        <th>Document Name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <?php
                                                $i = 0;
                                                foreach ($total_employee as $key_4 => $val_4) {
                                                    $employee_id = $val_4['id'];
                                                    // echo "<tr class='bg-light p-2'><td  colspan='2'>  " . $val_4['company_organisation_name'] . " </td><tr>";

                                                    foreach ($additional_info_request as $key => $value) {
                                                        $stage = $value['stage'];
                                                        $status = $value['status'];
                                                        $update_date = $value['update_date'];
                                                        if ($stage == "stage_2" && $status == "send") {
                                                            $pointer_id = $value['pointer_id'];
                                                            $reason = $value['reason'];
                                                            $request_document_id = $value['document_id'];

                                                            foreach ($documents as $key_2 => $val_2) {
                                                                $doc_id = $val_2['id'];
                                                                if ($doc_id == $request_document_id) {
                                                                    $request_employee_id = $val_2['employee_id'];
                                                                    // echo $employee_id . "---" . $request_employee_id . "<br>";
                                                                    if ($employee_id == $request_employee_id) {
                                                                        $doc_name = $val_2['name'];

                                                ?>
                                                                        <tr>
                                                                            <td><?= $i ?></td>
                                                                            <td><?= $val_4['company_organisation_name'] ?></td>
                                                                            <td><?= $reason ?></td>
                                                                            <td><?= $doc_name ?></td>
                                                                            <td>
                                                                                <input type="file" class="form-control" name="file[]" accept="" required />

                                                                                <input type="hidden" class="form-control" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                                                <input type="hidden" class="form-control" name="document_id[]" value="<?= $doc_id ?>">
                                                                                <input type="hidden" class="form-control" name="employee_id[]" value="<?= $employee_id ?>">
                                                                            </td>
                                                                        </tr>
                                                <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } // dcon_info 
                                                } // if stage_1
                                                ?>
                                            </table>
                                            <div class="mb-3 text-end">
                                                <button type="button" class="btn btn_green_yellow" onclick="add_info_req('stage_2')">upload</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>


                        </div>
                    <?php } ?>



                    <!-- show stage 2 document -->
                    <?php
                    $show_additional_info_request = false;
                    foreach ($additional_info_request as $key__ => $value__) {
                        $stage__ = $value__['stage'];
                        $status__ = $value__['status'];

                        if ($stage__ == "stage_2" && $status__ == "send") {
                            $show_additional_info_request = true;
                        }
                    }


                    $employ_show = false;
                    foreach ($total_employee as $key_4 => $val_4) {
                        $employee_id = $val_4['id'];
                        foreach ($additional_info_request as $key => $value) {
                            $stage = $value['stage'];
                            $status = $value['status'];
                            if ($stage == "stage_2" && $status == "send") {
                                $request_document_id = $value['document_id'];
                                foreach ($documents as $key_2 => $val_2) {
                                    $doc_id = $val_2['id'];
                                    if ($doc_id == $request_document_id) {
                                        $request_employee_id = $val_2['employee_id'];
                                        if ($employee_id == $request_employee_id) {
                                            $employ_show = true;
                                        }
                                    }
                                }
                            }
                        }
                    }


                    if ($show_additional_info_request) {
                        $i = 0;
                    ?>
                        <div class="col-sm-12">
                            <form action="<?= base_url('user/additional_information_request/stage_1/' . $ENC_pointer_id) ?>" id="add_info_req_stage_1" method="post" enctype="multipart/form-data">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>
                                            <!-- <th>Company Organisation Name</th> -->
                                            <th>Comment</th>
                                            <th>Document Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <?php if ($employ_show) { ?>
                                        <?php foreach ($total_employee as $key_4 => $val_4) {
                                            $employee_id = $val_4['id'];
                                            echo "<tr class='bg-light p-2'><td  colspan='4'>  " . $val_4['company_organisation_name'] . " </td><tr>";

                                            foreach ($additional_info_request as $key => $value) {
                                                $stage = $value['stage'];
                                                $status = $value['status'];
                                                $update_date = $value['update_date'];
                                                if ($stage == "stage_2" && $status == "send") {
                                                    $pointer_id = $value['pointer_id'];
                                                    $reason = $value['reason'];
                                                    $request_document_id = $value['document_id'];

                                                    foreach ($documents as $key_2 => $val_2) {
                                                        $doc_id = $val_2['id'];
                                                        if ($doc_id == $request_document_id) {
                                                            $request_employee_id = $val_2['employee_id'];
                                                            // echo $employee_id . "---" . $request_employee_id . "<br>";
                                                            if ($employee_id == $request_employee_id) {
                                                                $doc_name = $val_2['name'];
                                                                $i++;
                                        ?>
                                                                <tr>
                                                                    <td><?= $i ?></td>
                                                                    <!-- <td><?= $val_4['company_organisation_name'] ?></td> -->
                                                                    <td><?= $reason ?></td>
                                                                    <td>
                                                                        <input type="text" name="doc_name[]" value="<?= $doc_name ?>" class="form-control mb-2" readonly required />
                                                                    </td>
                                                                    <td>
                                                                        <input type="file" class="form-control" name="file[]" accept="" required />

                                                                        <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                                        <input type="hidden" name="send_by[]" value="<?= $value['send_by'] ?>">
                                                                        <input type="hidden" name="document_id[]" value="<?= $doc_id ?>">
                                                                        <input type="hidden" name="stage" value="stage_2">

                                                                        <input type="hidden" name="employee_id[]" value="<?= $employee_id ?>">
                                                                    </td>
                                                                </tr>
                                        <?php
                                                            }
                                                        }
                                                    }
                                                }
                                            } // dcon_info 
                                        } // if stage_1
                                        ?>
                                    <?php } ?>


                                    <?php
                                    foreach ($additional_info_request as $key => $value) {
                                        $stage = $value['stage'];
                                        $status = $value['status'];
                                        $update_date = $value['update_date'];
                                        if ($stage == "stage_2" && $status == "send") {
                                            $pointer_id = $value['pointer_id'];
                                            $reason = $value['reason'];
                                            // print_r($value);
                                            $i++;
                                    ?>
                                            <tr>
                                                <td><?= $i ?></td>
                                                <!-- <td></td> -->
                                                <td><?= $reason ?></td>
                                                <td>
                                                    <input type="text" name="doc_name[]" class="form-control mb-2" required />
                                                </td>
                                                <td>
                                                    <input type="file" class="form-control" name="file[]" accept="" required />

                                                    <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                    <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                    <input type="hidden" name="document_id[]" value="">
                                                    <input type="hidden" name="stage" value="stage_2">
                                                    <input type="hidden" name="employee_id[]" value="<?= $employee_id ?>">
                                                </td>
                                            </tr>
                                    <?php }
                                    } ?>

                                </table>
                                <div class="mb-3 text-end">
                                    <button type="submit" class="btn btn_green_yellow" onclick="add_info_req('stage_2')">upload</button>
                                </div>
                            </form>
                        </div>
                    <?php } ?>



                    <!--hide stage 2 Action Requad  -->
                    <?php if ($stage_index == 987877) {  ?>
                        <?php if ($stage_index >= 11 && $stage_index < 20) {  ?>
                            <?php
                            $show_Additional_Information_Request = false;
                            foreach ($additional_info_request as $key_1 => $value_1) {
                                $stage = $value_1['stage'];
                                $status = $value_1['status'];
                                if ($stage == "stage_2" && $status == "send") {
                                    $show_Additional_Information_Request = true;
                                }
                            }
                            ?>
                            <?php if ($show_Additional_Information_Request) { ?>
                                <div class="col-sm-12">
                                    <hr>
                                    <h4 class="text-green"><b> Additional Information Request</b></h4>
                                    <br>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Company Organisation Name</th>
                                                <th>Comment</th>
                                                <th>Document Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $i = 0;
                                        foreach ($total_employee as $key_4 => $val_4) {
                                            $employee_id = $val_4['id'];
                                            // echo "<tr class='bg-light p-2'><td  colspan='2'>  " . $val_4['company_organisation_name'] . " </td><tr>";

                                            foreach ($additional_info_request as $key => $value) {
                                                $stage = $value['stage'];
                                                $status = $value['status'];
                                                $update_date = $value['update_date'];
                                                if ($stage == "stage_2" && $status == "send") {
                                                    $pointer_id = $value['pointer_id'];
                                                    $reason = $value['reason'];
                                                    $request_document_id = $value['document_id'];

                                                    foreach ($documents as $key_2 => $val_2) {
                                                        $doc_id = $val_2['id'];
                                                        if ($doc_id == $request_document_id) {
                                                            $request_employee_id = $val_2['employee_id'];
                                                            // echo $employee_id . "---" . $request_employee_id . "<br>";
                                                            if ($employee_id == $request_employee_id) {
                                                                $doc_required_document_id = $val_2['required_document_id'];
                                                                $doc_employee_id = $val_2['employee_id'];
                                                                $doc_name = $val_2['name'];
                                                                $doc_document_name = $val_2['document_name'];
                                                                $doc_document_path = $val_2['document_path'];
                                                                echo '  <tr>
                                                            <td>' . $i . '</td>
                                                            <td>' . $val_4['company_organisation_name'] . '</td>
                                                            <td>' . $reason . '</td>
                                                            <td>' . $doc_name . '</td>
                                                            <td>
                                                                <input type="file" class="form-control" name="file" accept="" required />
                                                            </td>
                                                        </tr>';
                                                            }
                                                        }
                                                    }
                                                }
                                            } // dcon_info 
                                        } // if stage_1
                                        ?>
                                    </table>

                                </div>
                            <?php
                            } // show or not 
                            ?>

                        <?php } ?>
                    <?php } ?>


                </div> <!--- row --->
            </div>
        <?php } ?>

        <!-- stage 3  -->
        <?php if ($stage_index == 15 || ($stage_index >= 21)) { ?>
            <div class="tab-pane fade <?= ($is_active == "stage_3") ? "show active " : ""; ?>  bg-white shadow- p-3" id="stage_3" role="tabpanel" aria-labelledby="stage_3-tab">
                <div class="row mt-3">
                    <!--stage 3  status info  and button -->
                    <div class="col-sm-6">
                        <!-- info table  -->
                        <?php
                        if (isset($stage_3)) {
                            if ($stage_3["status"] != "") {
                        ?>
                                <table class="table ">
                                    <thead>
                                        <tr>
                                            <th>
                                                Status
                                            </th>
                                            <td>
                                                <?= $stage_3["status"] ?> </td>
                                        </tr>
                                        <tr>
                                            <th>
                                                Date Submitted
                                            </th>
                                            <td>

                                                <?= date("d/m/Y H:i:s", strtotime($stage_3["submitted_date"])) ?>
                                            </td>
                                        </tr>

                                    </thead>
                                </table>

                                <?php
                                if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Scheduled') {
                                    if (isset($Interview_Schedule['is_booked']) && $Interview_Schedule['is_booked'] == 1) { ?>
                                        <table class="table ">
                                            <thead>
                                                <tr>
                                                    <td style="width: 30%;border-bottom: 0px;margin-top:10px" colspan="2">
                                                        <br>
                                                        <u> <b style="color: #055837;"> Interview Schedule</b></u> <br>
                                                    </td>
                                                </tr>
                                                <tr style="background-color: #ffc107 !important;">
                                                    <td colspan="2" style="background-color: #ffc107;">
                                                        <div style="background-color: #ffc107;">
                                                            <style>
                                                                #sddsf td {
                                                                    border: 0px;
                                                                    color: #055837;
                                                                }
                                                            </style>
                                                            <table id="sddsf">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="width: 150px;">
                                                                            <b> Day &amp; Date / Time</b>
                                                                        </td>
                                                                        <td style="width: 20px;">
                                                                            :
                                                                        </td>
                                                                        <td>
                                                                            <!-- time 1  -->
                                                                            <?= date('l, jS F Y', $Interview_Schedule['tmsp']) ?> /
                                                                            <?= date('h:i A', $Interview_Schedule['tmsp']) ?>
                                                                            (Australia/Brisbane Time)
                                                                            <br>

                                                                            <!-- time 2  -->
                                                                            <?php
                                                                            if ($Interview_Schedule['venue'] != 'Australia/Brisbane') {
                                                                            ?>
                                                                                <?php
                                                                                if ($Interview_Schedule['tmsp']) {
                                                                                    $date = new DateTime(date('Y-m-d H:i:s', $Interview_Schedule['tmsp']));
                                                                                    $date->setTimezone(new DateTimeZone($Interview_Schedule['date_time_zone']));
                                                                                    echo  $date->format('l, jS F Y') . ' / ' . $date->format('h:i A');
                                                                                }
                                                                                ?>
                                                                                (<?= $Interview_Schedule['date_time_zone'] ?> Time)
                                                                            <?php } ?>

                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td>
                                                                            <b> Venue </b>
                                                                        </td>
                                                                        <td style="width: 20px;">
                                                                            :
                                                                        </td>
                                                                        <td>
                                                                            <?= $Interview_Schedule['venue'] ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <b> Location </b>
                                                                        </td>
                                                                        <td style="width: 20px;">
                                                                            :
                                                                        </td>
                                                                        <td>
                                                                            <?= $Interview_Schedule['office_address'] ?>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>

                                                </tr>

                                            </thead>
                                        </table>
                                    <?php } ?>
                                <?php } ?>
                            <?php   }   ?>
                        <?php   }   ?>
                        <?php if ($stage_index == 15 || $stage_index < 22) {  ?>

                            <!-- button  -->
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="row w-100 col-sm-12 " style="max-width:600px;">
                                    <!-- stage 3 start only  -->
                                    <div class="col-sm-12  mb-2">
                                        <div id="download_outcome_letter_3" class="">
                                            <a href="<?= base_url('user/stage_3/receipt_upload') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                                Start Stage 3 Submission
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php   }   ?>
                    </div>

                    <!-- stage 3 documents  -->
                    <div class="col-sm-6">

                        <div class="card">
                            <a class="btn p-0 collapsed" data-bs-toggle="collapse" href="#collapseOne">
                                <div class="card-header">

                                    <h4 class="text-green"><b> Uploaded Documents </b></h4>
                                </div>

                            </a>
                            <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th> Sr.No. </th>
                                                <th> Document Name </th>
                                                <!-- <td> Document </td> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 0;
                                            foreach ($documents as $key => $value) {
                                                if ($value['stage'] == "stage_3") {
                                                    if ($value['required_document_id'] > 0) {
                                                        $i++;
                                                        $required_document_id = $value['required_document_id'];

                                            ?>
                                                        <tr>
                                                            <td> <?= $i; ?> </td>
                                                            <td>
                                                                <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                    <?= $value['name']; ?>
                                                                </a>
                                                            </td>
                                                        </tr>
                                            <?php
                                                    } // required_document_id
                                                } // stage
                                            } // forech 
                                            ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                    </div>

                    <!-- stage 3 documents  -->
                    <!-- show stage 3 document -->
                    <!-- stage 3 Action Requad  -->
                </div>
            </div>
        <?php } ?>
    </div>

</div>

<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<!-- onready  -->
<script>
    var ENC_pointer_id = '<?= $ENC_pointer_id ?>';

    function add_info_req(stage) {
        // var stage = $(stage).val();
        var formData = new FormData($(id)[0]);
        console.log();
        return;
        console.log(stage);
        var id = '"#add_info_req_' + stage + '"';
        console.log(id);
        // creat alert box 
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to download all files?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
        // check Btn click
        $("#AJDSAKAJLD").click(function() {
            // if return true 
            if (custom_alert_popup_close('AJDSAKAJLD')) {
                // console.log("here");
                // return;
                // form = new formData();
                $.ajax({
                    url: "<?= base_url('user/additional_information_request') ?>/" + stage + '/' + ENC_pointer_id,
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {},
                    success: function(data) {
                        console.log(data);
                        window.location = data;
                    },
                });
            }
        })
    }
</script>
<?= $this->endSection() ?>