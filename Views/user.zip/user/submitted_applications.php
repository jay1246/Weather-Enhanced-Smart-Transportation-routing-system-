<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>


<!-- inner heading  -->
<div class=" bg-green text-white text-center">
    Submitted Applications
</div>

<!-- start -->
<div class="container mt-4 mb-4  ">
    <!-- center div  -->
    <div class=" p-2 bg-white shadow">

        <!-- Alert on set - Flashdata -->
        <?= $this->include("alert_box.php") ?>

        <table class="table" id="table">
            <thead>
                <tr>
                    <th scope="col"> Sr.No.</th>
                    <th scope="col">Applicant Name</th>
                    <th scope="col">D.O.B</th>
                    <th scope="col">Occupation</th>
                    <th scope="col">Date Created</th>
                    <th scope="col">Current Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>

            <tbody>

                <?php
                $i = 0;

                foreach ($table_data as $res) {
                    $i++;
                    $ENC_pointer_id = $res['ENC_pointer_id'];
                ?>
                    <tr>
                        <th scope="row">
                            <?= $i ?>
                        </th>
                        <td>
                            <?= $res['first_or_given_name'] ?> <?= $res['surname_family_name'] ?>
                        </td>
                        <td>
                            <?= $res['date_of_birth'] ?>
                        </td>
                        <td>
                            <?= $res['occupation'] ?>
                        </td>
                        <td>
                            <?= $res['created_at_format'] ?>
                            <!-- <?= $res['created_at'] ?> -->
                        </td>
                        <td>
                            <?= $res['status_format'] ?>
                        </td>
                        <td>

                            <a href="<?= base_url('user/view_application/' . $ENC_pointer_id) ?>" class="btn btn-sm btn_green_yellow ">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <!-- <a onclick="return confirm('Are you sure you want to delete this item?');" href="<?= base_url('user/incomplete_application_delete/' . $ENC_pointer_id) ?>" class="btn btn-sm btn-danger text-white">
                                    <i class="bi bi-trash-fill"></i>
                                </a> -->
                        </td>
                    </tr>
                <?php } ?>

            </tbody>
        </table>

    </div>
</div>


<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });
</script>
<?= $this->endSection() ?>