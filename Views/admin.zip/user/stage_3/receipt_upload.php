<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>
<style>
    label {
        margin-bottom: 0px !important;
        margin-bottom: 1px !important;
    }

    .Comments::placeholder {
        color: #e3e3e3;
    }
</style>

<!-- inner heading  -->
<div class="bg-green text-white text-center pt-1 pb-1" style="font-size: 120%;">

    <b> Stage 3 - Technical Interview </b>
</div>

<!-- start -->
<div class="container mt-4 mb-4">
    <div class="row">
        <div class="col-md-1"></div>

        <!-- center div  -->
        <div class="col-md-10 bg-white shadow pb-5">



            <!-- Alert on set - Flashdata -->
            <?= $this->include("alert_box.php") ?>
            <div class="mt-5" id="card_style">
                <div class="card-body" style="margin-left:10%">


                    <?php
                    if ($file_uploaded) {
                        $disabled = "disabled";
                    } else {
                        $disabled = "";
                    }
                    ?>

                    <form action="<?= base_url('user/stage_3/receipt_upload_action/' . $ENC_pointer_id) ?>" method="post" enctype="multipart/form-data" style="margin-left: 10%;" id="">
                        <b>Preferred Interview Location </b>
                        <select id="preference_location" class="form-select w-75" onchange="get_addresh(this.value)" name="preference_location">
                            <option value="" selected> Select Location</option>
                            <?php foreach ($location as $key => $value) {  ?>
                                <?php if ($key != "Online") {  ?>
                                    <optgroup label="<?= $key ?>">
                                        <?php foreach ($value as $key_ => $value_) {
                                            $selected = "";
                                            if ($preference_location == $value_['city_name']) {
                                                $selected = "selected";
                                            }  ?>

                                            <option value="<?= $value_['city_name'] ?>" <?= $selected ?>><?= $value_['city_name'] ?></option>
                                        <?php  }  ?>
                                    <?php  }  ?>
                                <?php  }  ?>
                        </select>
                        <div class="w-75 rounded mb-3" id="ads_auto"></div>
                        <b> Comments </b>
                        <textarea onchange="save_Preferred_info_()" id="preference_comment" class="Comments form-control w-75 mb-3" placeholder="Examples:
* Applicant is travelling from WA to the NSW centre, so he/she would need 2 weeks notice for the interview. 
* The applicant is currently away, kindly schedule the interview after DD/MM/YYYY." rows="6" class="form-control w-75 disabled__field" name="preference_comment"><?= $preference_comment ?></textarea>

                        <b> TRA Payment Receipt Number <span class="text-danger">*</span> </b>
                        <input type="number" <?= $disabled ?> autocomplete="off" value="<?= $receipt_number ?>" class="form-control w-75 disabled__field mb-3" name="recipt_number" id="receipt_no" required />

                        <b> Payment Date (dd/mm/yyyy) <span class="text-danger">*</span> </b>
                        <!-- <input type="date" class="form-control mb-3 w-75 datepicker  disabled__field" value="" name="payment_date" id="date1" placeholder="dd/mm/yyyy" required=""> <br> -->

                        <input type="text" <?= $disabled ?> autocomplete="off" class="form-control mb-4 w-75 datepicker" value="<?= $payment_date ?>" name="payment_date" id="date" placeholder="dd/mm/yyyy" maxlength="10" required="">

                        <div style="display: flex;">
                            <div class="col-sm-8">
                                <input type="file" <?= $disabled ?> class="form-control " name="recipt" id="file_receipt" required=""><br>
                            </div>
                            <div class="col-sm-4">
                                <button <?= $disabled ?> class="btn btn_green_yellow  float-start" style="padding-left:10px;padding-right:10px" id="" type="submit">Upload</button>
                            </div>
                        </div>
                        <?php if ($file_uploaded) { ?>
                            <div style="margin-top: -21px; margin-left: 119px;">
                                <a href="<?= base_url($document_path . '/' . $document_full_name); ?>">
                                    <?= $document_name ?>
                                </a>
                                <a href="<?= base_url('user/stage_3/receipt_upload_delete/' . $ENC_pointer_id) ?>" class="text-danger">
                                    <i class="bi bi-trash-fill"></i>
                                </a>
                            </div>
                        <?php } ?>

                    </form>
                </div>
            </div>



            <!-- -----------------table---------------- -->
            <?php if ($file_uploaded) { ?>
                <div class="mt-1" style="margin-left:10%">
                    <form onsubmit="return validateForm()" action="<?= base_url('user/stage_3/submit_/' . $ENC_pointer_id) ?>" method="post" id="s3_submit_stage">
                        <div class="form-check " style="margin-left:-30px;  margin-top: 30px;">
                            <input class="form-check-input" type="checkbox" id="all_check" required />
                            <label class="form-check-label" for="all_check">
                                I understand &amp; agree that once I submit the documents, I will not be able to remove or change these documents.
                            </label>
                        </div>


                        <a href="<?= base_url('user/view_application/' . $ENC_pointer_id) ?>" class="btn btn_yellow_green" style="margin-left:35%;" id="back_btn" onclick="history.back()"> Back</a>
                        <button type="submit" class="btn btn_green_yellow" style="margin-left:1%;">Submit</button>
                    </form>
                </div>
            <?php } ?>

        </div>

        <?php if (!$file_uploaded) { ?>
            <br>
            <br>
            <div class="mt-4" style="margin-left:10%">
                <a href="<?= base_url('user/view_application/' . $ENC_pointer_id) ?>" class="btn btn_yellow_green" style="margin-left:35%;     padding-left: 20px !important;
    padding-right: 20px !important;" id="back_btn" onclick="history.back()"> Back</a>
            </div>
            <br> <br>
            <br> <br>
            <br>
        <?php } ?>
    </div>
</div>
<style>
    #loader_img {
        position: fixed;
        left: 50%;
        top: 50%;
        pointer-events: none;
    }

    #cover-spin {
        position: fixed;
        width: 100%;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background-color: rgba(251, 251, 251, 0.6);
        z-index: 9999;
        display: none;
    }
</style>
<div id="cover-spin" style="display: none;">
    <div id="loader_img">
        <img src="https://attc.aqato.com.au/public/assets/image/admin/loader.gif" style="width: 100px; height:auto">
    </div>
</div>
<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    function validateForm() {

        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to submit stage 3 Application?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
        // check Btn click
        $("#AJDSAKAJLD").click(function() {
            // if return true 
            if (custom_alert_popup_close('AJDSAKAJLD')) {
                $('#cover-spin').show(0);
                return true;
            } else {
                $('#cover-spin').hide(0);
                return false;

            }
        });

    }


    //on change
    function get_addresh(value) {

        $('#ads_auto').html('');
        $.ajax({
            'url': '<?= base_url('user/stage_3/get_addresh_') ?>',
            'type': 'post',
            'data': {
                'city_name': value,
            },
            success: function(data) {
                if (value != "") {
                    data = JSON.parse(data);
                    html = '<div class="row"> <div class="col-3"><b>Venue :</b> </div> <div class="col-9"> ' + data['venue'] + '</div>  <div class="col-3"><b> Address : </b> </div>  <div class="col-9">  ' + data['office_address'] + '</div></div><br> <b >  Are you sure you want to choose the above venue for the technical interview ? </b>  ';
                    custom_alert_popup_show(header = '', html, close_btn_text = 'Cancel', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Confirm', other_btn_class = 'btn-success', other_btn_id = 'ouiouhasdasd');
                    $("#ouiouhasdasd").click(function() {
                        if (custom_alert_popup_close('ouiouhasdasd')) {
                            $('#ads_auto').html('<div class="mt-3 p-2" style="background-color:#ffc107;border-radius:5px" > <b> Address : </b> <br>' + data['office_address'] + '</div>');
                            save_Preferred_info_();

                        }
                    });
                } else {
                    save_Preferred_info_();

                }
            }

        });
    }

    // save on change 
    function save_Preferred_info_() {
        $.ajax({
            'url': '<?= base_url('user/stage_3/save_Preferred_info_/' . $ENC_pointer_id) ?>',
            'type': 'post',
            'data': {
                'preference_location': $('#preference_location').val(),
                'preference_comment': $('#preference_comment').val(),
            },
            success: function(data) {
                console.log("---------------------------" + data);
            }
        });
    }

    // on load page check old data
    <?php if (isset($preference_location) && !empty($preference_location)) { ?>
        $('#ads_auto').html('');
        $.ajax({
            'url': '<?= base_url('user/stage_3/get_addresh_') ?>',
            'type': 'post',
            'data': {
                'city_name': '<?= $preference_location ?>',
            },
            success: function(data) {
                data = JSON.parse(data);
                $('#ads_auto').html('<div class="mt-3 p-2" style="background-color:#ffc107;border-radius:5px" > <b> Address : </b> <br>' + data['office_address'] + '</div>');
            }
        });
    <?php } ?>




    $(".datepicker").datepicker({
        dateFormat: "dd/mm/yy",
        maxDate: new Date()
    });
</script>

<?= $this->endSection() ?>