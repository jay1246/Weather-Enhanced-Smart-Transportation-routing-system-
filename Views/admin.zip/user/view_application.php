<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>


<!-- inner heading  -->
<div class="bg-green text-white text-center pt-1 pb-1" style="font-size: 18px;">
    <b> Application Details </b>
</div>


<style>
    .arrow {
        border-radius: 0px !important;
        clip-path: polygon(93% 0, 100% 50%, 93% 100%, 0% 100%, 6% 50%, 0% 0%);
    }

    a.active {
        background-color: var(--yellow) !important;
        color: var(--green) !important;
    }

    .active {
        border: 1px solid var(--yellow) !important;

    }

    .staper_btn {
        max-width: 100%;
    }


    .mm {
        color: #055837;
        padding: 3px;
        border: 3px solid #fecc00;
        border-radius: 25px;
    }

    input[readonly] {
        background-color: #ebebeb;
    }
</style>


<!-- start body  -->
<div class="container-fluid mt-4 mb-4 p-4 bg-white shadow">
    <!-- View Submitted Application  -->
    <div class="row">
        <div class="col-sm-6">
            <!-- <h2 class="text-green"></h2> -->

            <table class="table">
                <tr>
                    <td>
                        <b>
                            <span data-bs-toggle="tooltip" data-bs-placement="top" title="Portal Reference No.">
                                PRN
                            </span>
                        </b>
                    </td>
                    <td>
                        <?= $portal_reference_no ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Application No. </b>
                    </td>
                    <td>
                        <?= $Unique_number ?>
                    </td>
                </tr>



                <tr>
                    <td>
                        <b> Applicant's Name </b>
                    </td>
                    <td>
                        <?= $Application_Details['name'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Occupation </b>
                    </td>
                    <td>
                        <?= $Application_Details['occupation'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Pathway </b>
                    </td>
                    <td>
                        <?= $Application_Details['pathway'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Program </b>
                    </td>
                    <td>
                        <?= $Application_Details['program'] ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-sm-6 d-flex align-items-center justify-content-center">
            <?php
            $show_img = false;
            $pic_full_url = "";
            $path = "";
            foreach ($documents as $key => $value) {
                if ($value['stage'] == "stage_1") {
                    if ($value['required_document_id'] == 1) {
                        $path = $value['document_path'] . "/" . $value['document_name'];
                        $pic_full_url = base_url($value['document_path'] . "/" . $value['document_name']);
                        if (file_exists($path)) {
                            $show_img = true;
                        } else {
                            $show_img = false;
                        }
                    }
                }
            }
            ?>

            <?php if ($show_img) {
                $image_info = getimagesize($path);
                if ($image_info !== false) { ?>
                    <img src="<?= $pic_full_url ?>" width="150px" height="170px" class="shadow">
                <?php } else {  ?>
                    <img src="https://cdn-icons-png.flaticon.com/512/180/180658.png" width="170px" height="170px" class="shadow">
                <?php } ?>
            <?php } else { ?>
                <img src="https://cdn-icons-png.flaticon.com/512/180/180658.png" width="170px" height="170px" class="shadow">
            <?php } ?>

        </div>
    </div>


    <?php
    $stage_2_have_docs = false;
    $stage_3_have_docs = false;
    foreach ($documents as $key => $value) {
        if ($value['stage'] == "stage_2") {
            $stage_2_have_docs = true;
        }
        if ($value['stage'] == "stage_3") {
            $stage_3_have_docs = true;
        }
    }

    $s1_active = "disabled";
    $s1_selected = "false";
    $s1_show = "Q";

    $s2_active = "disabled";
    $s2_selected = "false";
    $s2_show = "Q";

    $s3_active = "disabled";
    $s3_selected = "false";
    $s3_show = "Q";

    // stage 1 
    if ($stage_index >= 2) {
        if ($is_active == "stage_1" || !$is_employe_add) {
            $s1_active = "active";
            $s1_selected = "true";
            $s1_show = "show active";
        }
    }


    // stage 2 
    if ($is_employe_add) {  // continu stage 2
        if ($stage_index == 5 || $stage_index >= 11) {
            if ($is_active == "stage_2" || !$stage_3_have_docs) {
                $s1_active = "";
                $s1_show = "asdsad";

                $s2_active = "active";
                $s2_selected = "true";
                $s2_show = "show active";
            }
        }
    }



    if ($stage_3_have_docs) {
        if ($stage_index == 15 || ($stage_index >= 21)) {
            if ($is_active == "stage_3") {
                $s1_active = "";
                $s1_show = "asdsad";

                $s2_active = "";
                $s2_show = "asdsad";

                $s3_active = "active";
                $s3_selected = "true";
                $s3_show = "show active";
            }
        }
    }

    ?>


    <!-- all stage Stapper Button  -->
    <!-- <?= $stage_index ?> -->
    <div class="row nav nav-tabs" id="nav-tab" role="tablist">
        <?php if (!empty($s1_show)) { ?>
            <a href="" type="button" class=" staper_btn  <?= $s1_active ?> col-sm btn arrow bg-green text-yellow" id="stage_1-tab" data-bs-toggle="tab" data-bs-target="#stage_1" role="tab" aria-controls="stage_1" aria-selected="<?= $s1_selected ?>">
                Stage 1 - Self Assessment
            </a>
        <?php } ?>

        <?php if (!empty($s2_show)) { ?>
            <a href="" type="button" class="  staper_btn <?= $s2_active ?> col-sm btn arrow bg-green text-yellow" id="stage_2-tab" data-bs-toggle="tab" data-bs-target="#stage_2" role="tab" aria-controls="stage_2" aria-selected="<?= $s2_selected ?>">
                Stage 2 - Documentry Evidence
            </a>
        <?php } ?>

        <a href="" type="button" class="staper_btn <?= $s3_active ?> col-sm btn arrow bg-green text-yellow" id="stage_3-tab" data-bs-toggle="tab" data-bs-target="#stage_3" role="tab" aria-controls="stage_3" aria-selected="<?= $s3_selected ?>">
            Stage 3 -Technical Interview
        </a>
    </div>



    <!-- stage 1 TO stage 3  data  -->
    <div class="tab-content" id="nav-tabContent">

        <?php
        $show_Additional_Information_Request = false;
        foreach ($additional_info_request as $key_1 => $value_1) {
            $stage = $value_1['stage'];
            $status = $value_1['status'];
            if ($stage == "stage_1" && $status == "send") {
                $show_Additional_Information_Request = true;
            }
        }
        ?>


        <!-- stage 1  -->
        <?php if (!empty($s1_show)) { ?>
            <div class="tab-pane fade <?= $s1_show ?>  bg-white shadow- p-3" id="stage_1" role="tabpanel" aria-labelledby="stage_1-tab">
                <!-- 25-04-2023 vishal patel  -->
                <?php
                if (isset($stage_1['approved_date']) && !empty($stage_1['approved_date']) && $stage_1['approved_date'] != "0000-00-00 00:00:00" && $stage_1['approved_date'] != null) {
                    $Expired_date =  date('Y-m-d', strtotime('+60 days', strtotime($stage_1['approved_date'])));
                    $expiry_date_temp = strtotime($Expired_date);
                    $todays_date = strtotime(date('Y-m-d'));
                    $timeleft = $todays_date - $expiry_date_temp;
                    $day_remain = round((($timeleft / 86400)));
                } else {
                    $day_remain = -40;
                }

                ?>
                <div class="row mt-3">

                    <!-- left  -->
                    <div class="col-sm-6">

                        <table class="table">
                            <thead>
                                <!-- Submitted  -->
                                <?php if (isset($stage_1['status']) && !empty($stage_1['status'])) { ?>
                                    <tr>
                                        <th>
                                            Status
                                        </th>
                                        <td>
                                            <b>
                                                <?php    // <!-- 25-04-2023 vishal patel  -->
                                                if ($stage_1['status'] != "Expired") {
                                                    echo $stage_1['status'];
                                                } else {
                                                    if ($day_remain >= 0) {
                                                        echo "Closed";
                                                    } else {
                                                        echo $stage_1['status'];
                                                    }
                                                }
                                                ?>

                                            </b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>
                                            Date Submitted
                                        </th>
                                        <td>
                                            <?php
                                            if (!empty($stage_1['submitted_date']) && $stage_1['submitted_date'] != "0000-00-00 00:00:00" && $stage_1['submitted_date'] != null) {
                                                echo date("d/m/Y", strtotime($stage_1['submitted_date']));
                                            } ?>
                                        </td>
                                    </tr>
                                <?php } ?>




                                <!-- Lodged  date  -->
                                <?php //if (isset($stage_1['lodged_date']) && !empty($stage_1['lodged_date'])) { 
                                ?>
                                <!--    <tr>-->
                                <!--        <th>-->
                                <!--            Date Lodged-->
                                <!--        </th>-->
                                <!--        <td>-->
                                <?php
                                //if (!empty($stage_1['lodged_date']) && $stage_1['lodged_date'] != "0000-00-00 00:00:00" && $stage_1['lodged_date'] != null) {
                                //  echo date("d/m/Y", strtotime($stage_1['lodged_date']));
                                // } 
                                ?>
                                <!--        </td>-->
                                <!--    </tr>-->
                                <?php // } 
                                ?>
                                <?php //if (isset($stage_1['status']) && $stage_1['status'] == "Lodged") { 
                                ?>

                                <?php //} 
                                ?>


                                <!-- In Progress  date  -->
                                <?php //if (isset($stage_1['in_progress_date']) && !empty($stage_1['in_progress_date'])) { 
                                ?>
                                <!--    <tr>-->
                                <!--        <th>-->
                                <!--            Date In Progress-->
                                <!--        </th>-->
                                <!--        <td>-->
                                <!--            <?php
                                                //if (!empty($stage_1['in_progress_date']) && $stage_1['in_progress_date'] != "0000-00-00 00:00:00" && $stage_1['in_progress_date'] != null) {
                                                // echo date("d/m/Y", strtotime($stage_1['in_progress_date']));
                                                // } 
                                                ?>
                                <!--        </td>-->
                                <!--    </tr>-->
                                <?php //} 
                                ?>
                                <?php //if (isset($stage_1['status']) && $stage_1['status'] == "In Progress") { 
                                ?>

                                <?php //} 
                                ?>

                                <!-- Approved  date -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Approved") {  ?>
                                <?php } ?>

                                <?php if (isset($stage_1['approved_date'])) {
                                    if (!empty($stage_1['approved_date']) && $stage_1['approved_date'] != "0000-00-00 00:00:00" && $stage_1['approved_date'] != null) {
                                ?>
                                        <tr>
                                            <th>
                                                Date Approved
                                            </th>
                                            <td>
                                                <?php
                                                if (!empty($stage_1['approved_date']) && $stage_1['approved_date'] != "0000-00-00 00:00:00" && $stage_1['approved_date'] != null) {
                                                    echo date("d/m/Y", strtotime($stage_1['approved_date']));
                                                } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Decline  date / Reason -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Declined") { ?>
                                    <?php if (isset($stage_1['declined_date']) && !empty($stage_1['declined_date'])) {
                                        if (!empty($stage_1['declined_date']) && $stage_1['declined_date'] != "0000-00-00 00:00:00" && $stage_1['declined_date'] != null) { ?>
                                            <tr>
                                                <th>
                                                    Date Declined
                                                </th>
                                                <td>
                                                    <?php
                                                    if (!empty($stage_1['declined_date']) && $stage_1['declined_date'] != "0000-00-00 00:00:00" && $stage_1['declined_date'] != null) {
                                                        echo date("d/m/Y", strtotime($stage_1['declined_date']));
                                                    } ?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                    <?php if (isset($stage_1['declined_reason']) && !empty($stage_1['declined_reason']) && strlen($stage_1['declined_reason']) > 2) { ?>
                                        <tr>
                                            <th>
                                                Reason 
                                            </th>
                                            <td>
                                                <?= $stage_1['declined_reason'] ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Withdrawn  date  -->
                                <?php if (isset($stage_1['status']) && $stage_1['status'] == "Withdrawn") { ?>
                                    <?php if (isset($stage_1['withdraw_date']) && !empty($stage_1['withdraw_date'])) {
                                        if (!empty($stage_1['withdraw_date']) && $stage_1['withdraw_date'] != "0000-00-00 00:00:00" && $stage_1['withdraw_date'] != null) {
                                    ?>
                                            <tr>
                                                <th>
                                                    Date Withdrawn
                                                </th>
                                                <td>
                                                    <?php
                                                    if (!empty($stage_1['withdraw_date']) && $stage_1['withdraw_date'] != "0000-00-00 00:00:00" && $stage_1['withdraw_date'] != null) {
                                                        echo date("d/m/Y", strtotime($stage_1['withdraw_date']));
                                                    } ?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>


                                <!-- Expiry Date --> <!-- 25-04-2023 vishal patel  -->
                                <?php if ($stage_index < 12) {  ?>
                                    <?php
                                    // $expiry_date_temp = strtotime($stage_1['expiry_date']);
                                    $expiry_date_temp = strtotime(date('Y-m-d'));
                                    $approved_date_temp = strtotime($stage_1['approved_date']);
                                    $timeleft = $expiry_date_temp - $approved_date_temp;
                                    $day_remain_ = round((($timeleft / 86400))); // <!-- 25-04-2023 vishal patel  -->
                                    $day_remain_ = 29 - $day_remain_;
                                    ?>
                                    <?php if ($stage_1['status'] != "Expired") { ?>
                                        <?php if (isset($stage_1['status']) && $stage_1['status'] == "Approved" || $stage_1['status'] == "Archive" || $stage_1['status'] == "Expired") { ?>
                                            <?php if (isset($stage_1['expiry_date']) && !empty($stage_1['expiry_date'])) { ?>
                                                <?php if (!empty($stage_1['expiry_date']) && $stage_1['expiry_date'] != "0000-00-00 00:00:00" && $stage_1['expiry_date'] != null) { ?>
                                                    <?php if ($day_remain < -30) { ?>
                                                        <tr>
                                                            <th>
                                                                Expiry Date
                                                            </th>
                                                            <td> <!-- 25-04-2023 vishal patel  -->
                                                                <?= date('d/m/Y', strtotime('+30 days', strtotime($stage_1['approved_date'])));  ?>
                                                                <span class="text-danger"> (<?= $day_remain_ ?> Days Left) </span>
                                                            </td>
                                                        </tr>
                                                    <?php } ?>

                                                <?php } ?>
                                            <?php } ?>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <tr>
                                            <th> <!-- 25-04-2023 vishal patel  -->
                                                Date
                                                <?php
                                                if ($day_remain >= 0) {
                                                    echo "Closed";
                                                } else  if ($day_remain > -30 && $day_remain < 0) {
                                                    echo "Expired";
                                                } else {
                                                    echo "Expired";
                                                }
                                                ?>
                                            </th>
                                            <td> <!-- 25-04-2023 vishal patel  -->
                                                <?= date('d/m/Y', strtotime('+30 days', strtotime($stage_1['approved_date'])));  ?>
                                            </td>
                                        </tr>

                                    <?php } ?>

                                    <!--  Archive / Expired-->
                                    <?php if (isset($stage_1['status']) && $stage_1['status'] == "Archive" || $stage_1['status'] == "Expired") { ?>

                                        <?php if ($day_remain >= -30  && $day_remain < 0) { ?> <!-- 25-04-2023 vishal patel  -->
                                            <tr>
                                                <td colspan="2">
                                                    <div class="p-2 bg-yellow rounded">
                                                        Kindly reach out on
                                                        <b><a href="mail:dilpreet.bagga@attc.org.au">dilpreet.bagga@attc.org.au</a></b>
                                                        or +61-401200991 to re-instate the application. The applications can only be re-instated within 60 days from the date of Stage 1 approval,
                                                        conditional to the applicant still meeting the eligibility requirements.
                                                    </div>
                                                </td>
                                            </tr>

                                        <?php } ?>

                                        <?php if ($day_remain >= 0) { ?> <!-- 25-04-2023 vishal patel  -->
                                            <tr>
                                                <td colspan="2">
                                                    <div class="p-2 bg-yellow rounded">
                                                        As the Stage 2 was not submitted within 60 days from the date of Stage 1 approval,
                                                        this application has now been closed. Please feel free to lodge a new application.
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                    <?php } ?>

                                <?php } ?>





                                <?php if (!$show_Additional_Information_Request) { ?>
                                    <!-- stage 2 start alert box  -->
                                    <?php if (isset($stage_1['status']) && $stage_1['status'] == "Submitted" || $stage_1['status'] == "Lodged" ||  $stage_1['status'] == "In Progress") { ?>
                                        <tr>
                                            <td colspan="2">
                                                <div class="p-2 bg-yellow text-green rounded">
                                                    We shall contact you if any further documentation is required. In the meantime you may want to start preparing your stage 2 documentation.
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>



                            </thead>
                        </table>

                        <!-- Download Application Form Button  -->
                        <div class="col-sm-12">
                            <!-- <div class="bg-yellow rounded p-2">
                                We shall contact you if any further documentation is required. In the meantime you may want to start preparing your stage 2 documentation. Kindly download the Stage 2 document checklist below.
                            </div> -->
                            <div class="row">
                                <div class="col-sm-6 p-3">
                                    <a href="<?= $TRA_Application_Form_url ?> " class="btn btn_green_yellow w-100" download> Download Application Form <i class="bi bi-download"></i> </a>
                                </div>
                                <?php if (isset($stage_1['status']) && $stage_1['status'] != "Declined" && $stage_1['status'] != "Expired" && $stage_1['status'] != "Withdrawn") { ?>

                                    <div class="col-sm-6 p-3">
                                        <a href="<?= base_url('/public/assets/PDF/Stage%202%20Applicant%20Checklist.pdf') ?>" class="btn btn_green_yellow w-100" download>Download Stage 2 Checklist <i class="bi bi-download "></i></a>
                                    </div>

                                <?php } ?>
                                <?php if (isset($stage_1['status']) && $stage_1['status'] != "Declined" && $stage_1['status'] != "Expired" && $stage_1['status'] != "Withdrawn") { ?>
                                    <?php if (isset($Application_Details['pathway']) && $Application_Details['pathway'] == "Pathway 1") { ?>
                                        <?php if (isset($stage_2_application_kit) && $stage_2_application_kit['application_kit_file_available']) { ?>
                                            <div class="col-sm-12 p-3">

                                                <a href="<?php if (isset($stage_2_application_kit['File_full_path'])) {
                                                                echo base_url($stage_2_application_kit['File_full_path']);
                                                            } ?>" class="btn btn_green_yellow w-100" download="<?php if (isset($stage_2_application_kit['name'])) {
                                                                                                                    echo $stage_2_application_kit['name'];
                                                                                                                } ?>">Download Applicant Kit <i class="bi bi-download"></i> </a>
                                            </div>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>
                                <?php if ($stage_index == 5) {  ?>

                                <?php } ?>
                            </div>
                        </div>

                        <!-- stage 2 start button in stage 1 -->
                        <?php if ($stage_index == 11 || $stage_index == 5) { ?>
                            <?php if (!$is_employe_add) { ?>
                                <div class="row mb-2">
                                    <!-- <h2> Start Documentry Evidence </h2> -->
                                    <!-- <div class="col-sm-6 mb-2">
                                        <a href="<?= base_url('public/assets/PDF/Stage%202%20Applicant%20Checklist.pdf') ?>" class="btn btn_green_yellow w-100" download="">Download Stage 2 Checklist <i class="bi bi-download "></i></a>
                                    </div>
                                    <div class="col-sm-6 mb-2">
                                        <?php if (isset($stage_2_application_kit) && $stage_2_application_kit['application_kit_file_available']) { ?>
                                            <a href="<?php if (isset($stage_2_application_kit['File_full_path'])) {
                                                            echo base_url($stage_2_application_kit['File_full_path']);
                                                        } ?>" class="btn btn_green_yellow w-100" download="<?php if (isset($stage_2_application_kit['name'])) {
                                                                                                                echo $stage_2_application_kit['name'];
                                                                                                            } ?>">Download Applicant Kit <i class="bi bi-download"></i> </a>
                                        <?php } ?>
                                    </div> -->

                                    <div class=" col-sm-12 mb-2">
                                        <a href="<?= base_url('user/stage_2/add_employment') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                            Start Stage 2 Submission
                                        </a>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>

                    </div>

                    <!-- stage 1 documents  -->
                    <div class="col-sm-6">

                        <!-- main parent DIV  -->
                        <div class="accordion" id="accordionExample">
                            <!-- comman container for 1 item  -->
                            <div class="accordion-item">
                                <!-- Clickebal Button  -->
                                <h2 class="accordion-header" id="s1_tital_div">
                                    <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;font-size:18px !important " type="button" data-bs-toggle="collapse" data-bs-target="#s1_tital_body_div" aria-expanded="false" aria-controls="s1_tital_body_div">
                                        <h5 class="text-green" style="font-size:18px"><b> Submitted Documents </b></h5>
                                    </button>
                                </h2>
                                <!-- collapseabal Div show all data / collapse Body  -->
                                <div id="s1_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s1_tital_div" data-bs-parent="#accordionExample" style="overflow-y: scroll; height:400px;">
                                    <div class="card-body">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th> Sr.No. </th>
                                                    <th> Document Name </th>
                                                    <!-- <td> Document </td> -->
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 0;
                                                foreach ($documents as $key => $value) {
                                                    if ($value['stage'] == "stage_1") {
                                                        if ($value['required_document_id'] > 0 && $value['required_document_id'] != 21) {
                                                            $i++;
                                                            $required_document_id = $value['required_document_id'];

                                                ?>
                                                            <tr>
                                                                <td> <?= $i; ?> </td>
                                                                <td>
                                                                    <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                        <?= $value['name']; ?>
                                                                    </a>
                                                                </td>
                                                                <!-- <td> <img src="<?= base_url($value['document_path'] . '/' . $value['document_name']) ?>" width="150px"> </td> -->
                                                            </tr>
                                                <?php
                                                        } // required_document_id
                                                    } // stage
                                                } // forech 
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <!-- stage 1 Action Requad  -->
                    <?php if ($stage_index >= 2 && $stage_index <= 5) {  ?>

                        <?php if ($show_Additional_Information_Request) {

                        ?>
                            <!-- stage 1  -->
                            <div class="col-sm-12 mm">

                                <h2 class="text-green"><b>Action Required</b></h2>
                                <form action="<?= base_url('user/additional_information_request/stage_1/' . $ENC_pointer_id) ?>" id="add_info_req_stage_1" method="post" enctype="multipart/form-data">
                                    <table class="table table-striped table-hover ">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">Sr.No.</th>
                                                <th style="width: 45%;">Comment</th>
                                                <th style="width: 25%;">Document Name</th>
                                                <th style="width: 25%;">Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $i = 1;

                                        foreach ($additional_info_request as $key => $value) {
                                            $pointer_id = $value['pointer_id'];
                                            $document_id = $value['document_id'];
                                            $stage = $value['stage'];
                                            $reason = $value['reason'];
                                            $status = $value['status'];
                                            $update_date = $value['update_date'];
                                            if ($stage == "stage_1" && $status == "send") {
                                                $doc_info = documents_info($pointer_id, $document_id);
                                                // if (!empty($doc_info)) {
                                                // echo "jfgj";
                                                if (isset($doc_info['required_document_id'])) {
                                                    $doc_required_document_id = $doc_info['required_document_id'];
                                                } else {
                                                    $doc_required_document_id = "";
                                                }
                                                if ($doc_info) {
                                                    $doc_id = $doc_info['id'];
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"  value="' . $doc_info['name'] . '" readonly>';
                                                } else {
                                                    $doc_id = '';
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"   required>';
                                                }

                                        ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <td><?= $reason ?></td>
                                                    <td><?= $doc_name ?></td>
                                                    <td>
                                                        <input type="file" class="form-control" name="file[]" accept="" required />

                                                        <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                        <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                        <input type="hidden" name="document_id[]" value="<?= $doc_id ?>">
                                                        <input type="hidden" name="stage" value="stage_1">

                                                    </td>
                                                </tr>
                                        <?php

                                                $i++;
                                            } // if stage_1
                                        } // forech
                                        ?>
                                    </table>
                                    <div class="mb-3 text-center">
                                        <!-- <button type="button" class="btn btn_green_yellow" onclick="add_info_req('stage_1')">upload</button> -->
                                        <button type="submit" c class="btn btn_green_yellow add_info_req_upload" onclick="add_info_req('stage_1')">Submit Additional Information</button>
                                    </div>
                                </form>
                            </div>
                        <?php } ?>

                    <?php } ?>
                    <!-- stage 1 Action Requad  -->

                </div>
            </div>
        <?php  }  ?>
        <!-- stage 1  -->

        <!-- stage 2  -->
        <?php if (!empty($s2_show)) { ?>

            <div class="tab-pane fade <?= $s2_show ?> bg-white shadow p-3" id="stage_2" role="tabpanel" aria-labelledby="stage_2-tab">
                <div class="row mt-3">


                    <!--stage 2  status info  and button -->
                    <div class="col-sm-6">

                        <!-- info table  -->
                        <table class="table <?= (isset($stage_2) && empty($stage_2)) ? "d-none " : ""; ?>">
                            <thead>


                                <?php if (isset($stage_2['status']) && !empty($stage_2['status'])) { ?>
                                    <?php if ($stage_2['status'] == "Start") { ?>
                                        <?php if (isset($stage_1['status']) && $stage_1['status'] == "Approved" || $stage_1['status'] == "Archive") { ?>
                                            <?php if (isset($stage_1['expiry_date']) && !empty($stage_1['expiry_date'])) { ?>


                                                <?php
                                                // $expiry_date_temp = strtotime($stage_1['expiry_date']);
                                                $expiry_date_temp = strtotime(date('Y-m-d'));
                                                // $expiry_date_temp = strtotime(date('Y-m-d', strtotime('+30 days', strtotime($stage_1['approved_date']))));
                                                $approved_date_temp = strtotime($stage_1['approved_date']);

                                                $timeleft = $expiry_date_temp - $approved_date_temp;
                                                $day_remain_ = round((($timeleft / 86400)));
                                                $day_remain_ = 30 - $day_remain_;
                                                ?>
                                                <?php if ($day_remain != 0 && $day_remain > 0) { ?>
                                                    <tr>
                                                        <th>
                                                            Expiry Date
                                                        </th>
                                                        <td>
                                                            <?= date('d/m/Y', strtotime('-30 days', strtotime($stage_1['expiry_date'])));  ?>
                                                            <span class="text-danger"> (<?= $day_remain_ ?> Days Left) </span>
                                                        </td>
                                                    </tr>
                                                <?php } ?>

                                            <?php } ?>
                                        <?php } ?>
                                        <?php if (isset($stage_1['status']) && $stage_1['status'] == "Archive") { ?>
                                            <!-- Date Archive  -->
                                            <?php if (isset($stage_1['archive_date']) && !empty($stage_1['archive_date'])) { ?>
                                                <tr>
                                                    <th>
                                                        Date Archive
                                                    </th>
                                                    <td>
                                                        <?= $stage_1['archive_date'] ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>

                                            <!-- Archive yellow alert box  -->
                                            <tr>
                                                <td colspan="2">
                                                    <div class="p-2 bg-yellow rounded">
                                                        Kindly reach out on <b><a href="tel:+61-401200991">+61-401200991</a></b> or
                                                        email to <b><a href="mail:dilpreet.bagga@attc.org.au">dilpreet.bagga@attc.org.au</a></b>
                                                        to re-instate the application. The applications can only be re-instated within
                                                        60 days from the date of Stage 1 approval, conditional to the applicant still
                                                        meeting the eligibility requirements.
                                                    </div>
                                                </td>
                                            </tr>

                                        <?php } ?>
                                    <?php } ?>

                                    <!-- stage 2  status  start-->
                                <?php } ?>
                                <!-- stage 2 status -->

                                <!-- Employment Verification  true and false--> <!-- 25-04-2023 Vishal Patel  -->
                                <?php
                                $show_Employment_Verification = false;
                                $status_of_varification = "Pending";
                                $checck_panding = 0;
                                $checck_complated = 0;
                                $total = 0;

                                if (isset($stage_2['status']) && $stage_2['status'] == "Submitted") {
                                    // print_r($email_verification);

                                    foreach ($email_verification as $key => $value) {
                                        $total++;
                                        // echo "<pre>";
                                        // print_r($email_verification);
                                        // echo "</pre>";
                                        if ($value['verification_type'] == "Verification - Employment" || $value['verification_type'] == "Verification Email - Employment") {
                                            $verification_email_id = $value['verification_email_id'];
                                            $employer_id = $value['employer_id'];
                                            $is_verification_done = $value['is_verification_done'];

                                            if ($is_verification_done == 0) {
                                                $checck_panding++;
                                            } else {
                                                $checck_complated++;
                                            }
                                            $show_Employment_Verification = true;
                                        }
                                        // break; <!-- 25-04-2023 Vishal Patel  -->
                                    }
                                    if ($checck_panding == 0) {
                                        $status_of_varification = "Completed";
                                    } else {
                                        $status_of_varification = "Pending";
                                    }
                                } ?>


                                <?php if (isset($stage_2['status']) && !empty($stage_2['status'])) { ?>
                                    <?php if ($stage_2['status'] != "Start") { ?>
                                        <tr>
                                            <th>
                                                Status
                                            </th>
                                            <td>
                                                <?php if ($show_Employment_Verification) { ?>
                                                    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
                                                        <div class="modal-dialog modal-xl modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalToggleLabel">
                                                                        Employment Verification
                                                                    </h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">

                                                                    <table style=" border: none !important; margin-top: 0px !important; font-size:90%" class="table">
                                                                        <tbody>
                                                                            <tr style="border: none !important;" class="bg-green text-white">
                                                                                <th scope="col" style="width: 5;"> Sr.No. </th>
                                                                                <th scope="col" style="width: 25;"> Referee Name </th>
                                                                                <th scope="col" style="width: 30;"> Referee Email </th>
                                                                                <th scope="col" style="width: 30;"> Company/Organisation </th>
                                                                                <th scope="col" style="width: 10;"> Status </th>
                                                                            </tr>
                                                                            <?php
                                                                            $count = 0;

                                                                            foreach ($email_verification as $key => $value) {
                                                                                if ($value['verification_type'] == "Verification - Employment" || $value['verification_type'] == "Verification Email - Employment") {

                                                                                    // if ($value['verification_type'] == "Verification Email - Employment") {
                                                                                    $verification_email_id = $value['verification_email_id'];
                                                                                    $employer_id = $value['employer_id'];
                                                                                    $is_verification_done = $value['is_verification_done'];

                                                                                    if ($is_verification_done == 1) {
                                                                                        $status = "Verified";
                                                                                        $status = '<span class="bg-green text-white p-2 rounded">' . $status . ' </span>';
                                                                                    } else {
                                                                                        $status = "Pending";
                                                                                        $status = '<span class="bg-yellow text-black p-2 rounded">' . $status . ' </span>';
                                                                                    }

                                                                                    $stage_2_add_employment = find_one_row('stage_2_add_employment', 'id', $employer_id);


                                                                                    $count++; ?>

                                                                                    <tr>
                                                                                        <td style=" border: none !important; margin-top: 0px !important;"> <?= $count ?>
                                                                                        </td>
                                                                                        <td style=" border: none !important; margin-top: 0px !important;"> <?= (isset($stage_2_add_employment->referee_name) ? $stage_2_add_employment->referee_name : "") ?></td>
                                                                                        <td style=" border: none !important; margin-top: 0px !important;"> <?= $verification_email_id ?></td>
                                                                                        <td style=" border: none !important; margin-top: 0px !important;"><?= (isset($stage_2_add_employment->company_organisation_name) ? $stage_2_add_employment->company_organisation_name : "") ?></td>
                                                                                        <td style=" border: none !important; margin-top: 0px !important;  ">
                                                                                            <span class="bg-yellow text-black"> <b><?= $status ?></b> </span>
                                                                                        </td>
                                                                                    </tr>
                                                                                <?php } ?>
                                                                            <?php } ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>

                                                    <a class="text-black" data-bs-toggle="modal" href="#exampleModalToggle" role="button">
                                                        Employment Verification (<?= $status_of_varification ?>) <!-- 25-04-2023 Vishal Patel -->
                                                        <img id="myImage" src="<?= base_url('public/assets/icon/new_popup_.png') ?>" width="40px" style="padding-left: 10px;" onmouseover="hoverImage()" onmouseout="originalImage()">
                                                    </a>

                                                <?php } else { ?>
                                                   <b> <?= $stage_2['status'] ?></b>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>
                                                Date Submitted
                                            </th>
                                            <td>
                                                <?= date("d/m/Y", strtotime($stage_2['submitted_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <?php if ($show_Employment_Verification) { ?>
                                    <tr>
                                        <td colspan="2">


                                        </td>
                                    </tr>
                                <?php } ?>

                                <?php if ($show_Employment_Verification) { ?>
                                    <!-- </div>
                                    </div> -->
                                <?php } ?>




                                <!-- Approved  date -->
                                <?php if (isset($stage_2['approved_date']) && !empty($stage_2['approved_date'])) { ?>
                                    <tr>
                                        <th>
                                            Date Approved
                                        </th>
                                        <td>
                                            <?= date("d/m/Y", strtotime($stage_2['approved_date'])) ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Approved") { ?>

                                <?php } ?>

                                <!-- Decline  date / Reason -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Declined") { ?>
                                    <?php if (isset($stage_2['declined_date']) && !empty($stage_2['declined_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Declined
                                            </th>
                                            <td>
                                                <?= date("d/m/Y", strtotime($stage_2['declined_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <?php if (isset($stage_2['declined_reason']) && !empty($stage_2['declined_reason']) && strlen($stage_2['declined_reason']) > 2) { ?>
                                        <tr>
                                            <th>
                                                Reason
                                            </th>
                                            <td>
                                                <?= $stage_2['declined_reason'] ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                                <!-- Withdrawn  date  -->
                                <?php if (isset($stage_2['status']) && $stage_2['status'] == "Withdrawn") { ?>
                                    <?php if (isset($stage_2['withdraw_date']) && !empty($stage_2['withdraw_date'])) { ?>
                                        <tr>
                                            <th>
                                                Date Withdrawn
                                            </th>
                                            <td>
                                                <?= date("d/m/Y", strtotime($stage_2['withdraw_date'])) ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>


                                <?php if (isset($stage_2['archive_date']) && $stage_2['archive_date'] == 0) { ?>
                                    <tr>
                                        <th>
                                            Date archive_date
                                        </th>
                                        <td>
                                            <?= $stage_2['archive_date'] ?>
                                        </td>
                                    </tr>
                                <?php } ?>

                            </thead>
                        </table>





                        <!-- <div class="d-flex align-items-center justify-content-center"> -->
                        <div class="d-flex">
                            <!-- stage 2  Continue and all Button -->

                            <div class="row w-100 col-sm-12" style="max-width:600px;">
                                <div class="col-sm-6  mb-2">
                                    <a href="<?= base_url('public/assets/PDF/Stage%202%20Applicant%20Checklist.pdf') ?>" class="btn btn_green_yellow w-100" download="">Download Stage 2 Checklist <i class="bi bi-download "></i></a>
                                </div>
                                <div class="col-sm-6  mb-2">

                                    <?php
                                    if ($Application_Details['pathway'] == "Pathway 1") {
                                        if (isset($stage_2_application_kit) && $stage_2_application_kit['application_kit_file_available']) { ?>
                                            <a href="<?php if (isset($stage_2_application_kit['File_full_path'])) {
                                                            echo base_url($stage_2_application_kit['File_full_path']);
                                                        } ?>" class="btn btn_green_yellow w-100" download="<?php if (isset($stage_2_application_kit['name'])) {
                                                                                                                echo $stage_2_application_kit['name'];
                                                                                                            } ?>">Download
                                                Applicant Kit <i class="bi bi-download"></i> </a>
                                        <?php } ?>
                                    <?php } ?>
                                </div>

                                <?php
                                // echo $stage_index;
                                if ($stage_index == 11 || $stage_index == 5) { ?>
                                    <div class="col-sm-12  mb-2">
                                        <a href="<?= base_url('user/stage_2/add_employment_document') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                            Continue Stage 2 Submission
                                        </a>
                                    </div>
                                <?php } ?>



                                <!-- Start Stage 3 Submission Button in stage 2  -->
                                <?php if ($stage_index == 15) {  ?>
                                    <hr class="mt-4">
                                    <div class="col-sm-12  mb-2 mt-3" style="max-width:600px;">
                                        <a href="<?= base_url('user/stage_3/receipt_upload') ?>/<?= $ENC_pointer_id ?>" class="btn btn_yellow_green w-100">
                                            Start Stage 3 Submission
                                        </a>
                                    </div>
                                <?php } ?>

                            </div>


                        </div>




                    </div>

                    <!-- stage 2 Submitted Documents  -->
                    <?php
                    // check stage 2 documant availebal to show 
                    $show_stage_2_documents = false;
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $show_stage_2_documents = true;
                            }
                        }
                    }

                    // create employee name list for filter 
                    $total_employee = array();
                    $i = 0;
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $i++;
                                $required_document_id = $value['required_document_id'];
                                $employee_id = $value['employee_id'];
                                $employment_info = stage_2_employment_info($employee_id);
                                if (!empty($employment_info)) {
                                    $data = [
                                        "id" => $employment_info['id'],
                                        "company_organisation_name" => $employment_info['company_organisation_name'],
                                    ];
                                    if (!in_array($data, $total_employee)) {
                                        $total_employee[] = $data;
                                    }
                                }
                            }
                        }
                    }
                    ?>

                    <!-- show stage 2 document -->
                    <?php if (isset($stage_2['status']) &&  $stage_2['status'] != "Start") { ?>
                        <?php if ($show_stage_2_documents) {  ?>
                            <div class="col-sm-6">
                                <!-- main parent DIV  -->
                                <div class="accordion" id="accordionExample">
                                    <!-- comman container for 1 item  -->
                                    <div class="accordion-item">
                                        <!-- Clickebal Button  -->
                                        <h2 class="accordion-header" id="s2_tital_div">
                                            <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;" type="button" data-bs-toggle="collapse" data-bs-target="#s2_tital_body_div" aria-expanded="false" aria-controls="s2_tital_body_div">
                                                <h6 class="text-green" style="font-size:18px !important"><b> Submitted Documents </b></h6>
                                            </button>
                                        </h2>
                                        <!-- collapseabal Div show all data / collapse Body  -->
                                        <div id="s2_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s1_tital_div" data-bs-parent="#accordionExample" style="overflow-y: scroll; height:200px;">

                                            <div class="card-body bg-white  w-100 col-sm-12">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th> Sr.No. </th>
                                                            <th> Document Name </th>
                                                            <!-- <td> Document </td> -->
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        // Compony or employ  documents 
                                                        foreach ($total_employee as $key => $val) {
                                                            echo "<tr class='bg-light p-2'><td  colspan='2'>" . $val['company_organisation_name'] . "</td><tr>";
                                                            $i = 0;
                                                            foreach ($documents as $key => $value) {
                                                                if ($value['stage'] == "stage_2") {
                                                                    if ($value['required_document_id'] > 0) {
                                                                        $required_document_id = $value['required_document_id'];
                                                                        $employee_id = $value['employee_id'];
                                                                        if ($val['id'] == $employee_id) {
                                                                            $i++;

                                                                            $name = $value['name'];
                                                                            $file_info = (!empty(required_documents_info($required_document_id)) ? required_documents_info($required_document_id) : "");
                                                                            if ($file_info['is_multiple']) {
                                                                                $name = $file_info['document_name'];
                                                                            }

                                                                            echo '<tr>
                                                                        <td> ' . $i . ' </td>
                                                                        <td>
                                                                            <a target="_blank" href="' . base_url($value['document_path'] . '/' . $value['document_name']) . '">
                                                                            ' . $name . '
                                                                            </a>
                                                                        </td>
                                                                    </tr>';
                                                                        }
                                                                    } // required_document_id
                                                                } // stage
                                                            } // forech 
                                                        } // forech 

                                                        // Assessment Documents
                                                        $i = 0;
                                                        echo "<tr class='bg-light p-2'><td  colspan='2'>  Assessment Documents </td><tr>";

                                                        foreach ($documents as $key => $value) {
                                                            if ($value['stage'] == "stage_2") {
                                                                if ($value['required_document_id'] > 0 && $value['required_document_id'] != 22) {
                                                                    $required_document_id = $value['required_document_id'];
                                                                    $employee_id = $value['employee_id'];
                                                                    if ($employee_id == 0 || empty($employee_id)) {
                                                                        $i++;
                                                                        $name = $value['name'];
                                                                        $file_info = (!empty(required_documents_info($required_document_id)) ? required_documents_info($required_document_id) : "");
                                                                        if ($file_info['is_multiple']) {
                                                                            $name = $file_info['document_name'];
                                                                        }
                                                                        if ($value["name"] == "Verification Email - Employment") {
                                                                            $i--;
                                                                            continue;
                                                                        }
                                                                        echo '<tr>
                                                                    <td> ' . $i . ' </td>
                                                                    <td>
                                                                        <a target="_blank" href="' . base_url($value['document_path'] . '/' . $value['document_name']) . '">
                                                                        ' . $name . '
                                                                        </a>
                                                                    </td>
                                                                </tr>';
                                                                    }
                                                                } // required_document_id
                                                            } // stage
                                                        } // forech 
                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } ?>

                    <!-- show stage 2 Additional Information Request -->
                    <?php
                    $show_additional_info_request = false;
                    foreach ($additional_info_request as $key__ => $value__) {
                        $stage__ = $value__['stage'];
                        $status__ = $value__['status'];
                        if ($stage__ == "stage_2" && $status__ == "send") {
                            $show_additional_info_request = true;
                        }
                    }

                    $employ_show = false;
                    foreach ($total_employee as $key_4 => $val_4) {
                        $employee_id = $val_4['id'];
                        foreach ($additional_info_request as $key => $value) {
                            $stage = $value['stage'];
                            $status = $value['status'];
                            if ($stage == "stage_2" && $status == "send") {
                                $request_document_id = $value['document_id'];
                                foreach ($documents as $key_2 => $val_2) {
                                    $doc_id = $val_2['id'];
                                    if ($doc_id == $request_document_id) {
                                        $request_employee_id = $val_2['employee_id'];
                                        if ($employee_id == $request_employee_id) {
                                            $employ_show = true;
                                        }
                                    }
                                }
                            }
                        }
                    }


                    if ($show_additional_info_request) {

                        $i = 0;
                    ?>
                        <!-- <span class="h2 text-danger">
                            Developer working on it. Please wait few minutes.
                        </span> -->

                        <!-- stage 2 -->
                        <div class="col-sm-12 mm">
                            <h2 class="text-green"><b>Action Required</b></h2>
                            <form action="<?= base_url('user/additional_information_request/stage_1/' . $ENC_pointer_id) ?>" id="add_info_req_stage_2" method="post" enctype="multipart/form-data">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="width: 5%;">Sr.No.</th>
                                            <!-- <th>Company Organisation Name</th> -->
                                            <th style="width: 45%;">Comment</th>
                                            <th style="width: 25%;">Document Name</th>
                                            <th style="width: 25%;">Action</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    // print_r($employ_show);
                                    if ($employ_show) { ?>

                                        <?php
                                        $new_list = array();
                                        foreach ($total_employee as $key_4 => $val_4) {
                                            $employee_id = $val_4['id'];
                                            $company_organisation_name = $val_4['company_organisation_name'];
                                            foreach ($additional_info_request as $key => $value) {
                                                $stage = $value['stage'];
                                                $status = $value['status'];
                                                $add_req_id =  $value['id'];
                                                $send_by =  $value['send_by'];
                                                $update_date = $value['update_date'];
                                                if ($stage == "stage_2" && $status == "send") {
                                                    $pointer_id = $value['pointer_id'];
                                                    $reason = $value['reason'];
                                                    $request_document_id = $value['document_id'];

                                                    foreach ($documents as $key_2 => $val_2) {
                                                        $doc_id = $val_2['id'];


                                                        if ($doc_id == $request_document_id) {
                                                            $doc_id . " " . $request_document_id;


                                                            $request_employee_id = $val_2['employee_id'];
                                                            if ($employee_id == $request_employee_id) {

                                                                $doc_name = $val_2['name'];
                                                                $list_ = array();
                                                                $list_['company_organisation_name'] = $company_organisation_name;
                                                                $list_['doc_name'] = $doc_name;
                                                                $list_['reason'] = $reason;
                                                                $list_['pointer_id'] = $pointer_id;
                                                                $list_['send_by'] = $send_by;
                                                                $list_['add_req_id'] = $add_req_id;
                                                                $list_['doc_id'] = $doc_id;
                                                                $list_['employee_id'] = $employee_id;
                                                                $new_list[] = $list_;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // new

                                        $company_names = array_unique(array_column($new_list, "company_organisation_name"));

                                        // company loop
                                        $new_array = array();

                                        foreach ($company_names as $company_name) {
                                            //
                                            $company_name_array = [];
                                            foreach ($new_list as $list) {
                                                if ($company_name == $list["company_organisation_name"]) {
                                                    array_push($company_name_array, $list);
                                                }
                                            }
                                            $new_array[$company_name] = $company_name_array;
                                            // array_push($new_array, $company_name_array);
                                        }
                                        // pre
                                        // echo "<pre>";
                                        // print_r($new_array);
                                        // echo "</pre>";
                                        // 

                                        // new array with only one record for each employee name
                                        // $new_array = array();

                                        // foreach ($new_list as $employee) {
                                        //     $name = $employee['company_organisation_name'];
                                        //     if (!isset($new_array[$name])) {
                                        //         $new_array[$name] = $employee;
                                        //     }
                                        // }
                                        // echo "<pre>";
                                        // print_r($new_array);
                                        // echo "</pre>";

                                        ?>




                                        <?php
                                        // print_r($new_array);
                                        foreach ($new_array as $key_44 => $val_44) {

                                            echo "<tr class='bg-light p-2'><td  colspan='4'>  " . $key_44 . " </td><tr>";

                                            // echo "<pre>";
                                            // print_r($key_44);
                                            // echo "</pre>";
                                            // exit;
                                            foreach ($val_44 as $key_4 => $val_4) {
                                                $doc_name = $val_4['doc_name'];
                                                $reason = $val_4['reason'];
                                                $pointer_id = $val_4['pointer_id'];
                                                $send_by = $val_4['send_by'];
                                                $add_req_id = $val_4['add_req_id'];
                                                $doc_id = $val_4['doc_id'];
                                                $employee_id = $val_4['employee_id'];
                                                $i++;
                                        ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <td style="text-align: justify;"> <?= $reason ?></td>
                                                    <td>
                                                        <input type="text" name="doc_name[]" value="<?= $doc_name ?>" class="form-control mb-2" readonly required />
                                                    </td>
                                                    <td>
                                                        <input type="file" class="form-control" name="file[]" accept="" required />
                                                        <input type="hidden" name="add_req_id[]" value="<?= $add_req_id ?>">
                                                        <input type="hidden" name="send_by[]" value="<?= $send_by ?>">
                                                        <input type="hidden" name="document_id[]" value="<?= $doc_id ?>">
                                                        <input type="hidden" name="stage" value="stage_2">
                                                        <input type="hidden" name="employee_id[]" value="<?= $employee_id ?>">
                                                    </td>
                                                </tr>
                                        <?php
                                            } // dcon_info 
                                        } // if stage_1
                                        ?>
                                    <?php } ?>



                                    <?php
                                    foreach ($additional_info_request as $key => $value) {
                                        $stage = $value['stage'];
                                        $status = $value['status'];
                                        $update_date = $value['update_date'];
                                        if ($stage == "stage_2" && $status == "send") {
                                            $pointer_id = $value['pointer_id'];
                                            $reason = $value['reason'];
                                            $request_document_id = $value['document_id'];
                                            if (!empty($request_document_id)) {
                                                foreach ($documents as $key_2 => $val_2) {
                                                    if ($val_2['id'] == $request_document_id) {
                                                        $doc_name = $val_2['name'];
                                                        // $doc_name = "";
                                                        if ($val_2['employee_id'] == 0 || $val_2['employee_id'] == "") {
                                                            // echo "<pre>";
                                                            // print_r($val_2);
                                                            // echo '</pre>';

                                                            $i++;
                                    ?>
                                                            <tr>
                                                                <td><?= $i ?></td>
                                                                <!-- <td></td> -->
                                                                <td style="text-align: justify;"><?= $reason ?></td>
                                                                <td>
                                                                    <input type="text" name="doc_name[]" value="<?= $doc_name ?>" class="form-control mb-2" readonly required />

                                                                    <!-- <input type="text" name="doc_name[]" class="form-control mb-2" required /> -->
                                                                </td>
                                                                <td>
                                                                    <input type="file" class="form-control" name="file[]" accept="" required />

                                                                    <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                                    <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                                    <input type="hidden" name="document_id[]" value="">
                                                                    <input type="hidden" name="stage" value="stage_2">
                                                                    <input type="hidden" name="employee_id[]" value="<?= $employee_id ?>">
                                                                </td>
                                                            </tr>
                                    <?php }
                                                    }
                                                }
                                            }
                                        }
                                    } ?>



                                    <!-- // aditional info  -->
                                    <?php
                                    foreach ($additional_info_request as $key => $value) {
                                        $stage = $value['stage'];
                                        $status = $value['status'];
                                        $update_date = $value['update_date'];
                                        if ($stage == "stage_2" && $status == "send") {
                                            $pointer_id = $value['pointer_id'];
                                            $reason = $value['reason'];
                                            $request_document_id = $value['document_id'];
                                            // echo "<pre>";
                                            // print_r($additional_info_request);
                                            // echo '</pre>';

                                            if ($request_document_id == "" || $request_document_id == "0") {

                                                $i++;
                                    ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <!-- <td></td> -->
                                                    <td style="text-align: justify;"><?= $reason ?></td>
                                                    <td>
                                                        <input type="text" name="doc_name[]" class="form-control mb-2" required />
                                                    </td>
                                                    <td>
                                                        <input type="file" class="form-control" name="file[]" accept="" required />

                                                        <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                        <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                        <input type="hidden" name="document_id[]" value="">
                                                        <input type="hidden" name="stage" value="stage_2">
                                                        <input type="hidden" name="employee_id[]" value="">
                                                    </td>
                                                </tr>
                                    <?php }
                                        }
                                    } ?>

                                </table>
                                <div class="mb-3 text-center">
                                    <button type="submit" class="btn btn_green_yellow" onclick="add_info_req('stage_2')">Submit Additional Information</button>
                                </div>
                            </form>
                        </div>
                    <?php } ?>


                </div>
                <!--- row --->
            </div>
        <?php } ?>





        <!-- stage 3  -->
        <?php if (!empty($s3_show)) { ?>
            <div class="tab-pane fade <?= $s3_show ?>  bg-white shadow- p-3" id="stage_3" role="tabpanel" aria-labelledby="stage_3-tab">
                <div class="row mt-3">
                    <!--stage 3  status info  and button -->
                    <div class="col-sm-6">
                        <!-- info table  -->
                        <?php if (isset($stage_3) && !empty($stage_3["status"] != "")) { ?>
                            <!-- stage 3 info  -->
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th>
                                            Status
                                        </th>
                                        <td>
                                           <b><?= (isset($stage_3["status"])) ? $stage_3["status"] : "" ?></b> </td>
                                    </tr>
                                    <?php if (!empty($stage_3['submitted_date']) && $stage_3['submitted_date'] != "0000-00-00 00:00:00" && $stage_3['submitted_date'] != null) { ?>
                                        <tr>
                                            <th>
                                                Date Submitted
                                            </th>
                                            <td>
                                                <?= (isset($stage_3["submitted_date"])) ? date("d/m/Y", strtotime($stage_3["submitted_date"])) : "" ?>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                    <!--  Date Lodged -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Lodged') { ?>
                                    <?php } ?>
                                    <?php if (!empty($stage_3['lodged_date']) && $stage_3['lodged_date'] != "0000-00-00 00:00:00" && $stage_3['lodged_date'] != null) { ?>
                                       
                                    <?php } ?>

                                    <!--  Date Scheduled -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Scheduled') { ?>
                                    <?php } ?>

                                    <?php if (!empty($stage_3['scheduled_date']) && $stage_3['scheduled_date'] != "0000-00-00 00:00:00" && $stage_3['scheduled_date'] != null) { ?>
                                       
                                    <?php } ?>

                                    <!--   Date Conducted -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Conducted') { ?>
                                        <!-- <tr>
                                            <th>
                                                Date Conducted
                                            </th>
                                            <td>
                                                <?= (isset($stage_3["conducted_date"])) ? date("d/m/Y", strtotime($stage_3["conducted_date"])) : "" ?>
                                            </td>
                                        </tr> -->
                                    <?php } ?>

                                    <!-- Date Approved -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Approved') { ?>
                                        <?php if (!empty($stage_3['approved_date']) && $stage_3['approved_date'] != "0000-00-00 00:00:00" && $stage_3['approved_date'] != null) { ?>

                                            <tr>
                                                <th>
                                                    Date Approved
                                                </th>
                                                <td>
                                                    <?= (isset($stage_3["approved_date"])) ? date("d/m/Y", strtotime($stage_3["approved_date"])) : "" ?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>


                                    <!--   Date Declined -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Declined') { ?>
                                        <?php if (!empty($stage_3['declined_date']) && $stage_3['declined_date'] != "0000-00-00 00:00:00" && $stage_3['declined_date'] != null) { ?>
                                            <tr>
                                                <th>
                                                    Date Declined
                                                </th>
                                                <td>
                                                    <?= (isset($stage_3["declined_date"])) ? date("d/m/Y", strtotime($stage_3["declined_date"])) : "" ?>
                                                </td>
                                            </tr>
                                        <?php } ?>


                                        <tr>
                                            <th>
                                                Reason for Decline
                                            </th>
                                            <td>
                                                <?= (isset($stage_3["declined_reason"])) ? $stage_3["declined_reason"] : "" ?>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                    <!-- Date Withdrawn -->
                                    <?php if (isset($stage_3["status"]) &&  $stage_3["status"] == 'Withdrawn') { ?>
                                    <?php } ?>

                                    <?php if (!empty($stage_3['withdraw_date']) && $stage_3['withdraw_date'] != "0000-00-00 00:00:00" && $stage_3['withdraw_date'] != null) { ?>
                                        <tr>
                                            <th>
                                                Date Withdrawn
                                            </th>
                                            <td>
                                                <?= (isset($stage_3["withdraw_date"])) ? date("d/m/Y", strtotime($stage_3["withdraw_date"])) : "" ?>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                </thead>
                            </table>

                        <?php } ?>


                    </div>
                    <!-- stage 3 submitted Documents -->
                    <div class="col-sm-6">

                        <div class="card">

                            <!-- main parent DIV  -->
                            <div class="accordion" id="accordionExample">
                                <!-- comman container for 1 item  -->
                                <div class="accordion-item">
                                    <!-- Clickebal Button  -->
                                    <h2 class="accordion-header" id="s3_tital_div">
                                        <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;" type="button" data-bs-toggle="collapse" data-bs-target="#s3_tital_body_div" aria-expanded="false" aria-controls="s3_tital_body_div">
                                            <h5 class="text-green"><b> Submitted Documents </b></h5>
                                        </button>
                                    </h2>
                                    <!-- collapseabal Div show all data / collapse Body  -->
                                    <div id="s3_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s3_tital_div" data-bs-parent="#accordionExample" style="overflow-y: scroll; height:400px;">
                                        <div class="card-body">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th> Sr.No. </th>
                                                        <th> Document Name </th>
                                                        <!-- <td> Document </td> -->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $i = 0;
                                                    foreach ($documents as $key => $value) {
                                                        if ($value['stage'] == "stage_3") {
                                                            if ($value['required_document_id'] == 19 || $value['required_document_id'] == 29) {
                                                                $i++;
                                                                $required_document_id = $value['required_document_id'];

                                                    ?>
                                                                <tr>
                                                                    <td> <?= $i; ?> </td>
                                                                    <td>
                                                                        <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                            <?= $value['name']; ?>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                    <?php
                                                            } // required_document_id
                                                        } // stage
                                                    } // forech 
                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <!-- Interview Schedule -->
                    <?php
                    if (isset($stage_3["status"])) {
                        if ($stage_3["status"] == 'Scheduled' || $stage_3["status"] == 'Conducted') {
                            if (isset($Interview_Schedule['is_booked']) && $Interview_Schedule['is_booked'] == 1) { ?>
                                <table class="table ">
                                    <thead>
                                        <tr>
                                            <td style="width: 30%;border-bottom: 0px;margin-top:10px" colspan="2">
                                                <br>
                                                <u> <b style="color: #055837;"> Interview Booking Details</b></u> <br>
                                            </td>
                                        </tr>
                                        <tr style="background-color: #ffc107 !important;">
                                            <td colspan="2" style="background-color: #ffc107;">
                                                <div style="background-color: #ffc107;">
                                                    <style>
                                                        #sddsf td {
                                                            border: 0px;
                                                            color: #055837;
                                                        }
                                                    </style>
                                                    <table id="sddsf">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 150px;">
                                                                    <b> Day &amp; Date / Time</b>
                                                                </td>
                                                                <td style="width: 20px;">
                                                                    :
                                                                </td>
                                                                <td>
                                                                    <!-- time 1  -->
                                                                    <?php
                                                                    $time_date = date('Y-m-d H:i:s', $Interview_Schedule['tmsp']);
                                                                    $date = new DateTime($time_date, new DateTimeZone('Australia/Brisbane'));
                                                                    $time_date_n = $date->format('Y-m-d H:i:s');
                                                                    echo  $date->format('l, jS F Y') . ' / ' . $date->format('h:i A');
                                                                    ?>
                                                                    (Australia/Brisbane Time)
                                                                    <br>

                                                                    <!-- time 2  -->
                                                                    <?php
                                                                    if ($Interview_Schedule['venue'] != 'Australia/Brisbane') {
                                                                    ?>

                                                                        <?php
                                                                        $date->setTimezone(new DateTimeZone($Interview_Schedule['date_time_zone']));
                                                                        echo  $date->format('l, jS F Y') . ' / ' . $date->format('h:i A');
                                                                        ?>
                                                                        (<?= $Interview_Schedule['date_time_zone'] ?> Time)
                                                                    <?php } ?>

                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td>
                                                                    <b> Venue </b>
                                                                </td>
                                                                <td style="width: 20px;">
                                                                    :
                                                                </td>
                                                                <td>
                                                                    <?= $Interview_Schedule['venue'] ?>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                            if ($Interview_Schedule['venue']  != "Online (Via Zoom)") {
                                                            ?>
                                                                <tr>
                                                                    <td>
                                                                        <b> Location </b>
                                                                    </td>
                                                                    <td style="width: 20px;">
                                                                        :
                                                                    </td>
                                                                    <td>
                                                                        <?= $Interview_Schedule['office_address'] ?>,
                                                                        <?= $Interview_Schedule['country'] ?>
                                                                    </td>
                                                                </tr>
                                                            <?php } ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>

                                        </tr>

                                    </thead>
                                </table>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>


                    <!-- stage 3 Action Requad  -->
                    <?php if ($stage_index >= 22 && $stage_index <= 25) {  ?>
                        <?php
                        $show_Additional_Information_Request = false;
                        foreach ($additional_info_request as $key_1 => $value_1) {
                            $stage = $value_1['stage'];
                            $status = $value_1['status'];
                            if ($stage == "stage_3" && $status == "send") {
                                $show_Additional_Information_Request = true;
                            }
                        }
                        ?>
                        <?php if ($show_Additional_Information_Request) { ?>

                            <!-- stage 3 -->
                            <div class="col-sm-12 mm">
                                <h2 class="text-green"><b>Action Required</b></h2>
                                <form action="<?= base_url('user/additional_information_request/stage_3/' . $ENC_pointer_id) ?>" id="add_info_req_stage_3" method="post" enctype="multipart/form-data">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">Sr.No.</th>
                                                <th style="width: 45%;">Comment</th>
                                                <th style="width: 25%;">Document Name</th>
                                                <th style="width: 25%;">Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $i = 1;
                                        foreach ($additional_info_request as $key => $value) {
                                            $pointer_id = $value['pointer_id'];
                                            $document_id = $value['document_id'];
                                            $stage = $value['stage'];
                                            $reason = $value['reason'];
                                            $status = $value['status'];
                                            $update_date = $value['update_date'];
                                            if ($stage == "stage_3" && $status == "send") {
                                                $doc_info = documents_info($pointer_id, $document_id);
                                                if (isset($doc_info['required_document_id'])) {
                                                    $doc_required_document_id = $doc_info['required_document_id'];
                                                } else {
                                                    $doc_required_document_id = "";
                                                }
                                                if ($doc_info) {
                                                    $doc_id = $doc_info['id'];
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"  value="' . $doc_info['name'] . '" readonly>';
                                                } else {
                                                    $doc_id = '';
                                                    $doc_name = '<input type="text" name="doc_name[]" class="form-control mb-2"   required>';
                                                }

                                        ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <td><?= $reason ?></td>
                                                    <td><?= $doc_name ?></td>
                                                    <td>
                                                        <input type="file" class="form-control" name="file[]" accept="" required />

                                                        <input type="hidden" name="add_req_id[]" value="<?= $value['id'] ?>">
                                                        <input type="hidden" name="send_by" value="<?= $value['send_by'] ?>">
                                                        <input type="hidden" name="document_id[]" value="<?= $doc_id ?>">
                                                        <input type="hidden" name="stage" value="stage_3">

                                                    </td>
                                                </tr>
                                                <?php $i++; ?>
                                            <?php  } ?>
                                        <?php   } ?>
                                    </table>
                                    <div class="mb-3 text-center">
                                        <button type="submit" c class="btn btn_green_yellow add_info_req_upload">Submit Additional Information</button>
                                    </div>
                                </form>
                            </div>
                        <?php } ?>
                    <?php } ?>
                    <!-- stage 3 Action Requad  -->

                </div>
            </div>
        <?php } ?>
        <!-- stage 3  -->





        <!-- stage_4  -->
        <?php if ($stage_index == 27 || $stage_index == 28) { ?>
            <?php if ($stage_index == "Vishal") { ?>
                <!-- hide code  -->
                <div class="tab-pane fade <?= ($is_active == "stage_4") ? "show active " : ""; ?>  bg-white shadow- p-3" id="stage_4" role="tabpanel" aria-labelledby="stage_4-tab">
                    <div class="row ">
                        <!--stage 4  status info  and button -->
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-6">

                            <!-- all done stage 3 complate  -->
                            <table class="table">

                                <tbody>
                                    <tr>
                                        <!-- <th style="width:50%;">Date Completed</th> -->
                                        <th style="width:50%;"> Date Submitted </th>
                                        <td> <?= (isset($stage_1["submitted_date"])) ?  date("d/m/Y", strtotime($stage_1['submitted_date'])) : "" ?>
                                        </td>
                                    </tr>

                                    <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Approved") { ?>
                                        <tr>
                                            <th style="width:50%;"> Date Approved </th>

                                            <td> <?= (isset($stage_3["approved_date"])) ? date("d/m/Y", strtotime($stage_3["approved_date"]))  : "" ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Declined") { ?>
                                        <tr>
                                            <th style="width:50%;"> Date Declined </th>

                                            <td> <?= (isset($stage_3["declined_date"])) ? date("d/m/Y", strtotime($stage_3["declined_date"]))  : "" ?>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                    <tr>
                                        <th style="width:50%;">Status</th>
                                        <td> <?= (isset($stage_3["status"])) ?  $stage_3["status"] : "" ?> </td>
                                    </tr>


                                </tbody>
                            </table>

                            <!-- show Approved admin 2 file  -->
                            <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Approved") { ?>
                                <div class="row">
                                    <?php foreach ($documents as $key => $value) {
                                        if ($value['stage'] == "stage_3") {   ?>
                                            <!-- Upload Qualifications for pathway 1 only -->
                                            <?php if (isset($Application_Details['pathway']) && $Application_Details['pathway'] == "Pathway 1") {  ?>
                                                <?php if ($value['required_document_id'] == 26) {   ?>
                                                    <div class="col-sm-6">
                                                        <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download> <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                                    </div>
                                                <?php } ?>
                                            <?php } ?>
                                            <!-- Upload Outcome Letter	 -->
                                            <?php if ($value['required_document_id'] == 25) {   ?>
                                                <div class="col-sm-6">
                                                    <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download> <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                            <?php } ?>

                            <!-- show Declined admin 2 file  -->
                            <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Declined") { ?>
                                <!-- show document for pathway 1 only  -->
                                <div class="row">
                                    <?php foreach ($documents as $key => $value) {
                                        if ($value['stage'] == "stage_3") {   ?>
                                            <!-- Outcome Letter -->
                                            <?php if ($value['required_document_id'] == 23) {  ?>
                                                <div class="col-sm-6">
                                                    <a href=" <?= base_url("'" . $value['document_path'] . "/" . $value['document_name'] . "'") ?>" class="btn btn_green_yellow w-100" download> <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                                </div>
                                            <?php } ?>
                                            <!-- Statement of Reasons -->
                                            <?php if ($value['required_document_id'] == 24) { ?>
                                                <div class="col-sm-6">
                                                    <a href=" <?= base_url("'" . $value['document_path'] . "/" . $value['document_name'] . "'") ?>" class="btn btn_green_yellow w-100" download> <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                            <?php } ?>

                        </div>
                        <div class="col-sm-3">
                        </div>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>
        <!-- stage 4  -->



    </div>

</div>

<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<!-- onready  -->
<script>
    var ENC_pointer_id = '<?= $ENC_pointer_id ?>';

    function add_info_req(stage) {
        // var stage = $(stage).val();

        //  custom_alert_popup_show(header = '', body_msg = "Are you sure you want to submit additional information?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'submit');
        // $("#submit").click(function() {
        //     if (custom_alert_popup_close('submit')) {
        var formData = new FormData($(id)[0]);
        // $('#cover-spin').show(0);
        console.log();
        return;
        console.log(stage);
        var id = '"#add_info_req_' + stage + '"';
        console.log(id);
        // creat alert box 
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to download all files?", close_btn_text =
            'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class =
            'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
        // check Btn click
        $("#AJDSAKAJLD").click(function() {
            // if return true 
            if (custom_alert_popup_close('AJDSAKAJLD')) {
                // console.log("here");
                // return;
                // form = new formData();
                $.ajax({
                    url: "<?= base_url('user/additional_information_request') ?>/" + stage + '/' +
                        ENC_pointer_id,
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {},
                    success: function(data) {
                        console.log(data);
                        window.location = data;
                    },
                });
            }
        })


        //     }
        // });



    }
</script>

<script>
    $("#add_info_req_stage_1").submit(function() {

        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to submit the additional information ? You will not be able to remove or change these documents after submission.", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'submit_stage1');
        $("#submit_stage1").click(function() {
            if (custom_alert_popup_close('submit')) {
                $('#cover-spin').show(0);
                return true;
            }
        });

    });

    $("#add_info_req_stage_2").submit(function() {
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to submit the additional information ? You will not be able to remove or change these documents after submission.", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'submit_stage2');
        $("#submit_stage2").click(function() {
            if (custom_alert_popup_close('submit_stage2')) {
                $('#cover-spin').show(0);
                return true;
            }
        });

    });
    $("#add_info_req_stage_3").submit(function() {
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to submit the additional information ? You will not be able to remove or change these documents after submission.", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'submit_stage3');
        $("#submit_stage3").click(function() {
            if (custom_alert_popup_close('submit_stage3')) {
                $('#cover-spin').show(0);
                return true;
            }
        });

    });


    function hoverImage() {
        document.getElementById("myImage").src = "<?= base_url('public/assets/icon/new_popup.png') ?>";
    }

    function originalImage() {
        document.getElementById("myImage").src = "<?= base_url('public/assets/icon/new_popup_.png') ?>";
    }
</script>


<?= $this->endSection() ?>