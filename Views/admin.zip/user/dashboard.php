<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>

<style>
    .g-recaptcha {
        display: inline-block;
    }

    body {
        background-color: #FFF !important;
    }
</style>
<hr>
<div class="container mt-4 mb-4">


    <!-- Button UI  -->
    <style>
        .listing .nav-link:hover {
            background-color: var(--yellow) !important;
            color: var(--green) !important;
        }

        .listing .nav-link:hover .icons:hover {
            background-color: var(--green);
        }

        .left_icon {
            position: absolute;
            line-height: 5;
            height: 91px;
            margin-left: -20px;
            margin-top: -24px;
            display: flex;
            justify-content: center;
            background-color: var(--yellow);
            color: var(--green);
            width: 63px;
        }

        .c_box {
            float: right;
            line-height: 6;
            height: 91px;
            width: 63px;
            margin-top: -67px;
            display: flex;
            justify-content: center;
            background-color: var(--yellow);
            color: var(--green);
        }

        .vishal_ic {
            font-size: 24px !important;
            margin-top: -17px !important;
            color: var(--green);

        }

        .tx {
            font-size: 20px !important;
            margin-top: -13px !important;
        }
    </style>


    <div class="row">
        <div class="col-md-3"></div>

        <div class=" col-md-6">
            <?php
            if (is_Applicant()) {
            ?>
                <style>
                    .sidebar-nav {
                        margin-top: 200px;
                    }
                </style>
            <?php
            }
            ?>
            <?php 
                // echo $any_running;
                // echo $Incomplete_count;
            ?>
            <div class="sidebar-nav listing" id="sidebar-nav">
                <!-- Alert on set - Flashdata -->
                <?= $this->include("alert_box.php") ?>

                <?php
                $Create_New = false;
                $count = 0;
                if (is_Applicant()) {
                    $Create_New = false;
                    if($any_running > 0) {
                        // echo "fdfd";
                        $Create_New = false;
                    }
                    if ($Incomplete_count == 0) {
                        // echo "fdfd";
                        $Create_New = true;
                    }
                } else if (is_Agent()) {
                    $Create_New = true;
                }
                //  print_r($Create_New);
                ?>
                <?php if ($Create_New) { ?>
                    <div class="d-flex justify-content-center">
                        <div style="width: 400px;">
                            <a href="<?= base_url('user/create_new_application') ?>" class="nav-link text-light py-4 rounded" style="background-color:#055837;">
                                <span class="left_icon px-4  rounded">
                                    <i class="bi vishal_ic bi-align-middle "></i>
                                </span>
                                <h5 style="padding-top: 11px;margin-left: 65px;">Create New Application</h5>
                            </a>
                        </div>
                    </div>
                    <br>
                <?php } ?>


                <?php
                $Incomplete_Applications = false;
                if (is_Applicant()) {
                    $Incomplete_Applications = false;
                    if ($Incomplete_count > 0) {
                        $Incomplete_Applications = true;
                    }
                } else if (is_Agent()) {
                    $Incomplete_Applications = true;
                }
                ?>

                <?php if ($Incomplete_Applications) { ?>

                    <div class="d-flex justify-content-center ">
                        <div style="width: 400px;">
                            <a class="nav-link text-light py-4 rounded" style=" background-color:#055837;" href="<?= base_url('user/incomplete_application') ?>">
                                <span class="left_icon px-4  rounded"> <i class="bi vishal_ic bi-pencil-square  " style="margin: 10px;"></i></i> </span>
                                <h5 class="" style=" padding-top: 11px;margin-left: 65px;">Incomplete Applications</h5>
                                <span class="rounded c_box">
                                    <b class="tx">
                                        <?= $Incomplete_count ?>
                                    </b>
                                </span>
                            </a>
                        </div>
                    </div>
                    <br>
                <?php } ?>



                <!-- Submitted_Applications  hide show by Login Type  -->
                <?php
                $Submitted_Applications = false;
                if (is_Applicant()) {
                    $Submitted_Applications = false;
                    if ($submit_count > 0) {
                        $Submitted_Applications = true;
                    }
                } else if (is_Agent()) {
                    $Submitted_Applications = true;
                }
                ?>
                <?php if ($Submitted_Applications) { ?>
                    <div class="d-flex justify-content-center">
                        <div style="width: 400px;">
                            <a class="nav-link text-light py-4 rounded" style="background-color:#055837;" href="<?= base_url('user/submitted_applications') ?>">
                                <!-- <span class="mx-2"> <i class="bi bi-stickies-fill nav-link bg-warning  icons"></i> </span> -->

                                <span class="left_icon px-4  rounded"> <i class="bi vishal_ic bi-stickies-fill " style="margin: 10px;"></i></i> </span>
                                <h5 class="" style=" padding-top: 11px;margin-left: 65px;">Submitted Applications</h5>
                                <span class="rounded c_box">
                                    <b class="tx">
                                        <?= $submit_count ?>
                                    </b>
                                </span>
                            </a>
                        </div>
                    </div>
                    <br>

                <?php } ?>



                <div class="d-flex justify-content-center">
                    <div style="width: 400px;">
                        <a class="nav-link text-light py-4 rounded" style="background-color:#055837;" href="<?= base_url('user/account_update') ?>">
                            <!-- <span class="mx-2"> <i class="bi bi-person-square nav-link bg-warning  icons"></i> </span> -->
                            <span class="left_icon px-4  rounded"> <i class="bi vishal_ic  bi-person-square   " style="margin: 10px;"></i></i> </span>
                            <h5 class="" style=" padding-top: 11px;margin-left: 65px;">Update My Details</h5>
                        </a>
                    </div>
                </div>
                <br>
                <?php
                if (is_Agent()) {
                ?>
                    <div class="d-flex justify-content-center">
                        <div style="width: 400px;">
                            <a class="nav-link text-light py-4 rounded" style="background-color:#055837;" href="<?= base_url('user/download_Form') ?>">
                                <!-- <span class="mx-2"> <i class="bi bi-person-square nav-link bg-warning  icons"></i> </span> -->
                                <span class="left_icon px-4  rounded"> <i class="bi vishal_ic  bi-folder2   " style="margin: 10px;"></i></i> </span>
                                <h5 class="" style=" padding-top: 11px;margin-left: 65px;"> Forms</h5>
                            </a>
                        </div>
                    </div>
                <?php
                }
                ?>

            </div>
            <br>
        </div>

        <div class="col-md-3"></div>


    </div> <!-- row  -->
</div> <!-- container  -->
<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<script>
    $('#login').on('click', function() {

        var response = grecaptcha.getResponse();

        if (response.replace(/ /g, '').length == 0) {

            alert('Please complete the Captcha below'); // 29 aug 2022 :- Vishal h patel
            return false;
        }
    });
</script>

<?= $this->endSection() ?>