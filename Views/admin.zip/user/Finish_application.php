<?= $this->extend('template/user_template') ?>
<?= $this->section('main') ?>


<!-- inner heading  -->
<div class="bg-green text-white text-center pt-1 pb-1" style="font-size: 120%;">
    <b> Application Details </b>
</div>


<style>
    .arrow {
        border-radius: 0px !important;
        clip-path: polygon(93% 0, 100% 50%, 93% 100%, 0% 100%, 6% 50%, 0% 0%);
    }

    a.active {
        background-color: var(--yellow) !important;
        color: var(--green) !important;
    }

    .active {
        border: 1px solid var(--yellow) !important;

    }

    .staper_btn {
        max-width: 100%;
    }
</style>


<!-- start body  -->
<div class="container-fluid mt-4 mb-4 p-4 bg-white shadow">
    <!-- Application Details  -->
    <div class="row">
        <div class="col-sm-6">


            <table class="table">
                <tr>
                    <td>
                        <b> Portal Reference No. </b>
                    </td>
                    <td>
                        <?= $portal_reference_no ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Application No. </b>
                    </td>
                    <td>
                        <?= $Unique_number ?>
                    </td>
                </tr>



                <tr>
                    <td>
                        <b> Applicant's Name </b>
                    </td>
                    <td>
                        <?= $Application_Details['name'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Occupation </b>
                    </td>
                    <td>
                        <?= $Application_Details['occupation'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Pathway </b>
                    </td>
                    <td>
                        <?= $Application_Details['pathway'] ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b> Program </b>
                    </td>
                    <td>
                        <?= $Application_Details['program'] ?>
                    </td>
                </tr>

                <tr>
                    <!-- <th style="width:50%;">Date Completed</th> -->
                    <th style="width:50%;"> Date Submitted </th>
                    <td> <?= (isset($stage_1["submitted_date"])) ?  date("d/m/Y", strtotime($stage_1['submitted_date'])) : "" ?>
                    </td>
                </tr>

                <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Approved") { ?>
                    <tr>
                        <th style="width:50%;"> Date Approved </th>

                        <td> <?= (isset($stage_3["approved_date"])) ? date("d/m/Y", strtotime($stage_3["approved_date"]))  : "" ?>
                        </td>
                    </tr>
                <?php } ?>
                <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Declined") { ?>
                    <tr>
                        <th style="width:50%;"> Date Declined </th>

                        <td> <?= (isset($stage_3["declined_date"])) ? date("d/m/Y", strtotime($stage_3["declined_date"]))  : "" ?>
                        </td>
                    </tr>
                <?php } ?>

                <tr>
                    <th style="width:50%;">Status</th>
                    <td><b> <?= (isset($stage_3["status"])) ?  $stage_3["status"] : "" ?></b> </td>
                </tr>


                </tbody>
            </table>

            <!-- show Approved admin 2 file  -->
            <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Approved") { ?>
                <div class="row mt-2 mb-2   ">
                    <div class="col-sm-6 mt-2">
                        <a href="<?= $TRA_Application_Form_url ?> " class="btn btn_green_yellow w-100" download> Download Submitted Application <i class="bi bi-download"></i> </a>
                    </div>
                    <?php foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_3") {   ?>
                            <!-- Upload Qualifications for pathway 1 only -->
                            <?php if (isset($Application_Details['pathway']) && $Application_Details['pathway'] == "Pathway 1") {  ?>
                                <?php if ($value['required_document_id'] == 26) {   ?>
                                    <div class="col-sm-6 mt-2">
                                        <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download> Download <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                    </div>
                                <?php } ?>
                            <?php } ?>
                            <!-- Upload Outcome Letter	 -->
                            <?php if ($value['required_document_id'] == 25) {   ?>
                                <div class="col-sm-6 mt-2">
                                    <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download> Download <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php } ?>

            <!-- show Declined admin 2 file  -->
            <?php if (isset($stage_3["status"]) && $stage_3["status"] == "Declined") { ?>
                <!-- show document for pathway 1 only  -->
                <div class="row mt-2 mb-2">
                    <?php foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_3") {   ?>
                            <!-- Outcome Letter -->
                            <?php if ($value['required_document_id'] == 23) {  ?>
                                <div class="col-sm-6">
                                    <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download>Download <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                </div>
                            <?php } ?>
                            <!-- Statement of Reasons -->
                            <?php if ($value['required_document_id'] == 24) { ?>
                                <div class="col-sm-6">
                                    <a href=" <?= base_url($value['document_path'] . "/" . $value['document_name']) ?>" class="btn btn_green_yellow w-100" download> Download <?= $value['name'] ?> <i class="bi bi-download "></i></a>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>

        <!-- Submitted  -->
        <?php if (isset($stage_1['status']) && !empty($stage_1['status'])) {
            if (!empty($stage_1['submitted_date']) || $stage_1['submitted_date'] != "0000-00-00 00:00:00" || $stage_1['submitted_date'] != null) {
                //  echo date("d/m/Y", strtotime($stage_1['submitted_date']));
            }
        } ?>

        <!-- stage 1 documents  -->
        <div class="col-sm-6">

            <div class="text-center">

                <!-- // image  -->
                <?php
                $check = false;
                foreach ($documents as $key => $value) {
                    if ($value['stage'] == "stage_1") {
                        if ($value['required_document_id'] == 1) {
                            $check = true;

                ?>
                            <img src="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" width="170px" height="170px" class="shadow">

                <?php
                            break;
                        } // required_document_id
                    } // stage
                } // forech 
                ?>
                <?php if (!$check) { ?>
                    <img src="https://cdn-icons-png.flaticon.com/512/180/180658.png" width="170px" height="170px" class="shadow">
                <?php } ?>
                <!-- // image  -->

            </div>

            <br>
            <br>
            <br>


            <div class="accordion" id="accordionExample">

                <!-- stage 1 docs  -->
                <div>
                    <!-- comman container for 1 item  -->
                    <div class="accordion-item">
                        <!-- Clickebal Button  -->
                        <h2 class="accordion-header" id="s1_tital_div">
                            <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;" type="button" data-bs-toggle="collapse" data-bs-target="#s1_tital_body_div" aria-expanded="false" aria-controls="s1_tital_body_div">
                                <h5 class="text-green p-2"><b>Stage 1 - Submitted Documents </b></h5>
                            </button>
                        </h2>
                        <!-- collapseabal Div show all data / collapse Body  -->
                        <div id="s1_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s1_tital_div" data-bs-parent="#accordionExample" style="overflow-y: scroll; height:400px;">
                            <div class="card-body">
                                <table class="table p-2">
                                    <thead>
                                        <tr>
                                            <th> Sr.No. </th>
                                            <th> Document Name </th>
                                            <!-- <td> Document </td> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        foreach ($documents as $key => $value) {
                                            if ($value['stage'] == "stage_1") {
                                                if ($value['required_document_id'] > 0) {
                                                    $i++;
                                                    $required_document_id = $value['required_document_id'];

                                        ?>
                                                    <tr>
                                                        <td> <?= $i; ?> </td>
                                                        <td>
                                                            <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                <?= $value['name']; ?>
                                                            </a>
                                                        </td>
                                                        <!-- <td> <img src="<?= base_url($value['document_path'] . '/' . $value['document_name']) ?>" width="150px"> </td> -->
                                                    </tr>
                                        <?php
                                                } // required_document_id
                                            } // stage
                                        } // forech 
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- stage 2 docs  -->
                <div>
                    <?php
                    // check stage 2 documant availebal to show 
                    $show_stage_2_documents = false;
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $show_stage_2_documents = true;
                            }
                        }
                    }
                    // create employee name list for filter 
                    $total_employee = array();
                    $i = 0;
                    foreach ($documents as $key => $value) {
                        if ($value['stage'] == "stage_2") {
                            if ($value['required_document_id'] > 0) {
                                $i++;
                                $required_document_id = $value['required_document_id'];
                                $employee_id = $value['employee_id'];
                                $employment_info = stage_2_employment_info($employee_id);
                                if (!empty($employment_info)) {
                                    $data = [
                                        "id" => $employment_info['id'],
                                        "company_organisation_name" => $employment_info['company_organisation_name'],
                                    ];
                                    if (!in_array($data, $total_employee)) {
                                        $total_employee[] = $data;
                                    }
                                }
                            }
                        }
                    }
                    ?>

                    <!-- show stage 2 document -->
                    <?php if ($show_stage_2_documents) {  ?>
                        <div class="accordion-item">
                            <!-- Clickebal Button  -->
                            <h2 class="accordion-header" id="s2_tital_div">
                                <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;" type="button" data-bs-toggle="collapse" data-bs-target="#s2_tital_body_div" aria-expanded="false" aria-controls="s2_tital_body_div">
                                    <h5 class="text-green p-2"><b>Stage 2 - Submitted Documents </b></h5>
                                </button>
                            </h2>
                            <!-- collapseabal Div show all data / collapse Body  -->
                            <div id="s2_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s1_tital_div" data-bs-parent="#accordionExample" style="overflow-y: auto; height:100px;">
                                <div style="overflow-y: auto; height:500px;" class="mb-3">
                                    <div class="card-body bg-white  w-100 col-sm-12">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th> Sr.No. </th>
                                                    <th> Document Name </th>
                                                    <!-- <td> Document </td> -->
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                // Compony or employ  documents 
                                                foreach ($total_employee as $key => $val) {
                                                    echo "<tr class='bg-light p-2'><td  colspan='2'>" . $val['company_organisation_name'] . "</td><tr>";
                                                    $i = 0;
                                                    foreach ($documents as $key => $value) {
                                                        if ($value['stage'] == "stage_2") {
                                                            if ($value['required_document_id'] > 0) {
                                                                $required_document_id = $value['required_document_id'];
                                                                $employee_id = $value['employee_id'];
                                                                if ($val['id'] == $employee_id) {
                                                                    $i++;

                                                                    $name = $value['name'];
                                                                    $file_info = (!empty(required_documents_info($required_document_id)) ? required_documents_info($required_document_id) : "");
                                                                    if ($file_info['is_multiple']) {
                                                                        $name = $file_info['document_name'];
                                                                    }

                                                                    echo '<tr>
                                                                        <td> ' . $i . ' </td>
                                                                        <td>
                                                                            <a target="_blank" href="' . base_url($value['document_path'] . '/' . $value['document_name']) . '">
                                                                            ' . $name . '
                                                                            </a>
                                                                        </td>
                                                                    </tr>';
                                                                }
                                                            } // required_document_id
                                                        } // stage
                                                    } // forech 
                                                } // forech 

                                                // Assessment Documents
                                                $i = 0;
                                                echo "<tr class='bg-light p-2'><td  colspan='2'>  Assessment Documents </td><tr>";

                                                foreach ($documents as $key => $value) {
                                                    if ($value['stage'] == "stage_2") {
                                                        if ($value['required_document_id'] > 0) {
                                                            $required_document_id = $value['required_document_id'];
                                                            $employee_id = $value['employee_id'];
                                                            if ($employee_id == 0 || empty($employee_id)) {
                                                                $i++;
                                                                $name = $value['name'];
                                                                $file_info = (!empty(required_documents_info($required_document_id)) ? required_documents_info($required_document_id) : "");
                                                                if ($file_info['is_multiple']) {
                                                                    $name = $file_info['document_name'];
                                                                }
                                                                // echo "<pre>";
                                                                // print_r($value);
                                                                if($value["name"] == "Verification Email - Employment"){
                                                                    $i--;
                                                                    continue;
                                                                }
                                                                echo '<tr>
                                                                    <td> ' . $i . ' </td>
                                                                    <td>
                                                                        <a target="_blank" href="' . base_url($value['document_path'] . '/' . $value['document_name']) . '">
                                                                        ' . $name . '
                                                                        </a>
                                                                    </td>
                                                                </tr>';
                                                            }
                                                        } // required_document_id
                                                    } // stage
                                                } // forech 
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>

                <!-- stage 3 docs  -->
                <div>
                    <div class="accordion-item">
                        <!-- Clickebal Button  -->
                        <h2 class="accordion-header" id="s3_tital_div">
                            <button class="accordion-button collapsed" style="padding: 5px !important; padding-top: 10px !important;" type="button" data-bs-toggle="collapse" data-bs-target="#s3_tital_body_div" aria-expanded="false" aria-controls="s3_tital_body_div">
                                <h5 class="text-green p-2"><b>Stage 3 - Submitted Documents </b></h5>
                            </button>
                        </h2>
                        <!-- collapseabal Div show all data / collapse Body  -->
                        <div id="s3_tital_body_div" class="accordion-collapse collapse" aria-labelledby="s3_tital_div" data-bs-parent="#accordionExample" style="overflow-y: scroll; height:400px;">
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th> Sr.No. </th>
                                            <th> Document Name </th>
                                            <!-- <td> Document </td> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        foreach ($documents as $key => $value) {
                                            if ($value['stage'] == "stage_3") {
                                                if ($value['required_document_id'] == 19 || $value['required_document_id'] == 29) {
                                                    $i++;
                                                    $required_document_id = $value['required_document_id'];

                                        ?>
                                                    <tr>
                                                        <td> <?= $i; ?> </td>
                                                        <td>
                                                            <a href="<?= base_url() . "/" . $value['document_path'] . '/' . $value['document_name']  ?>" target="_blank">
                                                                <?= $value['name']; ?>
                                                            </a>
                                                        </td>
                                                    </tr>
                                        <?php
                                                } // required_document_id
                                            } // stage
                                        } // forech 
                                        ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>


<?= $this->endSection() ?>

<!---------- custom_script -->
<?= $this->section('custom_script') ?>


<?= $this->endSection() ?>