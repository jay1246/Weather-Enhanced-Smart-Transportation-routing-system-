<?= $this->extend('template/login_template') ?>
<?= $this->section('main') ?>

<!-- inner heading  -->
<div class="bg-green text-white text-center pb-1" style="font-size: 120%;">
    <span>
        <b> Welcome to the Admin Login </b>
    </span>
</div>

<div class="container mt-4 mb-4">

    <div class="row">

        <div class="col-md-3"></div>
        <div class="bg-white col-md-6 shadow ">
            <form action="<?= base_url('admin/logincheck') ?>" id="Login_form" method="post" class="row g-3">
                <h6 class="" style="padding: 10px;  font-size:24px"><i class="bi bi-shield-lock"></i> Admin Login </h6>
                <hr class="" style="margin: 0px;">

                <?= $this->include("alert_box.php") ?>

                <div class="col-sm-2"></div>
                <div class="col-sm-8">
                    <div class="input-group">
                        <div class="input-group-prepend" style="width: 25%;">
                            <div class="input-group-text">Email <span class="text-danger" style="margin: 5px;"> *</span> </div>
                        </div>
                        <input type="text" name="email" class="form-control" id="inputText" required />
                    </div>
                </div>
                <div class="col-sm-2"></div>

                <div class="col-sm-2"></div>
                <div class="col-sm-8">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">Password <span class="text-danger" style="margin: 5px;">*</span> </div>
                        </div>
                        <input type="password" name="password" class="form-control" required />
                    </div>
                </div>
                <div class="col-sm-2"></div>



                <div class="col-sm-2"></div>
                <div class="col-sm-8">
                    <div class="text-center">
                        <button class="btn btn_green_yellow w-50 login mb-4 " type="submit" id="login_btn">Login</button>
                    </div>
                </div>
                <div class="col-sm-2"></div>

            </form>


            <div class="col-12 text-center " style="font: size 14px;">
                <a href="<?= base_url('admin/forgot_password') ?>" class="text-danger">Forgot Password ?</a>
                <div style="margin-bottom: 10px;"></div>
            </div>
        </div>

        <div class="col-md-3"></div>

        <div class="col-md-12 mb-5 mt-5"></div>

    </div> <!-- row  -->
</div> <!-- container  -->

<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    // $("#Login_form").submit(function(e) {

    //         $("#alert").fadeIn("slow");

    // });
</script>
<?= $this->endSection() ?>