<?= $this->extend('template/admin_template') ?>

<?= $this->section('main') ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h4 class="text-green">Referee Details</h4>
    </div><!-- End Page Title -->
    <?php
    //  $this->include("alert_box.php");
    ?>
    <style>
        tr {
            border-color: inherit;
            border-style: solid;
            border-width: 0;
        }
    </style>
    <section class="section dashboard mt-3 shadow">
        <div class="row">
            <div class="card shadow">
                <div class="card-body">
                    <div class="table table-responsive">
                        <table class="table ">
                            <tbody>

                                <tr>
                                    <th width="25%"><b>PRN</b></th>
                                    <td>:</td>
                                    <td>
                                        <b><?php
                                            echo portal_reference_no($pointer_id);
                                            ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="25%"><b>Application No.</b></th>
                                    <td>:</td>
                                    <td>
                                        <b><?php
                                            echo get_unique_number($pointer_id);
                                            ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="25%"><b>Applicant Name</b></th>
                                    <td>:</td>
                                    <td><?= $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name ?></td>
                                </tr>
                                <tr>
                                    <th width="25%"><b>Agent Name</b></th>
                                    <td>:</td>
                                    <td>
                                        <?=
                                        $user_account->name . " " . $user_account->middle_name . " " . $user_account->last_name
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="25%"><b>Agency</b></th>
                                    <td>:</td>
                                    <td>
                                        <?=
                                        $user_account->business_name
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="25%"><b>Agent Contact No.</b></th>
                                    <td>:</td>
                                    <td>
                                        <?php $mobile_code = find_one_row('country', 'id', $user_account->mobile_code);
                                        echo "+" . $mobile_code->phonecode . " " . $user_account->mobile_no ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <!--  Table with stripped rows starts -->
                        <table id="" class="table" style="background-color: #f6f6f6;">
                            <thead>
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Referee Name </th>
                                    <th>Referee Email-Id</th>
                                    <th>Referee Contact No</th>
                                    <th>Company/Organisation Name</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                foreach ($employs as $employ) { ?>
                                    <tr>
                                        <th><?= $count ?></th>
                                        <td><?= $employ->referee_name ?></td>
                                        <td><?= $employ->referee_email ?></td>
                                        <td>
                                            <?php
                                            // echo $employ->referee_mobile_number_code;
                                            $ref_mobile_code = find_one_row('country', 'id', $employ->referee_mobile_number_code);
                                            echo "+" . $ref_mobile_code->phonecode . " " . $employ->referee_mobile_number ?>
                                        </td>

                                        <td>
                                            <?= $employ->company_organisation_name ?>
                                        </td>
                                        <td>


                                            <?php
                                            $email_verification = find_one_row('email_verification', 'employer_id', $employ->id);

                                            if (isset($email_verification)) {
                                                $verification_email_send = $email_verification->verification_email_send;
                                                $is_verification_done = $email_verification->is_verification_done;
                                            } else {
                                                $verification_email_send = 0;
                                                $is_verification_done = 0;
                                            }


                                            if ($is_verification_done == 1) {
                                                $url_Verified = base_url('admin/verification/Change_status/' . $pointer_id . '/' . $employ->id . '/Verified');
                                            ?>
                                                <a onclick="update_data('<?= $url_Verified ?>')" id="ver_url">
                                                    <span class='text-green'>Verified</span>
                                                </a>

                                            <?php
                                            } else
                                            if ($verification_email_send == 1) {
                                                $url_Pending = base_url('admin/verification/Change_status/' . $pointer_id . '/' . $employ->id . '/Pending');
                                            ?>
                                                <a onclick="update_data('<?php echo $url_Pending; ?>')" id="pending_url">
                                                    <span class='text-blue' style="color:blue !important">Pending</span>
                                                </a>
                                            <?php
                                            } else {
                                                echo "[#T.B.A]";
                                            }
                                            ?>



                                        </td>

                                        <td>
                                            <a href="" data-bs-toggle="modal" data-bs-target="#edit_form<?= $count ?>" class="btn btn-sm btn_green_yellow"> <i class="bi bi-pencil-square"></i></a>
                                        </td>

                                    </tr>

                                    <!-- modal box for edit -->
                                    <div class="modal" id="edit_form<?= $count ?>">
                                        <div class="modal-dialog  modal-lg">
                                            <div class="modal-content" style="background-color: white;">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-center text-green">Edit Employee</h5>
                                                </div>
                                                <div class="modal-body">

                                                    <!-- <form class="edit_data" id="edit_data<?= $pointer_id . $employ->id ?>" action="" method="post"> -->
                                                    <form class="edit_data" id='resend_form_<?= $pointer_id . $employ->id ?>' action="<?= base_url('admin/verification/edite_and_email_send/' . $pointer_id . '/' . $employ->id) ?>" method="post">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <label>Company/Organisation Name <span class="text-danger">*</span></label>
                                                                <input name="company_organisation_name" type="text" class="form-control mb-2" value="<?= $employ->company_organisation_name ?>" disabled>
                                                                <input type="hidden" name="pointer_id" class="form-control mb-2" value="<?= $pointer_id ?>">
                                                                <input type="hidden" name="employer_id" class="form-control mb-2" value="<?= $employ->id ?>">
                                                            </div>



                                                            <!-- vishal patel 28-04-2023  -->
                                                            <div class="col-12">
                                                                <label>Select Document :</label>
                                                                <?php
                                                                foreach ($documents as $key => $value) {
                                                                    $document_id = $value->id;
                                                                    $employee_id = $value->employee_id;
                                                                    $required_document_id = $value->required_document_id;
                                                                    $document_name = $value->name;
                                                                    $document_file_name = $value->document_name;
                                                                    $document_path = $value->document_path;

                                                                    if ($employ->id == $employee_id) {
                                                                        if ($required_document_id != 10) {
                                                                            $email_verification = find_one_row('email_verification', 'employer_id', $employ->id);
                                                                            $document_ids_json =  isset($email_verification->document_ids) ? $email_verification->document_ids : "";
                                                                            $checked = "";
                                                                            if (!empty($document_ids_json)) {
                                                                                if (!empty($required_document_id)) {
                                                                                    if (strpos($document_ids_json, $document_id) !== false) {
                                                                                        $checked = "checked";
                                                                                    }
                                                                                }
                                                                            }
                                                                ?>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" <?= $checked ?> name="document_ids[]" type="checkbox" value="<?= $document_id ?>" id="<?= $document_file_name ?>">
                                                                                <label class="form-check-label" for="<?= $document_file_name ?>">
                                                                                    <a class="text-blue" href="<?= base_url($document_path . "/" . $document_file_name) ?>" target="_blank"> <?= $document_name ?> </a>
                                                                                </label>
                                                                            </div>
                                                                <?php  }
                                                                    }
                                                                    # code...
                                                                }
                                                                ?>
                                                            </div>
                                                            <!--/ vishal patel 28-04-2023  -->


                                                            <div class="col-12">
                                                                <label>Referee Name <span class="text-danger">*</span></label>
                                                                <input name="referee_name" type="text" class="form-control mb-2" value="<?= $employ->referee_name ?>">
                                                            </div>
                                                            <div class="col-12">
                                                                <label>Referee Email-Id <span class="text-danger">*</span></label>
                                                                <input name="referee_email" type="email" class="form-control mb-2" autocomplete="false" value="<?= $employ->referee_email ?>">
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="text-end">
                                                                <button type="button" class="btn btn_yellow_green" data-bs-dismiss="modal">Close</button>
                                                                <button type="button" onclick="save_send('resend_form_<?= $pointer_id . $employ->id ?>');" class="btn btn_green_yellow">Save & Send</button>

                                                                <!-- <button type="button" onclick="save_send('edit_data<?= $pointer_id . $employ->id  ?>');" class="btn btn_green_yellow">Save & Send</button> -->
                                                            </div>
                                                        </div>

                                                    </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- modal box for edit end -->


                                <?php
                                    $count++;
                                }  ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>


</main>



<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    $(document).ready(function() {
        $('#employ_table').DataTable();
    });

    function update_data(url) {
        //c//onsole.log(url);
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to update the status?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'update_btn');
        $("#update_btn").click(function() {

            if (custom_alert_popup_close('update_btn')) {
                // if (confirm("Are you sure you want to delete this Occupation?")) {  
                window.location = url;


            }
        });
    }



    function save_send(data) {
        //c//onsole.log(url);
        custom_alert_popup_show(header = '', body_msg = "Are you sure you want to send the verification email ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'save_send_');
        $("#save_send_").click(function() {
            var myForm = document.getElementById(data);
            myForm.submit();
            $('#cover-spin').show(0);
            // console.log(data + "-------------------------------------------");
        });
    }


    function Alert() {
        var confirmation = confirm("Are you sure you want to change the status?");
        if (confirmation) {
            return true;
        }
        return false;
    }
</script>
<style>
    #cover-spin {
        position: fixed;
        width: 100%;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background-color: rgba(251, 251, 251, 0.6);
        z-index: 9999;
        display: none;
    }

    #loader_img {
        position: fixed;
        left: 50%;
        top: 50%;
    }
</style>
<div id="cover-spin">
    <div id="loader_img">
        <img src="<?= base_url("public/assets/image/admin/loader.gif") ?>" style="width: 100px; height:auto">
    </div>
</div>
<?= $this->endSection() ?>