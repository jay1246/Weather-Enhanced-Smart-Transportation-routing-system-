<?= $this->extend('template/admin_template') ?>

<?= $this->section('main') ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h4 class="text-green">Employment Verification</h4>
    </div><!-- End Page Title -->
    <section class="section dashboard mt-3 shadow">
        <div class="row">
            <div class="card shadow">
                <div class="card-body">
                    <div class="table table-responsive">

                        <!--  Table with stripped rows starts -->

                        <table id="staff_table" class="table table-striped datatable">

                            <thead>
                                <tr>
                                    <th scope="col" style="width: 5%;">
                                        <span data-bs-toggle="tooltip" data-bs-placement="top" title="Portal Reference No.">
                                            PRN
                                        </span>
                                    </th>

                                    <!--<th>Sr.No.</th>-->
                                    <th>Application No. </th>
                                    <th>Applicant Name</th>
                                    <th>Agent Name</th>
                                    <th>Agent Contact No.</th>
                                    <th>Agency</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                foreach ($applications as $applicant) {
                                    $email_verification = find_one_row('email_verification', 'pointer_id', $applicant->id);
                                ?>

                                    <?php if (!empty($email_verification)) { ?>
                                        <tr>
                                            <?php
                                            $user_account = find_one_row('user_account', 'id', $applicant->user_id);
                                            $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $applicant->id);
                                            $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $applicant->id);
                                            ?>
                                            <td>
                                                <?php echo  portal_reference_no($applicant->id); ?>
                                            </td>
                                            <!--<td><?php //$count ?></td>-->
                                            <td><?php
                                                $stage_1 = find_one_row('stage_1', 'id', $applicant->id);
                                                if (empty($stage_1->unique_id)) {
                                                    $unique_code = "[#T.B.A]";
                                                } else {
                                                    $unique_code = "[#" . $stage_1->unique_id . "]";
                                                }
                                                echo $unique_code ?>
                                            </td>
                                            <td><?= $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name ?></td>
                                            <td><?= $user_account->name . " " . $user_account->middle_name . " " . $user_account->last_name ?></td>
                                            <td><?php
                                                $mobile_code = find_one_row('country', 'id', $user_account->mobile_code);
                                                echo "+" . $mobile_code->phonecode . " " . $user_account->mobile_no ?></td>
                                            <td><?= $user_account->business_name ?></td>
                                            <td>
                                                <?php
                                                $email_verification = find_multiple_rows('email_verification', 'pointer_id', $applicant->id);
                                                $No_varification = 0;
                                                $No_done_varification = 0;
                                                foreach ($email_verification as $key => $value) {
                                                    $No_varification++;
                                                    if ($value->is_verification_done == 1) {
                                                        $No_done_varification++;
                                                    }
                                                }
                                                ?>
                                                <a data-bs-toggle="tooltip" data-bs-placement="right" title="<?= $No_done_varification ?> / <?= $No_varification ?>" href="<?= base_url('admin/verification/view_application') ?>/<?= $applicant->id ?>" class="btn btn-sm btn_green_yellow">
                                                    <i class="bi bi-eye-fill eye-open-click"></i>
                                                </a>
                                            </td>

                                        </tr>

                                        <?php $count++;  ?>

                                    <?php   } else {  ?>
                                        <tr>
                                            <?php
                                            $user_account = find_one_row('user_account', 'id', $applicant->user_id);
                                            $s1_personal_details = find_one_row('stage_1_personal_details', 'pointer_id', $applicant->id);
                                            $s1_occupation = find_one_row('stage_1_occupation', 'pointer_id', $applicant->id);
                                            ?>
                                            <td>
                                                <?php echo  portal_reference_no($applicant->id); ?>
                                            </td>
                                            <!--<td><?= $count ?></td>-->
                                            <td><?php
                                                $stage_1 = find_one_row('stage_1', 'id', $applicant->id);
                                                if (empty($stage_1->unique_id)) {
                                                    $unique_code = "[#T.B.A]";
                                                } else {
                                                    $unique_code = "[#" . $stage_1->unique_id . "]";
                                                }
                                                echo $unique_code ?>
                                            </td>
                                            <td><?= $s1_personal_details->first_or_given_name . " " . $s1_personal_details->middle_names . " " . $s1_personal_details->surname_family_name ?></td>
                                            <td><?= $user_account->name . " " . $user_account->middle_name . " " . $user_account->last_name ?></td>
                                            <td><?php
                                                $mobile_code = find_one_row('country', 'id', $user_account->mobile_code);
                                                echo "+" . $mobile_code->phonecode . " " . $user_account->mobile_no ?></td>
                                            <td><?= $user_account->business_name ?></td>
                                            <td>
                                                <?php

                                                ?>
                                                <a data-bs-toggle="tooltip" data-bs-placement="right" title="[#T.B.A]" href="<?= base_url('admin/verification/view_application') ?>/<?= $applicant->id ?>" class="btn btn-sm btn_green_yellow">
                                                    <i class="bi bi-eye-fill eye-open-click"></i>
                                                </a>
                                            </td>

                                        </tr>
                                    <?php  } ?>

                                <?php  }  ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>


</main>



<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    $(document).ready(function() {
        $('#staff_table').DataTable({
            "language": {
                "lengthMenu": '_MENU_ ',
                "search": '<i class="fa fa-search"></i>',
                "searchPlaceholder": "Search",
            }

        });
    });
</script>

<?= $this->endSection() ?>