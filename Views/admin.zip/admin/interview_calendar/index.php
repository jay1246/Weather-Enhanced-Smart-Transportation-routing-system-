<?= $this->extend('template/admin_template') ?>
<?= $this->section('main') ?>


<main id="main" class="main">

    <div class="pagetitle">
        <h4 class="text-green">Interview Calender</h4>
    </div><!-- End Page Title -->

    <section class="section dashboard mt-3 shadow">
        <div class="row">
            <div class="card shadow">
                <div class="card-body">  
                </div>
            </div>
        </div>
    </section>
</main>

<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<script>
   
</script>
<?= $this->endSection() ?>