<style>
    .tital_set {
        /* background-color: var(--gray); */
        background-color: #8b9fc6;
        font-size: 1.1rem;
        color: black !important;
        box-shadow: none;
    }
</style>

<?php
$show = true;
if (session()->get('admin_account_type') == 'head_office') {
    if ($stage_2->status == "Submitted") {
        $show = false;
    }
} ?>
<?php if ($show) { ?>
    <div class="accordion" id="document_stage_2">
        <div class="accordion-item">
            <h2 class="accordion-header" id="doc_head_stage_2">
                <button class="accordion-button collapsed  text-green" type="button" data-bs-toggle="collapse" data-bs-target="#doc_stage_2" aria-expanded="false" aria-controls="doc_stage_2" style="font-size:16px; font-style:Nunito,sans-serif;font-weight:bold"> <i class="bi bi-folder-fill mx-2"></i>
                    Stage 2 Documents
                </button>
            </h2>

            <div id="doc_stage_2" class="accordion-collapse collapse" aria-labelledby="doc_head_stage_2" data-bs-parent="#document_stage_2">
                <div class="accordion-body">
                    <div id="download_div" class="mb-3 ">
                        <a onclick="download_zip(<?= $pointer_id ?>,'stage_2')" class="btn_yellow_green btn"> Download All Stage 2 Documents <i class="bi bi-download"></i></a>
                    </div>
                    <?php
                    // echo "<pre>";
                    // print_r($stage_2_ass_documents);
                    // echo "</pre>";

                    ?>

                    <form action="" id="reason_form_stage_2" method="post">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Document Name</th>
                                    <th style="width: 150px;text-align: center;">Action</th>
                                    <th>Comments</th>
                                </tr>
                            </thead>
                            <tbody>

                                <!-- assessment documents ----------------------->
                                <tr class="tital_set">
                                    <td colspan="3" style="--bs-table-accent-bg:none">
                                        <!-- <i class="bi bi-briefcase-fill" style="padding-right: 5px;"></i>  -->
                                        <b> Assessment Documents</b>
                                    </td>
                                </tr>
                                <?php
                                $stage_2_ass_documents = assessment_documents($pointer_id);
                                $sr_no = 1;
                                $verify_email_2 = 0;

                                foreach ($stage_2_ass_documents as $s2_document_ass) {
                                    // if ($s2_document_ass->employee_id = 17) {


                                    $show_f2 = true;
                                    $employee_documnet_request_s2 = find_one_row('additional_info_request', 'document_id', $s2_document_ass->id);
                                    if (!empty($employee_documnet_request_s2)) {
                                        if (isset($employee_documnet_request_s2->status)) {
                                            if ($employee_documnet_request_s2->status == "send") {
                                                $show_f2 = false;
                                            }
                                        }
                                    }


                                    // $s2_disabled_comment = "";
                                    // if (isset($s2_document_ass->name)) {
                                    //     if ($s2_document_ass->name  == "Verification - Employment" || $s2_document_ass->name  == "Verification Email - Employment") {
                                    //         $s2_disabled_comment = "disabled";
                                    //         $show_f2 = false;

                                    //         $verify_email_2 = 1;
                                    //     }
                                    // }
                                    // // if ($s2_document_ass->required_document_id == 0) {
                                    // //     $s2_disabled_comment = "disabled";
                                    // //     $show_f2 = false;
                                    // // }
                                    // $documnet_request_s2 = find_one_row('additional_info_request', 'document_id', $s2_document_ass->id);
                                    // if (!empty($documnet_request_s2)) {
                                    //     $s2_disabled_comment = "disabled";
                                    //     $show_f2 = false;
                                    // }
                                    if ($show_f2) {
                                ?>
                                        <tr>
                                            <!-- <td class="w-50" style="padding-left: 50px;"> -->
                                            <td class="w-50">
                                                <a class="normal_link" target="_blank" href="<?= base_url() ?>/<?= $s2_document_ass->document_path ?>/<?= $s2_document_ass->document_name ?>"> <?= $s2_document_ass->name  ?> </a>
                                            </td>
                                            <td style="text-align: center;">
                                                <!-- download  -->
                                                <a href="<?= base_url() ?>/<?= $s2_document_ass->document_path  ?>/<?= $s2_document_ass->document_name  ?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>

                                                <!-- Delete  -->
                                                <a onclick="delete_document_s2_(<?= $s2_document_ass->id ?>)" href="javascript:void(0)" class="btn btn-sm btn-danger">
                                                    <i class="bi bi-trash-fill"></i>
                                                </a>
                                                <?php
                                                $s2_disabled_comment = "";
                                                if (isset($s2_document_ass->name)) {
                                                    if ($s2_document_ass->name  == "Verification - Employment" || $s2_document_ass->name  == "Verification Email - Employment") {
                                                        $s2_disabled_comment = "disabled";
                                                        $verify_email_2 = 1;
                                                    }
                                                }
                                                if ($s2_document_ass->required_document_id == 0) {
                                                    $s2_disabled_comment = "disabled";
                                                }
                                                $documnet_request_s2 = find_one_row('additional_info_request', 'document_id', $s2_document_ass->id);
                                                if (!empty($documnet_request_s2)) {
                                                    $s2_disabled_comment = "disabled";
                                                }
                                                ?>
                                                <!-- comment  -->
                                                <a href="javascript:void(0)" class="btn <?= $s2_disabled_comment ?>  btn-sm btn_green_yellow" id="Dbtn_s2_<?= $sr_no ?>" onclick="show_input_s2('<?= $sr_no ?>')">
                                                    <i class="bi bi-chat-left-dots"></i>
                                                </a>
                                                <a href="javascript:void(0)" style="display: none;" id="Xbtn_s2_<?= $sr_no ?>" class="btn btn_yellow_green btn-sm" onclick="show_input_s2('<?= $sr_no ?>')">
                                                    <i class="bi bi-x-lg"></i>
                                                </a>
                                            </td>
                                            <td>
                                                <input type="text" name="reason[]" style="display: none;" onkeyup=check_s2() id="input_s2_<?= $sr_no ?>" class="form-control s1">
                                                <input type="hidden" name="document_id[]" value="<?= $s2_document_ass->id  ?>">
                                                <input type="hidden" name="pointer_id[]" value="<?= $s2_document_ass->pointer_id ?>">
                                                <input type="hidden" name="stage[]" value="<?= $s2_document_ass->stage ?>">
                                            </td>
                                        </tr>
                                <?php

                                        $sr_no++;
                                    }
                                    // }
                                }
                                ?>
                                <!-- assessment documents end ----------------------->

                                <!-- employees documents ----------------------->
                                <?php
                                $sr = 1;
                                foreach ($stage_2_add_employees as $stage_2_employee) { ?>
                                    <tr class="tital_set">
                                        <td colspan="3" style="--bs-table-accent-bg:none">
                                            <!-- <i class="bi bi-briefcase-fill" style="padding-right: 5px;"></i> -->
                                            <?= $stage_2_employee->company_organisation_name ?>
                                        </td>
                                    </tr>
                                    <?php
                                    $stage_2_documents = find_multiple_row_3_field('documents', 'pointer_id', $pointer_id, 'stage', 'stage_2', 'employee_id', $stage_2_employee->id);
                                    $count = 1;
                                    foreach ($stage_2_documents as $s2_document) {
                                        if ($s2_document->required_document_id != 17) {
                                    ?>


                                            <?php
                                            $show_f2 = true;
                                            $employee_documnet_request_s2 = find_one_row('additional_info_request', 'document_id', $s2_document->id);
                                            if (!empty($employee_documnet_request_s2)) {
                                                if (isset($employee_documnet_request_s2->status)) {
                                                    if ($employee_documnet_request_s2->status == "send") {
                                                        $show_f2 = false;
                                                    }
                                                }
                                            }
                                            if ($show_f2) {
                                            ?>
                                                <!-- All Basic Documents ----------------------------->
                                                <tr>
                                                    <!-- <td class="w-50" style="padding-left: 50px;"> -->
                                                    <td class="w-50">
                                                        <a class="normal_link" target="_blank" href="<?= base_url() ?>/<?= $s2_document->document_path ?>/<?= $s2_document->document_name ?>"> <?= $s2_document->name  ?> </a>
                                                    </td>
                                                    <td style="text-align: center;">
                                                        <!-- download  -->
                                                        <a href="<?= base_url() ?>/<?= $s2_document->document_path  ?>/<?= $s2_document->document_name  ?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>

                                                        <!-- Delete  -->
                                                        <a onclick="delete_document_s2_(<?= $s2_document->id ?>)" href="javascript:void(0)" class="btn btn-sm btn-danger">
                                                            <i class="bi bi-trash-fill"></i>
                                                        </a>
                                                        <!-- comment  -->

                                                        <a href="javascript:void(0)" class="btn btn-sm  btn_green_yellow " id="Dbtn_s2_<?= $sr . $count ?>" onclick="show_input_s2('<?= $sr . $count ?>')">
                                                            <i class="bi bi-chat-left-dots"></i>
                                                        </a>
                                                        <a href="javascript:void(0)" style="display: none;" id="Xbtn_s2_<?= $sr . $count ?>" class="btn btn_yellow_green btn-sm" onclick="show_input_s2('<?= $sr . $count ?>')">
                                                            <i class="bi bi-x-lg"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="reason[]" style="display: none;" onkeyup=check_s2() id="input_s2_<?= $sr . $count ?>" class="form-control s1">
                                                        <input type="hidden" name="document_id[]" value="<?= $s2_document->id  ?>">
                                                        <input type="hidden" name="pointer_id[]" value="<?= $s2_document->pointer_id ?>">
                                                        <input type="hidden" name="stage[]" value="<?= $s2_document->stage ?>">
                                                    </td>
                                                </tr>
                                <?php
                                            }
                                            $count++;
                                        }
                                        $sr++;
                                    }
                                }
                                ?>


                                <!-- employees documents end ----------------------->





                                <!-- Additional Information ----------------------->
                                <tr class="tital_set">
                                    <td style="--bs-table-accent-bg:none">
                                        <b> Additional Information </b>
                                    </td>
                                    <!-- background-color: #8b9fc600; -->
                                    <td style="text-align: center; ">
                                        <!-- download  -->
                                        <!-- download  -->
                                        <a herf="" class="btn disabled btn-sm btn_yellow_green " style=" border:0px; background-color: #ffe475 !important; color:black !important"><i class="bi bi-download"></i></a>
                                        <!-- delete  -->
                                        <a class="btn btn-sm btn-danger disabled"><i class="bi bi-trash-fill"></i></a>
                                        <!-- comment  -->
                                        <a href="javascript:void(0)" class="btn btn-sm btn-sm btn_green_yellow" id="Dbtn_s2_Additional" onclick="show_input_s2('Additional')">
                                            <i class="bi bi-chat-left-dots"></i>
                                        </a>
                                        <a href="javascript:void(0)" class="btn btn-sm btn_yellow_green" style="display: none;" id="Xbtn_s2_Additional" onclick="show_input_s2('Additional')">
                                            <i class="bi bi-x-lg"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <input type="hidden" name="pointer_id[]" value="<?= $pointer_id ?>">
                                        <input type="hidden" name="stage[]" value="stage_2">
                                        <input type="text" id="input_s2_Additional" style="display: none;" onkeyup=check_s2() class="form-control s1" name="request_additional">
                                    </td>
                                </tr>
                                <?php
                                $stage_2_ass_documentsa = Additional_Information_docs($pointer_id);
                                $sr_no = 1;

                                foreach ($stage_2_ass_documentsa as $s2_document_ass) {
                                    // if ($s2_document_ass->employee_id == "") {
                                ?>
                                    <tr>
                                        <!-- <td class="w-50" style="padding-left: 50px;"> -->
                                        <td class="w-50">
                                            <a class="normal_link" target="_blank" href="<?= base_url() ?>/<?= $s2_document_ass->document_path ?>/<?= $s2_document_ass->document_name ?>"> <?= $s2_document_ass->name  ?> </a>
                                        </td>
                                        <td style="text-align: center;">
                                            <!-- download  -->
                                            <a href="<?= base_url() ?>/<?= $s2_document_ass->document_path  ?>/<?= $s2_document_ass->document_name  ?>" download="" class="btn btn-sm btn_yellow_green"><i class="bi bi-download"></i></a>

                                            <!-- Delete  -->
                                            <a onclick="delete_document_s2_(<?= $s2_document_ass->id ?>)" href="javascript:void(0)" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash-fill"></i>
                                            </a>
                                            <?php
                                            $s2_disabled_comment = "";
                                            if (isset($s2_document_ass->name)) {
                                                if ($s2_document_ass->name  == "Verification - Employment") {
                                                    $s2_disabled_comment = "disabled";
                                                    $verify_email_2 = 1;
                                                }
                                            }
                                            if ($s2_document_ass->required_document_id == 0) {
                                                $s2_disabled_comment = "disabled";
                                            }
                                            $documnet_request_s2 = find_one_row('additional_info_request', 'document_id', $s2_document_ass->id);
                                            if (!empty($documnet_request_s2)) {
                                                $s2_disabled_comment = "disabled";
                                            }
                                            ?>
                                            <!-- comment  -->
                                            <a href="javascript:void(0)" class="btn <?= $s2_disabled_comment ?>  btn-sm btn_green_yellow" id="Dbtn_s2_<?= $sr_no ?>" onclick="show_input_s2('<?= $sr_no ?>')">
                                                <i class="bi bi-chat-left-dots"></i>
                                            </a>
                                            <a href="javascript:void(0)" style="display: none;" id="Xbtn_s2_<?= $sr_no ?>" class="btn btn_yellow_green btn-sm" onclick="show_input_s2('<?= $sr_no ?>')">
                                                <i class="bi bi-x-lg"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <input type="text" name="reason[]" style="display: none;" onkeyup=check_s2() id="input_s2_<?= $sr_no ?>" class="form-control s1">
                                            <input type="hidden" name="document_id[]" value="<?= $s2_document_ass->id  ?>">
                                            <input type="hidden" name="pointer_id[]" value="<?= $s2_document_ass->pointer_id ?>">
                                            <input type="hidden" name="stage[]" value="<?= $s2_document_ass->stage ?>">
                                        </td>
                                    </tr>
                                <?php
                                    $sr_no++;
                                    // }
                                }
                                ?>
                                <!-- <tr>
                                <td> -->
                                <?php
                                $stage_2_ass_documents = Additional_Information_docs($pointer_id);
                                // echo "<pre>";
                                // echo "s";
                                // print_r($stage_2_ass_documents);
                                // echo "</pre>";
                                ?>
                                <!-- </td>
                            </tr> -->






                                <!-- Additional Information end ----------------------->
                                <tr>
                                    <td colspan="3">
                                        <button type="submit" class="btn btn_green_yellow" style="display: none; float:right" id="s2_doc_sub_btn">Request Additional Info</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </form>
                    <?php
                    if (session()->get('admin_account_type') == 'admin') {
                    ?>
                        <div class="row">
                            <?php
                            // echo "<pre>";
                            // print_r($stage_2_email_verification);
                            // echo "</pre>";
                            if (empty($stage_2_email_verification)) {
                            ?>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <button id="Send_Employment_Verification_Email" class="btn btn_green_yellow" onclick="send_emp_email()"> Send Employment Verification Email </button>
                                        </div>
                                    </div>

                                </div>
                            <?php
                            }
                            if ($verify_email_2 != 1) {
                            ?>

                                <div class="col-sm-4 my-4">
                                    <form action="" id="verify_email_stage_2" method="post">
                                        <h5> Verification - Employment </h5>
                                        <div class="row">
                                            <div class="col-10">
                                                <input name="file" type="file" class="form-control s1" required>
                                                <input name="pointer_id" type="hidden" class="form-control s1" value="<?= $pointer_id ?>">
                                            </div>
                                            <div class="col-2">
                                                <button type="submit" class="btn btn_green_yellow">Upload</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>