<?= $this->extend('template/admin_template') ?>
<?= $this->section('main') ?>

<main id="main" class="main">
    <style>
        .flag_button_row {
            /*margin-right: 10px;*/
            /*width: 200px;*/
        }

        /*.flag_button {*/
        /*    padding: 0;*/
        /*    margin: 0;*/
        /* border-radius: 15px; */
        /*}*/

        /*.pull-up {*/
        /*    position: absolute;*/
        /*    margin-top: -48px;*/
        /*    text-align: right;*/
        /*    margin-left: 84%;*/
        /*}*/

        /*.dataTables_length {*/
        /*    margin-top: -48px;*/
        /*}*/
        table {
            table-layout: fixed;
            width: 100% !important;
        }



        .grn_btn {
            width: 70px;
            border-radius: 3px;
            height: 36.96px;
            position: absolute;
            right: 320px;
            /*right: 250px;*/
            top: 7px;
            z-index: 3;
        }


        .red_btn {
            width: 70px;
            height: 36.96px;
            border-radius: 3px;
            position: absolute;
            right: 240px;
            /*right: 250px;*/
            top: 7px;
            z-index: 3;
        }

        .grn_btn:hover {
            background-color: #EBFCDF;
        }

        .red_btn:hover {
            background-color: #FCE8E4;
        }


        /*.active_flag_green{*/
        /*    background-color:#EBFCDF;*/
        /*}*/
        /*.active_flag_red{*/
        /*   background-color:#FCE8E4; */
        /*}*/
        /*.active_flag {*/
        /*    background-image: linear-gradient(#ffde82, #fecc00);*/
        /*}*/

        .flag_img {
            width: 18px;
        }

        .filter_flag {
            height: 40px;
        }
    </style>
    <div class="pagetitle">
        <h4 class="text-green">Application Manager</h4>
    </div><!-- End Page Title -->
    <section class="section dashboard mt-3 shadow">
        <div class="row">
            <div class="card shadow">
                <div class="card-body" style="padding: 0px !important;">

                    <div class="table">

                        <!--  Table with stripped rows starts -->

                        <table id="staff_table" class="table table-striped datatable table-hover">
                            <div class="row flag_button_row float-end">
                                <button class="col-md flag_button grn_btn" id="green_flag_btn" type="button" style="border: 1px solid white;"><img id="id_flag_green" class="filter_flag" data-toggle="tooltip" data-placement="top" title="Additional Information Received" src="<?= base_url("public/assets/icon/flag-green.png") ?>"></button>
                                <button class="col-md flag_button red_btn" id="red_flag_btn" data-toggle="tooltip" data-placement="top" title="Additional Information Requested" type="button" style="border: 1px solid white;"><img id="id_flag_red" class="filter_flag" src="<?= base_url("public/assets/icon/flag-red.png") ?>"></button>
                            </div>
                            <thead>
                                <tr>
                                    <th style="width: 1%;"></th>
                                    <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                                        <th style="width: 5%;">
                                            <span data-bs-toggle="tooltip" data-bs-placement="top" title="Portal Reference No.">
                                                PRN
                                            </span>
                                        </th>
                                    <?php } ?>
                                    <th style="width: 10%;">Applicant No.</th>
                                    <th style="width: 30%;">Applicant Name </th>
                                    <th style="width: 10%;">D.O.B </th>
                                    <th style="width: 15%;">Occupation</th>
                                    <th style="width: 10%;">Date Submitted</th>
                                    <th style="width: 10%;">Current Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                                // echo "<pre>";
                                // print_r($all_list);
                                // echo "</pre>";
                                // exit;

                                // Custom comparison function
                                function compareItemsByCreatedAt($a, $b)
                                {
                                    return strtotime($a['submitted_date']) - strtotime($b['submitted_date']);
                                }

                                // Sort the items array using the custom comparison function
                                usort($all_list, 'compareItemsByCreatedAt');
                                $all_list = array_reverse($all_list);
                                $count = 1;

                                foreach ($all_list as $key => $value) {

                                    $Expiry_name = "";
                                    // $approved_date = $value['approved_date'];
                                    $approved_date = isset($value['approved_date']) ? $value['approved_date'] : "";

                                    if (!empty($approved_date) && $approved_date != "0000-00-00 00:00:00" && $approved_date != null) {
                                        $Expired_date =  date('Y-m-d', strtotime('+60 days', strtotime($approved_date)));
                                        $expiry_date_temp = strtotime($Expired_date);
                                        $todays_date = strtotime(date('Y-m-d'));  // sempal
                                        // $todays_date = strtotime('2023-02-16');  // sempal
                                        $timeleft = $todays_date - $expiry_date_temp;
                                        $day_remain = round((($timeleft / 86400)));
                                        if ($day_remain < -30) {
                                            $Expiry_name =  "Expiry";
                                        } else if ($day_remain > -30 && $day_remain  < 0) {
                                            $Expiry_name =  "Expired";
                                        } else if ($day_remain  >= 0) {
                                            $Expiry_name =  "Closed";
                                        }
                                    }

                                ?>
                                    <tr>
                                        <td>
                                            <?php
                                            $additional_info_request = $value['additional_info_request'];
                                            if ($value['Current_Status'] != "Closed" && $value['Current_Status'] != "Completed")
                                                if ($additional_info_request != "") {
                                                    $session = session();
                                                    $admin_account_type = $session->get('admin_account_type');
                                                    $flag_show = true;
                                                    if ($admin_account_type == 'head_office' && $value['Current_Status'] == "S2 - Submitted") {
                                                        $flag_show = false;
                                                    }

                                                    if ($flag_show) {

                                            ?>
                                                    <?php if ($additional_info_request->status == "send") { ?>
                                                        <span style="font-size: 0px; position: absolute;">F_red</span>
                                                        <a href="" data-bs-toggle="modal" data-bs-target="#flag_model<?= $count ?>">
                                                            <img class="flag_img" src="<?= base_url("public/assets/icon/flag-red.png") ?>">
                                                        </a>
                                                    <?php  } else if ($additional_info_request->status == "upload") { ?>
                                                        <span style="font-size: 0px;     position: absolute;">F_greeen</span>
                                                        <a href="" data-bs-toggle="modal" data-bs-target="#flag_model<?= $count ?>">
                                                            <img class="flag_img" src="<?= base_url("public/assets/icon/flag-green.png") ?>">
                                                        </a>
                                                    <?php  } else if ($additional_info_request->status == "verified") { ?>
                                                        <!-- verified -->
                                                    <?php } ?>
                                                <?php } ?>

                                                <!-- model box for flag -->
                                                <div class="modal" id="flag_model<?= $count ?>">
                                                    <div class="modal-dialog  modal-xl">
                                                        <div class="modal-content" style="background-color: white;">
                                                            <div class="modal-header">

                                                                <?php if ($additional_info_request->status == "send") { ?>
                                                                    <h5 class="modal-title text-center text-success"> Additional Information Requested</h5>
                                                                <?php  } else if ($additional_info_request->status == "upload") { ?>
                                                                    <h5 class="modal-title text-center text-success"> Additional Information Received</h5>
                                                                <?php } ?>

                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="table">
                                                                    <!--  Table with stripped rows starts -->
                                                                    <table class="table table-striped datatable">
                                                                        <thead>
                                                                            <tr>
                                                                                <th class="col-lg-1"> Sr.No </th>
                                                                                <th class="col-lg-4"> Comments </th>
                                                                                <th class="col-lg-3"> Document Name</th>
                                                                                <th class="col-lg-2"> Date Requested </th>
                                                                                <?php if ($additional_info_request->status == "upload") { ?>
                                                                                    <th class="col-lg-2"> Date Received </th>
                                                                                <?php } ?>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php
                                                                            $sr = 1;
                                                                            $additional_infos = find_multiple_rows('additional_info_request', 'pointer_id', $value['pointer_id']);
                                                                            foreach ($additional_infos as $val) {
                                                                            ?><tr>
                                                                                    <td><?= $sr ?></td>
                                                                                    <td>

                                                                                        <?php
                                                                                        $employ_name = "";
                                                                                        if (isset($val->document_id)) {
                                                                                            $id = $val->document_id;
                                                                                            $stage = $val->stage;
                                                                                            $employee_id  = isset(find_one_row('documents', 'id', $id)->employee_id) ? find_one_row('documents', 'id', $id)->employee_id : "";
                                                                                            $required_document_id  = isset(find_one_row('documents', 'id', $id)->required_document_id) ? find_one_row('documents', 'id', $id)->required_document_id : "";
                                                                                           // echo $required_document_id ;
                                                                                            //exit;
                                                                                            if($required_document_id==15||$required_document_id==16 ||$required_document_id==30 ){
                                                                                                  $employ_name = "<b class='text-success'>ASSESMENT DOCUMENTS</b><br>";
                                                                                            }
                                                                                            else if($required_document_id==17){
                                                                                                  $employ_name = "<b class='text-success'>ADDITIONAL INFORMATION</b><br>";
                                                                                            }
                                                                                            else{
                                                                                                if (!empty($employee_id) || $employee_id != 0) {

                                                                                                $company_organisation_name  = isset(find_one_row('stage_2_add_employment', 'id', $employee_id)->company_organisation_name) ? find_one_row('stage_2_add_employment', 'id', $employee_id)->company_organisation_name : "";

                                                                                                if (!empty($company_organisation_name)) {

                                                                                                    $employ_name = "<b class='text-success'>" . $company_organisation_name . "</b><br>";

                                                                                                }


                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                        <?= $employ_name ?> <?= $val->reason ?>

                                                                                    </td>
                                                                                    <td><?php
                                                                                        if (isset($val->document_id)) {
                                                                                            $id = $val->document_id;
                                                                                            if (isset(find_one_row('documents', 'id', $id)->document_name) || isset(find_one_row('documents', 'id', $id)->document_path)) {
                                                                                                $document_name = find_one_row('documents', 'id', $val->document_id)->document_name;
                                                                                                $document_path = find_one_row('documents', 'id', $val->document_id)->document_path;
                                                                                                echo  '  <a href="' . base_url($document_path . '/' . $document_name) . '" target="_blank">' . $document_name . '</a>';
                                                                                            } else {
                                                                                                echo "N/A";
                                                                                            }
                                                                                        } else {
                                                                                            echo "N/A";
                                                                                        } ?></td>

                                                                                    <?php if ($val->status == "upload") { ?>
                                                                                        <td><?php
                                                                                            if ($val->create_date != "0000-00-00 00:00:00" and !empty($val->update_date)) {
                                                                                                $create_date = date('d/m/Y', strtotime($val->create_date));
                                                                                            } else {
                                                                                                $create_date = "--//--";
                                                                                            }
                                                                                            echo $create_date;
                                                                                            ?></td>
                                                                                    <?php } ?>
                                                                                    <td><?php if ($val->update_date != "0000-00-00 00:00:00" and !empty($val->update_date)) {
                                                                                            $update_date =  date('d/m/Y', strtotime($val->update_date));
                                                                                        } else {
                                                                                            $update_date = "--//--";
                                                                                        }
                                                                                        echo $update_date;
                                                                                        ?></td>
                                                                                </tr>
                                                                            <?php
                                                                                $sr++;
                                                                            }
                                                                            ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </td>
                                        <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                                            <td>
                                                <?= $value['portal_reference_no'] ?>
                                            </td>
                                        <?php } ?>
                                        <td>
                                            <?= $value['unique_id'] ?>
                                        </td>
                                        <td>
                                            <a href="<?= base_url('admin/application_manager/view_application') ?>/<?= $value['pointer_id'] ?>/view_edit" style="color:#009933">
                                                <?= $value['Applicant_name'] ?>
                                            </a>
                                        </td>
                                        <td>
                                            <?= $value['date_of_birth'] ?>
                                        </td>
                                        <td>
                                            <?= $value['occupation_name'] ?>
                                        </td>
                                        <td>
                                            <?= $value['submitted_date_format'] ?>
                                        </td>
                                        <td>
                                            <?php
                                            if ($value['Current_Status'] == "S1 - Expired") {
                                                if ($Expiry_name ==  "Closed") {
                                                    // if (stage_1_expired_day($value['pointer_id']) < -60) {
                                                    echo "Closed";
                                                } else {
                                                    echo $value['Current_Status'];
                                                }
                                            } else {
                                                echo $value['Current_Status'];
                                            }
                                            ?>
                                        </td>

                                    </tr>
                                <?php $count++;
                                } ?>
                            </tbody>
                        </table>




                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>


</main>



<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>
<script>
    $(document).ready(function() {
        var table = $('#staff_table').DataTable({
            "aaSorting": [],
            // order: [
            //     [5, 'asc']
            // ],
            "language": {
                "lengthMenu": '_MENU_ ',
                "search": '<i class="fa fa-search"></i>',
                "searchPlaceholder": "Search",
            },
            scrollX: false
        });
        console.log('staff_table');
        $('.dataTables_filter').addClass('pull-up');

        // document.getElementById("id_flag_red").addEventListener("click", function() {
        //         console.log('F_red');
        //         var red_flag = document.getElementById("red_flag_btn");
        //         if (red_flag.className == "col-md flag_button active_flag_red") {
        //             console.log('remove');
        //             red_flag.classList.remove("active_flag_red");
        //             table.column(0).search('').draw();
        //         } else {
        //             console.log('add');
        //             red_flag.classList.add("active_flag");

        //             var green_flag = document.getElementById("green_flag_btn");
        //             if (green_flag.className == "col-md flag_button active_flag_green") {
        //                 console.log('remove');
        //                 green_flag.classList.remove("active_flag_green");
        //             }
        //             table.column(0).search('F_red').draw();
        //         }
        //     }),
        //     document.getElementById("id_flag_green").addEventListener("click", function() {
        //         console.log('F_greeen');
        //         var green_flag = document.getElementById("green_flag_btn");
        //         var red_flag = document.getElementById("red_flag_btn");
        //         console.log(green_flag.className);
        //         if (green_flag.className == "col-md flag_button active_flag_green") {
        //             console.log('remove');
        //             green_flag.classList.remove("active_flag_green");
        //             table.column(0).search('').draw();
        //         } else {
        //             console.log('add');
        //             green_flag.classList.add("active_flag");
        //             var red_flag = document.getElementById("red_flag_btn");
        //             if (red_flag.className == "col-md flag_button active_flag_red") {
        //                 console.log('remove');
        //                 red_flag.classList.remove("active_flag_red");
        //             }
        //             table.column(0).search('F_greeen').draw();
        //         }

        //     })

        $('#green_flag_btn').click(function() {
            console.log('F_green');
            var green_flag = $('#green_flag_btn');
            var red_flag = $('#red_flag_btn');
            if (green_flag.attr('class') == "col-md flag_button grn_btn active_flag") {
                green_flag.removeClass("active_flag");
                green_flag.css("background-color", "#F0F0F0");
                table.column(0).search('').draw();
            } else {
                green_flag.addClass("active_flag");
                if (red_flag.attr('class') == "col-md flag_button red_btn active_flag") {
                    red_flag.removeClass("active_flag");
                    red_flag.css("background-color", "#F0F0F0");
                }
                red_flag.css("background-color", "#F0F0F0");
                table.column(0).search('F_greeen').draw();
                green_flag.css("background-color", "#EBFCDF");
            }

        });


        $('#red_flag_btn').click(function() {
            console.log('F_red');
            var green_flag = $('#green_flag_btn');
            var red_flag = $('#red_flag_btn');
            if (red_flag.attr('class') == "col-md flag_button red_btn active_flag") {
                red_flag.removeClass("active_flag");
                red_flag.css("background-color", "#F0F0F0");
                table.column(0).search('').draw();

            } else {
                red_flag.addClass("active_flag");
                if (green_flag.attr('class') == "col-md flag_button grn_btn active_flag") {
                    green_flag.removeClass("active_flag");
                    green_flag.css("background-color", "#F0F0F0");
                }
                table.column(0).search('F_red').draw();
                green_flag.css("background-color", "#F0F0F0");
                red_flag.css("background-color", "#FCE8E4");
            }

        });
    });
    $(document).ready(function() {
        $('#flag_table').DataTable({
            "aaSorting": []
        });

    });
</script>

<?= $this->endSection() ?>