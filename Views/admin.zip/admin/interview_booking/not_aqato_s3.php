<?= $this->extend('template/admin_template') ?>

<?= $this->section('main') ?>

<link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
<style>
    input[type="datetime-local"]::-webkit-datetime-edit-seconds-field {
        display: none;

    }

    input[type="datetime-local"]::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .book_btn {
        position: absolute;
        right: 250px;
        top: 69px;
        z-index: 3
    }

    .nav-link {
        font-weight: bold;
        color: #055837;
    }

    .nav-link:hover {
        font-weight: bold;
        background-color: #FFC107 !important;
        color: #055837 !important;
    }

    .active_btn {
        font-weight: bold;
        background-color: #055837 !important;
        color: #FFC107 !important;
    }


    .active_btn:hover {
        font-weight: bold;
        background-color: #FFC107 !important;
        color: #055837 !important;
    }

    .btn_green {
        background-color: #055837 !important;
        color: #FFC107 !important;
    }

    .btn_green:hover {
        background-color: #FFC107 !important;
        color: #055837 !important;
    }
</style>
<main id="main" class="main">
    <div class="pagetitle">
        <h4 class="text-green">Interview Bookings</h4>
    </div><!-- End Page Title -->

    <section class="section dashboard mt-3 shadow">
        <div class="row">

            <div class="card shadow">
                <div class="card-header p-0 border-bottom-0">
                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">

                        <li class="nav-item">
                            <a class="nav-link" id="custom-tabs-agent-tab" href="https://attc.aqato.com.au/admin/interview_booking" role="tab" aria-controls="custom-tabs-agent" aria-selected="false">
                                AQATO
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active_btn" id="custom-tabs-applicant-tab" href="https://attc.aqato.com.au/admin/not_aqato_s3" role="tab" aria-controls="custom-tabs-applicant" aria-selected="true">
                                NON-AQATO
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- End Add booking Modal-->
                <br>
                <div class="table table-responsive">

                    <!--  Table with stripped rows starts -->
                    <a href="" data-bs-toggle="modal" data-bs-target="#add_form" class="btn btn_green_yellow book_btn">
                        <i class="bi bi-plus"></i>
                        New Booking
                    </a>
                    <div class="modal " id="add_form">
                        <div class="modal-dialog  modal-lg ">
                            <div class=" modal-content bg-white">
                                <form id="add_data" action="" class="p-2" method="post">

                                    <div class="modal-header">
                                        <h5 class="modal-title text-center text-green">Add New Interview Booking (NON-AQATO)</h5>
                                    </div>
                                    <div class="modal-body">

                                        <!-- Applicant -->
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-6 mt-2">
                                                    <b><label>Applicant Full Name <span class="text-danger">*</span></label></b>
                                                    <input type="text" name="full_name" value="" required class="form-control md-4" />
                                                </div>
                                                <div class="col-6 mt-2">
                                                    <b> <label>Application No.<span class="text-danger">*</span></label></b>
                                                    <input type="text" name="unique_number" value="" required class="form-control md-4" />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="row">

                                                <div class="col-6 mt-2">
                                                    <b> <label>Occupation <span class="text-danger">*</span></label></b>
                                                    <select name="occupation_name" id="select_location_new" class="form-select md-4" required>
                                                        <option value="">Select Occupation</option>
                                                        <?php
                                                        foreach ($occupation_list as $occupation) {
                                                        ?>
                                                            <option value="<?= $occupation->name ?>"><?= $occupation->name; ?></option>
                                                        <?php
                                                        }
                                                        ?>
                                                    </select>
                                                </div>

                                                <div class="col-6 mt-2">
                                                    <b> <label>Location <span class="text-danger">*</span></label> </b>
                                                    <select name="interview_location" id="new_book_select_venue" class="form-select md-4" required>
                                                        <option value="">Select Interview New Location</option>
                                                        <?php $all_countries = countries();
                                                        foreach ($all_countries as $country) {
                                                            if ($country->country != "Online" && $country->country != "Australia" && $country->country != "Philippines") {
                                                        ?>
                                                                <optgroup label="<?= $country->country ?>">
                                                                    <?php
                                                                    $num = 1;
                                                                    foreach ($interview_locations as $venue) {
                                                                        if ($venue->country == $country->country) {
                                                                    ?>
                                                                            <option value="<?= $venue->id ?>"><?= $venue->city_name ?></option>
                                                                    <?php
                                                                            $num++;
                                                                        }
                                                                    }
                                                                    ?>
                                                                </optgroup>

                                                        <?php
                                                            }
                                                        }
                                                        ?>



                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-6 mt-2 ">
                                                    <b> <label>Date <span class="text-danger">*</span></label></b>
                                                    <input name="date" id="new_book_date" type="date" min="<?php echo date('Y-m-d'); ?>" class="form-control mb-4" required />
                                                </div>

                                                <div class="col-6 mt-2" id="new_book_time_div_id">
                                                    <b> <label>Time (QLD) <span class="text-danger">*</span></label> </b>
                                                    <select name="time" class="form-select" required>
                                                        <?php
                                                        foreach ($stage_3_interview_booking_time_slots as $key => $value) {
                                                            $time = $value['time_start'];
                                                            $time =  str_replace(".", ":", $time);
                                                            $time =  str_replace("am", "AM", $time);
                                                            $time =  str_replace("pm", "PM", $time);
                                                            echo '<option value="' . $time . '">' . $time . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="text-end">
                                            <!-- <button type="button" class="btn btn_yellow_green" data-bs-dismiss="modal">Close</button> -->
                                            <a href="<?= base_url('admin/not_aqato_s3') ?>" class="btn btn_yellow_green" data-bs-dismiss="modal"> Close </a>
                                            <button type="submit" id="new_book_btn_submit" class="btn btn_yellow_green">Book Interview</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <table id="interview_booking_table" class="table table-striped datatable table-hover">
                        <thead>
                            <tr>
                                <th>Sr.No.</th>
                                <th>Applicant Name</th>
                                <th>Occupation</th>
                                <th>Application No.</th>
                                <th>Location</th>
                                <th>Date</th>
                                <th>Time(QLD)</th>
                                <?php if (session()->get('admin_account_type') == 'admin') {  ?>
                                    <!-- <th> Action </th> -->
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
                            foreach ($not_aqato_s3_model as $key => $value) {
                                $i++;
                                $s3_offline_location = find_one_row('stage_3_offline_location', 'id', $value->interview_location);
                            ?>
                                <tr>
                                    <td> <?= $i ?> </td>
                                    <td> <?= $value->full_name ?> </td>
                                    <td> <?= $value->occupation_name ?> </td>
                                    <td> [#<?= $value->unique_number ?>] </td>
                                    <td> <?= $s3_offline_location->city_name ?> </td>
                                    <td> <?= date('d/m/Y', strtotime($value->interview_date)) ?> </td>
                                    <td> <?= date('h:i A', strtotime($value->interview_date)) ?> </td>
                                    <!-- <td>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#add_form<?= $i ?>" class="btn btn_green_yellow">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <div class="modal " id="add_form<?= $i ?>">
                                            <div class="modal-dialog  modal-lg ">
                                                <div class=" modal-content bg-white">
                                                    <form action="<?= base_url('admin/not_aqato_s3/insert_booking_edite') ?>" class="p-2" method="post">

                                                        <div class="modal-header">
                                                            <h5 class="modal-title text-center text-green">Add New Interview Booking</h5>
                                                        </div>
                                                        <div class="modal-body">

                                                            <div class="col-12">
                                                                <div class="row">
                                                                    <div class="col-8 mt-2">
                                                                        <label>Applicant Full Name <span class="text-danger">*</span></label>
                                                                        <input type="text" name="full_name" value="<?= $value->full_name ?> " required class="form-control md-4" />
                                                                    </div>
                                                                    <div class="col-4 mt-2">
                                                                        <label>Uniq No <span class="text-danger">*</span></label>
                                                                        <input type="text" name="unique_number" value="<?= $value->unique_number ?>" required class="form-control md-4" />
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-12">
                                                                <div class="row">

                                                                    <div class="col-6 mt-2">
                                                                        <label>Occupation <span class="text-danger">*</span></label>
                                                                        <select name="occupation_name" id="select_location_new" class="form-select md-4" required>
                                                                            <option value="">Select Occupation</option>
                                                                            <?php
                                                                            $selected = "";
                                                                            foreach ($occupation_list as $occupation) {
                                                                                if ($value->occupation_name == $occupation->name) {
                                                                                    $selected = "selected";
                                                                                }
                                                                            ?>
                                                                                <option <?= $selected ?> value="<?= $occupation->name ?>"><?= $occupation->name; ?></option>
                                                                            <?php
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>

                                                                    <div class="col-6 mt-2">
                                                                        <label>Location <span class="text-danger">*</span></label>
                                                                        <select name="interview_location" id="new_book_select_venue" class="form-select md-4" required>
                                                                            <option value="">Select Interview New Location</option>
                                                                            <?php $all_countries = countries();
                                                                            foreach ($all_countries as $country) {
                                                                                if ($country->country != "Online" || $country->country != "Australia") {

                                                                            ?>
                                                                                    <optgroup label="<?= $country->country ?>">
                                                                                        <?php
                                                                                        $num = 1;
                                                                                        foreach ($interview_locations as $venue) {
                                                                                            if ($venue->country == $country->country) {
                                                                                                $selected = "";
                                                                                                if ($venue->id == $value->interview_location) {
                                                                                                    $selected = "selected";
                                                                                                }
                                                                                        ?>
                                                                                                <option <?= $selected ?> value="<?= $venue->id ?>"><?= $venue->city_name ?></option>
                                                                                        <?php
                                                                                                $num++;
                                                                                            }
                                                                                        }
                                                                                        ?>
                                                                                    </optgroup>

                                                                            <?php
                                                                                }
                                                                            }
                                                                            ?>



                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-12">
                                                                <div class="row">
                                                                    <div class="col-6 mt-2 ">
                                                                        <label>Date <span class="text-danger">*</span></label>
                                                                        <input name="date" value="<?= date('Y-m-d', strtotime($value->interview_date)) ?>" id="new_book_date" type="date" min="<?php echo date('Y-m-d'); ?>" class="form-control mb-4" required />
                                                                    </div>

                                                                    <div class="col-6 mt-2" id="new_book_time_div_id">
                                                                        <label>Time (QLD) <span class="text-danger">*</span></label>
                                                                        <select name="time" class="form-select" required>
                                                                            <?php
                                                                            foreach ($stage_3_interview_booking_time_slots as $key => $value) {
                                                                                $time = $value['time_start'];
                                                                                $time =  str_replace(".", ":", $time);
                                                                                $time =  str_replace("am", "AM", $time);
                                                                                $time =  str_replace("pm", "PM", $time);
                                                                                echo '<option value="' . $time . '">' . $time . '</option>';
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="text-end">
                                                                <a href="<?= base_url('admin/not_aqato_s3') ?>" class="btn btn_yellow_green" data-bs-dismiss="modal"> Close </a>
                                                                <button type="submit" id="new_book_btn_submit" class="btn btn_yellow_green">Book Interview</button>
                                                            </div>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td> -->
                                </tr>
                            <?php   }  ?>

                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>

<?= $this->endSection() ?>
<!---------- custom_script -->
<?= $this->section('custom_script') ?>

<script>
    $(document).ready(function() {
        $('#interview_booking_table').DataTable({
            "aaSorting": [],
            "language": {
                "lengthMenu": '_MENU_ ',
                "search": '<i class="fa fa-search"></i>',
                "searchPlaceholder": "Search",
            }

        });

        $(document).ready(function() {
            $("#add_data").submit(function(event) {
                event.preventDefault();
                custom_alert_popup_show(header = '', body_msg = "Are you sure, you want to book interview ?", close_btn_text = 'No', close_btn_css = 'btn-danger', other_btn = true, other_btn_name = 'Yes', other_btn_class = 'btn_green_yellow', other_btn_id = 'AJDSAKAJLD');
                // check Btn click
                $("#AJDSAKAJLD").click(function() {
                    // if return true 
                    if (custom_alert_popup_close('AJDSAKAJLD')) {

                        var formData = new FormData($('#add_data')[0]);

                        if ($('#select_location_new').val() != "" && $('#new_book_select_venue').val() != "") {
                            $('#cover-spin').show(0);
                            $.ajax({
                                method: "POST",
                                url: "<?= base_url("admin/not_aqato_s3/insert_booking") ?>",
                                data: formData,
                                processData: false,
                                contentType: false,
                                success: function(res) {
                                    console.log(res);
                                    if (res == "ok") {
                                        window.location = "<?= base_url("admin/not_aqato_s3") ?>"
                                    } else {
                                        $('#cover-spin').hide(0);
                                        window.location = "<?= base_url("admin/not_aqato_s3") ?>"
                                    }
                                },
                                error: function(xhr, ajaxOptions, thrownError) {
                                    $('#cover-spin').hide(0);
                                }
                            });
                        }
                    }
                });


            });
        });




    });
</script>
<?= $this->endSection() ?>