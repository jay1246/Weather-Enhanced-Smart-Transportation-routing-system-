<style>
    * {
        font-family: "Helvetica Neue", Roboto, Arial, "Droid Sans", sans-serif;
    }

    .logo_text_heading {
        padding: 10px;
        font-size: 24px;
        width: 100px;

        font-size: clamp(20px, 3vw, 24px);
    }

    .nav_div_css {
        padding: 13px;
        padding-bottom: 0px;
        max-width: 780px;
        text-align: center;
    }

    .nav_img_css {
        width: 100%;
    }

    .toggle-sidebar-btn {
        font-size: 32px;
        cursor: pointer;
        color: #012970;
    }

    .nav_img_css {
        max-width: 950px;
        /* max-height: 100px; */
    }

    .dropdown-menu:hover {
        color: green;
    }

    .out {
        /* padding: 2px !important; */
    }

    .out:hover {
        box-shadow: 5px 10px #888888 !important;
        color: red !important;
        border-bottom: 3px solid red !important;
    }
</style>
<div style="box-shadow: 0px 2px 20px rgba(1, 41, 112, 0.1);   ">
    <!-- main logos  -->
    <!--<header class="bg-white text-center d-flex justify-content-center">-->
    <!--    <br> <img class="nav_img_css" src="<?= base_url('public/assets/image/header_logo.jpg') ?>">-->
    <!--</header>-->
    <!-- User Funtion  -->

    <?php
    // print_r(session());
    if (session()->has('admin_name')) { ?>
        <nav class="bg-white row mx-0">
            <div class="col-lg-6 bg-white text-center d-flex  ">
                <img class="nav_img_css" src="<?= base_url('public/assets/image/header_logo.jpg') ?>" style="margin-left:50%">
            </div>

            <div class="col-6 dropdown d-flex justify-content-end mt-5">
                <a class="dropdown-toggle" style="text-decoration: none !important;margin-right: 10px; color:#012970" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                    <?php
                    // print_r(session());
                    if (session()->has('admin_name')) { ?>
                        <img src="<?= base_url('public/assets/image/admin/usericon.jpg') ?>" alt="Profile" class="rounded-circle" style="max-height:36px;margin-bottom:5% ">
                        <span class="ps-2" style="font-size: 14px; font-weight: 600;">
                            <!-- <?= session()->get('admin_email') ?> -->
                            <?= session()->get('admin_name') ?>
                        </span>
                        <a class="text-body nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <?php } ?>
                        </a>
                        <ul class="dropdown-menu shadow" style="min-width: 240px;" aria-labelledby="dropdownMenuButton1">

                            <!-- <?php if (isset($_COOKIE['day_night_mode'])) { ?>
                     <?php if ($_COOKIE['day_night_mode'] == "night") { ?>
                <li>
                    <a class="dropdown-item" href="<?= base_url('day_night_mode/day') ?>">
                        <i class="bi bi-brightness-high"></i> Day Mode
                    </a>
                </li>
                <?php } ?>
                <?php if ($_COOKIE['day_night_mode'] == "day") { ?>
                <li>
                    <a class="dropdown-item" href="<?= base_url('day_night_mode/night') ?>">
                        <i class="bi bi-moon-fill"></i> Night Mode
                    </a>
                </li>
                <?php } ?>
                <?php } else { ?>
                    <li>
                    <a class="dropdown-item" href="<?= base_url('day_night_mode/night') ?>">
                        <i class="bi bi-moon-fill"></i> Night Mode
                    </a>
                </li>
                <?php } ?> -->


                            <li class="dropdown-header">
                                <?php if (session()->has('admin_email')) { ?>
                                    <h6 class="text-black">
                                        Welcome - <?= session()->get('admin_name') ?>
                                    </h6>
                                    <hr>
                                    <a class="text-black out" href="<?= base_url('admin/logout') ?>">
                                        <center> <i class="bi bi-power"></i> Sign Out</center>
                                    </a>
                                <?php } ?>
                            </li>



                        </ul>
            </div>
        </nav>


    <?php } ?>
</div>