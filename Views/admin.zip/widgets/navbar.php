<style>
    .nav_img_css {
        max-width: 100%;
        max-height: 130px;
    }
    
    .dpn_item:hover {
         /*box-shadow: 5px 10px #888888 !important;*/
        color: red !important;
        /*border-bottom: 3px solid red !important;*/
          /*box-shadow: 0 5px 15px rgba(0, 0, 0, 0.8);*/
          /*background-color: #e6ffe6;*/
 
    }
</style>
<!-- main logos  -->
<header class="bg-white text-center d-flex justify-content-center">
    <!-- PC navbar  -->
    <div style="object-fit:cover; " class="container">
        <img class="nav_img_css" src="<?= base_url('public/assets/image/header_logo.jpg') ?>">
    </div>
</header>

<!-- User Funtion  -->
<?php if (session()->has('name')) { ?>

    <nav class="d-flex justify-content-end bg-white ">
        <!-- use for developer  -->
        <span style="padding-right: 90px;">
            <a href="<?= base_url('Account_type_change') ?>">
                <!-- <?= session()->get('account_type'); ?> -->
            </a>
            <?php
            if (isset($ENC_pointer_id)) {
                // echo pointer_id_decrypt($ENC_pointer_id);
            }
            ?>
        </span>
        <!-- use for developer  -->

        <div class="dropdown mb-1">
            <span style="padding-right: 10px;">
                <a href="<?= base_url() ?>">
                    <i class="bi bi-house-door-fill"></i> Dashboard
                </a>
            </span>
            <!-- <?= session()->get('last_name') ?> -->
            <a class="dropdown-toggle " style="margin-right: 20px;" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                <?php if (session()->has('name')) { ?>
                    Welcome - <b><?= session()->get('name') ?></b>
                    <a class="text-body nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                    <?php } else { ?>
                        Menu
                    <?php } ?>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">

                        <?php
                        if (isset($blablabla)) {
                            if (isset($_COOKIE['day_night_mode'])) { ?>
                                <?php if ($_COOKIE['day_night_mode'] == "night") { ?>
                                    <li>
                                        <a class="dropdown-item dpn_item" href="<?= base_url('day_night_mode/day') ?>">
                                            <i class="bi bi-brightness-high"></i> Day Mode
                                        </a>
                                    </li>
                                <?php } ?>
                                <?php if ($_COOKIE['day_night_mode'] == "day") { ?>
                                    <li>
                                        <a class="dropdown-item dpn_item" href="<?= base_url('day_night_mode/night') ?>">
                                            <i class="bi bi-moon-fill"></i> Night Mode
                                        </a>
                                    </li>
                                <?php } ?>
                            <?php } else { ?>
                                <li>
                                    <a class="dropdown-item dpn_item" href="<?= base_url('day_night_mode/night') ?>">
                                        <i class="bi bi-moon-fill"></i> Night Mode
                                    </a>
                                </li>
                            <?php } ?>
                        <?php } ?>


                        <?php if (session()->has('name')) { ?>
                            <li>
                                <a class="dropdown-item dpn_item" style="text-decoration: none !important;" href="<?= base_url('sing_out') ?>">
                                    <i class="bi bi-power"></i> Sign Out
                                </a>
                            </li>
                        <?php } ?>

                    </ul>
        </div>

    </nav>

<?php } else {
} ?>